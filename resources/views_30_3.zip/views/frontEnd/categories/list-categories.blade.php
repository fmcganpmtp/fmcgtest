@extends('layouts.template')
@section('title')
FMCG | List Categories
@endsection
@section('content')
<div class="bg-light min-vh-100 d-flex flex-row align-items-center login-scr">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 ">
        <div class="loginC align-middle">
          <div class="row">
            
            
                 
                 
                  
                  
                  
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
