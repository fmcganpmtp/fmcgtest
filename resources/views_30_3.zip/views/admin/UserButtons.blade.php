<div class="user-buttonC">
                  	<div class="col-auto">
                        <!-- <a href="{{ route('admin.dashboard') }}"><button   class="btn btn-outline-primary" type="button"><i class="icon  cil-list-numbered-rtl"></i>back to list</button></a> -->
                        <a href="{{ route('list-users') }}"><button   class="btn btn-outline-info" type="button"><i class="icon cil-list-rich"></i>Admin users</button></a>
                        <a href="{{ route('list.admin.roles') }}"><button   class="btn btn-outline-warning" type="button"><i class="icon  cil-functions"></i>Roles</button></a>

                        <a href="{{ route('list.permissions') }}"><button   class="btn btn-outline-success" type="button"><i class="icon  cil-highligt"></i>Permissions</button></a>
                       
                      </div>
                  </div>