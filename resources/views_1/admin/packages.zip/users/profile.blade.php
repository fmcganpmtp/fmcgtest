@extends('admin.master')
@section('title', 'User Profile')
@section('breadcrumb') Profile @endsection
@section('content')

@if(Session::has('message')) <div class="alert alert-success">{{Session::get('message') }}</div> @endif



    <div class="body flex-grow-1 px-3">
    <div class="container-lg">
      <div class="card-out mb-4 inner-form">
        <h2>Profile</h2>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-8 col-12">
              <div class="card ">
                <div class="card-header">Profile information</div>
                <div class="card-body">
               
                  <form method="POST" action="{{ route('update.user') }}" aria-label="{{ __('Register') }}" enctype="multipart/form-data">
                    @csrf
                     <input type="hidden" name="user_id" value="{{ $user->id }}">
					<div class="form-group">
                      <label>Name:</label>
                      <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ $user->name }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                    </div>
                    
                    <div class="form-group">
                      <label>Email:</label>
                      <input  id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{  $user->email }}" required>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                    </div>
                    
                    
                    <div class="form-group">
                      <label>Phone:</label>
                      <input id="phone" type="text" class="form-control{{ $errors->has('phone') ? ' is-invalid' : '' }}" name="phone" value="{{  $user->phone }}" required autofocus>

                                @if ($errors->has('phone'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('phone') }}</strong>
                                    </span>
                                @endif
                    </div>
                    
                    <div class="form-group">
                      <label>Job title:</label>
                      
                                @foreach($adminroles as $adminrole) 
                                         @if($adminrole->id== $adminroleSlected->id) {{$adminrole->role_name}} @endif
                                    @endforeach
                             <input type="hidden" name="adminrole" value="{{$adminroleSlected->id}}">
                            
                    </div>
                    
                    
                    
                     <div class="form-group">
    <label >Bio:</label>
    <textarea name="about" id="about" class="form-control{{ $errors->has('about') ? ' is-invalid' : '' }}">{{  $user->about }}</textarea>
                                @if ($errors->has('about'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('about') }}</strong>
                                    </span>
                                @endif
  </div>
  
  
  
  <div class="file-drop-area form-group">
  @if($user->profile_pic)
<img style=" width:100px !important;" class="pr_img" src="{{URL::asset('/uploads/userImages/').'/'.$user->profile_pic}}">
@endif
<label >Choose Profile Picture</label>
        <input type="file" name="image"  class="file-input form-control" accept=".jfif,.jpg,.jpeg,.png,.gif">
		

	</div>

	<div id="divImageMediaPreview">

	</div>
    
     <button type="submit" class="bl-btn">
                                    {{ __('Update') }}
                                </button>
                    
                  </form>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-12"> 
            
            
            <div class="card ">
                <div class="card-header">Change password</div>
                <div class="card-body">
                @if(Session::has('message'))
<p class="alert alert-info">{{ Session::get('message') }}</p>
@endif
                  <form action="{{ route('reset.admin.password.post') }}" method="POST">
				  <input type="hidden" name="email" value="{{ $user->email}}">
                          @csrf
                    <div class="form-group">
                      <label>Current password:</label>
                      <input name="oldPassword" type="password" class="form-control{{ $errors->has('oldPassword') ? ' is-invalid' : '' }}"  placeholder="" value="">
                     @if ($errors->has('oldPassword'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('oldPassword') }}</strong>
                            </span>
                        @endif
					</div>
                    
                    <div class="form-group">
                      <label>New password:</label>
                      <input value="" id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password">

                        @if ($errors->has('password'))
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $errors->first('password') }}</strong>
                            </span>
                        @endif
                    </div>
                    
                    
                    <div class="form-group">
                      <label>Confirm new password:</label>
                      <input  id="password-confirm" type="password" class="form-control" name="password_confirmation" >
                    </div>
                    
              
                    
                    
                    
                     
  
  
  
  


    
    <button type="submit" class="bl-btn">update password</button>
                    
                  </form>
                </div>
              </div>
            
            
            
             </div>
          </div>
        </div>
      </div>
    </div>
  </div>








@endsection
