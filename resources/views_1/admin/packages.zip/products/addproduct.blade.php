@extends('admin.master')
@section('title', 'Create Product')
@section('breadcrumb') Create Product @endsection
@section('content')




  <div class="body flex-grow-1 px-3">
    <div class="container-lg">
      <div class="card-out mb-4 inner-form">
        <h2>Product Creation</h2>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-12 col-12">
              <div class="card ">
    
              <div class="card-body">
              <div class="row">


				  
				  
				  
				  
				  <form method="POST" action="{{ route('save.product') }}" aria-label="{{ __('Register') }}"  enctype="multipart/form-data">
                     
                        @csrf
            <div class="row">
                        
               
            

            <div class=" col-lg-6 col-12">
                <div class="form-group">
                            <label for="name" >{{ __('Product name:') }} <span class="color_red">*</span></label>

                            <div >
                                <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ old('name') }}" required autofocus>

                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                    
                        <div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="product_price" >{{ __('Product Price') }} </label>

                            <div >
                                <input id="product_price"  type="number" step="0.01" class="form-control{{ $errors->has('product_price') ? ' is-invalid' : '' }}" name="product_price" value="{{ old('product_price') }}" required>

                                @if ($errors->has('product_price'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('product_price') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    </div>
                        
                        <div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="catrgory" >{{ __('Category') }} <span class="color_red">*</span></label>
 
                            <div >
							
							
							<select type="text" name="category_id[]" class="form-control" multiple>
                                        <option value="">None</option>
                                        @if($categories)
                                            @foreach($categories as $item)
                                                <?php $dash=''; ?>
                                                <option value="{{$item->id}}" >{{$item->name}}</option>
                                                @if(count($item->subcategory))
                                                @include('admin/products/subCategory',['subcategories' => $item->subcategory])
                                                @endif
                                            @endforeach
                                        @endif
                                    </select>
                             @if ($errors->has('category_id'))
                                 <span class="invalid-feedback" role="alert">
                                     <strong>{{ $errors->first('category_id') }}</strong>
                                 </span>
                             @endif
							
							
							
                            </div>
                        </div>
                    </div>
                        
                        <div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="SKU" >{{ __('SKU:') }} <span class="color_red">*</span></label>
 
                            <div >
                                <input id="SKU" type="text" class="form-control{{ $errors->has('SKU') ? ' is-invalid' : '' }}" name="SKU" value="{{ old('SKU') }}" required autofocus>

                                @if ($errors->has('SKU'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('SKU') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>
						
						<div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="stock_count" >{{ __('Stock Count:') }} </label>
 
                            <div >
                                <input id="stock_count" type="number" class="form-control{{ $errors->has('stock_count') ? ' is-invalid' : '' }}" name="stock_count" value="{{ old('stock_count') }}" required autofocus>

                                @if ($errors->has('stock_count'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('stock_count') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>
						
						<div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="product_color" >{{ __('Product Color:') }}</label>
 
                            <div >
                                <input id="product_color" type="text" class="form-control{{ $errors->has('product_color') ? ' is-invalid' : '' }}" name="product_color" value="{{ old('product_color') }}" required autofocus>

                                @if ($errors->has('product_color'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('product_color') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>
						
						<div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="product_weight" >{{ __('Weight:') }} </label>
 
                            <div >
                                <input id="product_weight" type="text" class="form-control{{ $errors->has('product_weight') ? ' is-invalid' : '' }}" name="product_weight" value="{{ old('product_weight') }}" required autofocus>

                                @if ($errors->has('product_weight'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('product_weight') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>
						
						<div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="product_size" >{{ __('Size:') }} </label>
 
                            <div >
                                <input id="product_size" type="text" class="form-control{{ $errors->has('product_size') ? ' is-invalid' : '' }}" name="product_size" value="{{ old('product_size') }}" required autofocus>

                                @if ($errors->has('product_size'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('product_size') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>
						<div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="product_dimension" >{{ __('Dimensions:') }} </label>
 
                            <div >
                                <input id="product_dimension" type="text" class="form-control{{ $errors->has('product_dimension') ? ' is-invalid' : '' }}" name="product_dimension" value="{{ old('product_dimension') }}" required autofocus>

                                @if ($errors->has('product_dimension'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('product_dimension') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>
						
						<div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="variants" >{{ __('Varients:') }} </label>
 
                            <div >
                                 <select type="text" multiple  name="variants[]" id='variants' class="form-control{{ $errors->has('variants') ? ' is-invalid' : '' }}">
          </select>
                               
                                @if ($errors->has('variants'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('variants') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>
						
						<div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="product_image" >{{ __('Thumbnail image:') }} </label>
 
                            <div >
                            <input type="file" id="input-file-now-custom-3" class="form-control m-2" name="product_image">
                               
                                @if ($errors->has('product_image'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('product_image') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>
						
						<div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="product_gallery" >{{ __('Gallery Images(multiple upload)::') }} </label>
 
                            <div >
                            <input type="file" id="input-file-now-custom-3" class="form-control m-2" name="product_gallery[]" multiple>
                                
                                @if ($errors->has('product_gallery'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('product_gallery') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>
						
                        <div class=" col-lg-6 col-12">
                <div class="form-group">
                            <label for="company_name" >{{ __('Company Name:') }}</label>

                            <div >
                                <input id="company_name" type="text" class="form-control" name="company_name" value="{{ old('company_name') }}"> 
                            </div>
                        </div>
                    </div>
                    
                        <div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="location" >{{ __('Location') }} </label>

                            <div >
                                <input id="location"  type="text"  class="form-control" name="location" value="{{ old('location') }}">                            
                            </div>
                        </div>
                    </div>
						
						
						<div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="available_countries" >{{ __('Available Countries:') }} </label>
 
                            <div >
                                <select type="text" multiple placeholder="Available Countries" name="available_countries[]" id='available_countries' class="form-control{{ $errors->has('product_dimension') ? ' is-invalid' : '' }}">
          </select>
                                @if ($errors->has('available_countries'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('available_countries') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>
						
						<div class=" col-lg-6 col-12"><div class="form-group">
                            <label for="product_description" >{{ __('Description') }}</label>

                            <div >
                                <textarea name="product_description" id="about" class="form-control{{ $errors->has('product_description') ? ' is-invalid' : '' }}">{{ old('product_description') }}</textarea>
                                @if ($errors->has('product_description'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('product_description') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div></div>




                        <div class="form-group mb-0">
                            <div class="">
                                <button type="submit" class="bl-btn">
                                    {{ __('Save') }}
                                </button>
								</div>
                        </div>







				  
            </div>
				  
                  </form>
                  
                  
                  
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>

</div>


  </div>

  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
</script>
<script type="text/javascript">
  
  
var route = "{{route('available.countries')}}";
  $('#available_countries').select2({
     placeholder: 'Select Available Countries',

    escapeMarkup: function(markup) { 
          return markup;
    },
    templateResult: function(data) {
       
      return data.html;
    },
    templateSelection: function(data) {
      

      if (data && !data.selected) 
      return data.text;
    },
    ajax: {
      url: route,
      dataType: 'json',
      delay: 250,
      processResults: function(data) {
        return {
          results: $.map(data, function(item) {
            return {
              html:"<span>"+item.name+"</span>",
              text: item.name,
              id: item.id
            }
          })
        };
      },
      cache: true,

    }
  });





  var route_varients = "{{route('autocomplete.product')}}";
  $('#variants').select2({
     placeholder: 'Select Varients',

    escapeMarkup: function(markup) { 
          return markup;
    },
    templateResult: function(data) {
       
      return data.html;
    },
    templateSelection: function(data) {
      

      if (data && !data.selected) 
      return data.text;
    },
    ajax: {
      url: route_varients,
      dataType: 'json',
      delay: 250,
      processResults: function(data) {
        return {
          results: $.map(data, function(item) {
            return {
              html:"<span>"+item.name+"</span>",
              text: item.name,
              id: item.id
            }
          })
        };
      },
      cache: true,

    }
  });
</script>







@endsection