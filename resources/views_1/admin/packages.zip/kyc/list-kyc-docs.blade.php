@extends('admin.master')
@section('title', 'List Admin Roles')
@section('breadcrumb') Admin Roles @endsection
@section('content')




 
  <div class="body flex-grow-1 px-3">
    <div class="container-lg">
      <div class="card-out mb-4 inner-form">
      @if(Session::has('message')) <div class="alert alert-success">{{Session::get('message') }}</div> @endif
        <h2>Kyc Documents</h2>
       
        <div class="card-body">
          <div class="row">
            <div class="col-lg-12 col-12">
              <div class="card ">
                <div class="card-header">
                <div class="search-area wth-btn">
                    
                    <div class="form-group">
                    <input type="search" id="search_key"  placeholder="Search...." class="form-control" value={{$search_key}}>
                      <button type="button" id="btnsearch"><i class="icon cil-search"></i></button>
                    
                   </div>
                   
                   </div> 
              </div>
             
                <div class="card-body">
                  <div class="tableC ad-rl-list">
                  <table id="datatable" class="table  table-bordered" data-page-length='20' cellspacing="0" width="100%">
                    <thead>
                        <tr>
                          <th>Sl No</th>
                          <th>User Name</th>
                          <th>File Type</th>
                          <th> Reason</th>
                          <th> Created At</th> 
                          <th> Status</th> 
                          <th> Actions</th>
                        </tr>
                      </thead>
                      
                    </table>
                  </div>
                
                
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
 
  </div>

  <div class="modal fade" id="Mymodal">
	  <div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Reject Document</h4>   <button type="button" class="close" data-dismiss="modal" onclick="fnclosepopup1()">&times;</button> 
				                                                          
			</div> 
			<div class="modal-body">
                <input type="hidden" id="hdnkycid">
                <textarea id="txtreason"  rows="4" cols="50"></textarea>
                <input type="button" onclick="rejectdocs()" Value="Ok" class="bl-btn">
            
			</div>  
		
		</div>                                                                       
	</div>  
                                                    
</div>
<script src="{{asset('/admin1/js/datatable.js')}}"></script>
<script>
var $ = jQuery;
  (function($) {
  $(document).ready( function () {
  
     
    $('#btnsearch').click(function(){
    dataTable.draw();
    });

    var dataTable=$('#datatable').DataTable({
         processing: false,
         serverSide: true,
        'searching': false,
         "lengthChange": false,
          "order": [ 0,'desc'],
         'ajax': {
       'url':'getkyclist',
       'data': function(data){
          _token="{{csrf_token()}}";
          data.search_key = $("#search_key").val();
       },
      
    }, 
   
    "columnDefs":[
      {
       "targets":0, 
       "orderable": false,
       "render": function(data,type,full,meta)
      {
        return meta.row + meta.settings._iDisplayStart + 1;

      }
    },
     
      {
       "targets":6, 
       "orderable": false,
       "render": function(data,type,full,meta)
      {
       var full_path='"'+full.file_path+'"';
       var str='"Are you Sure?"';
        return "<div class='icon-bx'> <button onclick='fnviewdocs("+full.id+","+full_path+")'  style='border: 0 none;'><i class='icon  fa fa-eye'></i></button>  <button type='button' onclick='fnapprove("+full.id+")' style='border: 0 none;'><i class='fa fa-thumbs-o-up' aria-hidden='true'></i></button><button type='button'  onclick='fnopenpopup1("+full.id+")' style='border: 0 none;'><i class='fa fa-thumbs-down' aria-hidden='true'></i></button></div>";
      }
    }
  ],
         columns: [
          { data: 'id' },
          { data: 'name' },
          { data: 'file_type' } ,  
          { data: 'reason' } ,
          { data: 'created_at' } ,
          { data: 'status' }  ,  
            

         ]
      });

  
     
  });
})(jQuery);

function fnviewdocs(id,name){
  var myArray = name.split(".");
  var type=myArray[myArray.length-1]; 
  var url= "{{asset('/uploads/KYCFiles/')}}"+'/'+name;
  window.open(url, "_blank");
}

function fnapprove(id){
    if(confirm("Are you Sure?"))  
    {
        $.ajax({
         url: "{{ url('approveuserdocs') }}",
            type: "post",
            data:{ 
                _token:'{{ csrf_token() }}',
                  id: id,
            },
            async:true,
            cache: false,
            dataType: 'json',
            success: function(data){
              
             if(data==1)
              {
                alert('Successfully Updated'); 
                location.reload(); 
              }
             else 
              alert('Updation Failed');
          }  
        })  ;

    }
}


 function rejectdocs(id){

        $.ajax({
         url: "{{ url('rejectdocs') }}",
            type: "post",
            data:{ 
                _token:'{{ csrf_token() }}',
                  reason: $("#txtreason").val(),
                  id: $("#hdnkycid").val(),
            },
            async:true,
            cache: false,
            dataType: 'json',
            success: function(data){
              
             if(data==1)
              {
                alert('Status Updated');
                $("#txtreason").val('');
                $("#Mymodal").modal('hide');
                 location.reload(); 
              }
             else 
              alert('Updation Failed');
          }  
        })  ;
    };




function fnopenpopup1(id){
  if(confirm("Are you Sure?"))  
   {
    $('#Mymodal').modal('show');
    $("#hdnkycid").val(id);
    }
}
function fnclosepopup1(){
    $("#Mymodal").modal('hide');
}
</script>

@endsection