@extends('admin.master')
@section('title', 'Edit Testimonial')
@section('breadcrumb') Edit Testimonial @endsection
@section('content')

@section('content')

    @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>{{ _('messages.Whoops') }}!</strong>
            {{ _('messages.There were some problems with your input') }}.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

<div class="body flex-grow-1 px-3">
    <div class="container-lg">
      <div class="card-out mb-4 inner-form">
        <h2>Edit Testimonial</h2>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-8 col-12">
              <div class="card ">
              <div class="card-body">
                  
                    <form method="POST" action="{{ route('testimonials.edit', $testimonials->id) }}"  enctype="multipart/form-data">
                    
                     @csrf
                     <input type="hidden" name="testimonial_id" value="{{ $testimonials->id }}">
                        <div class="form-group">
                            <label for="name" >{{ __('Name') }}  <span class="color_red">*</span></label>

                            <div >
                            <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }}" name="name" value="{{ $testimonials->name }}" required autofocus>
                                
                                
                                
                                @if ($errors->has('name'))
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                    
                        
						
						<div class="form-group">
                            <label for="name" >{{ __('Company') }}  <span class="color_red">*</span></label>
                            <div >
                             <input id="company" type="text" placeholder="Company" class="form-control" name="company" value="{{ $testimonials->company_name }}">
                             </div>
                        </div>
						
						
						<div class="form-group">
                            <label for="name" >{{ __('Title') }}  <span class="color_red">*</span></label>

                            <div >
                             <input id="title" type="text" placeholder="Title" class="form-control" name="title" value="{{ $testimonials->title }}">   
                            </div>
                        </div>
						
						<div class="form-group">
                        <div id="image-block">
                                <div class="form-group">
                                    @if ($testimonials->profile_pic != '')
                                    <img src="{{ asset('/assets/uploads/testimonials/') }}/{{ $testimonials->profile_pic }}" alt="{{ $testimonials->profile_pic }}" width="200px" />
                                    
                                    
                                    <a href="javascript:void(0)" onclick="removeImage({{ $testimonials->id }})" class=""><span class="red_round remove-input-field"><i class="fa fa-minus-circle" aria-hidden="true"></i></span></a>
                                @endif
                                </div>
                            </div>
                            <label for="file" >{{ __('Profile Picture') }}</label>

                            <div >
							 <input id="profile_pic" type="File" class="course-img" name="profile_pic">
                            </div>
                            </div>
                        </div>
						
						<div class="form-group">
                            <label for="name" >{{ __('Comments') }}  <span class="color_red">*</span></label>

                            <div >
                             <textarea placeholder="Comments" class="form-control" name="comments">{{ $testimonials->comments }}</textarea>   
                            </div>
                        </div>
						
                        
                        <div class="form-group mb-0">
                            <div class="">
                                <button type="submit" class="bl-btn">
                                    {{ __('Update') }}
                                </button>
								</div>
                        </div>
                    </form>
                  
                  
                  
                    @include('admin.UserButtons')
                  
                  
                </div>
              </div>
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>





@endsection
<script type="text/javascript">
        function removeImage(id = null){ 
            if(confirm('Do you want to remove image?')){
                if(id != null){
                    $.ajax({
                        type:'POST',
                        url:'{{ route("testimonials.removeImage") }}',
                        data:{id: id, '_token':'{{csrf_token()}}'},
                        success:function(response){
                            if(response.result){
                                $('#image-block').replaceWith('<span class="text-success" id="alert_image">Testimonial image removed successfully.</span>');
                                $('#alert_image').delay(2000).fadeOut();
                                $('#image-block').remove();
                            } else {
                                alert(response.message);
                            }
                        }
                    });
                } else {
                    alert('Image remove failed. Something went wrong.');
                }
            }
        }
    </script>