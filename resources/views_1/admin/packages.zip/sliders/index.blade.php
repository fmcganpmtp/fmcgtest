@extends('admin.master')
@section('title', 'Slider Settings')
@section('breadcrumb')Sliders @endsection
@section('content')

@section('content')
    @if (count($errors) > 0)
        <div class="alert alert-danger">
            <strong>{{ _('messages.Whoops') }}!</strong> {{ _('messages.There were some problems with your input') }}.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if (session('success'))
        <div class="alert alert-success">
            <ul>
                <li>{{ session('success') }}</li>
            </ul>
        </div>
    @endif
 
    <div class="body flex-grow-1 px-3">
    <div class="container-lg">
      <div class="card-out mb-4 inner-form">
      @if(Session::has('message')) <div class="alert alert-success">{{Session::get('message') }}</div> @endif
        <h2>Sliders</h2>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-12 col-12">
              <div class="card ">
                <div class="card-header">
                	<div class="search-area wth-btn">
                    
                     <div class="form-group">
					 
					  <a href="{{ route('admin.sliders') }}" style="text-decoration:none; color:#fff;padding: 10px 16px;position: relative;top: 7px;" class="bl-btn flt-left">Slider</a>
                        <a href="{{ route('admin.contentpages') }}"  style="text-decoration:none; color:#fff;padding: 10px 16px;position: relative;top: 7px;" class="bl-btn flt-left">Content Page</a>
					 
				
                    </div>
                    
                    </div>
                    
                    <a href="{{ route('slider.create') }}" class="bl-btn flt-right">Create Slider</a>
                    
                    
                </div>
                <div class="card-body">
                  <div class="tableC">
				  
                  @if($sliders->count() > 0) 
                    <table class="table table-bordered">
                      <thead>
                        <tr>
                                    <th>#</th>
                                    <th>Title</th>
                                    <th>Created at</th>
                                    <th class="action-icon">Action</th>
                                </tr>
                      </thead>
                      <tbody>
                      @php $count = 0; @endphp
                      @forelse ($sliders as $row)
                      @php $count++; @endphp
                      
                      <tr>
                      
                         <td>{{ ($sliders->currentpage() - 1) * $sliders->perpage() + $count }}</td>
                                    <td> {{ $row->name }}</td>
                                    <td>{{ $row->created_at }}</td>
                          <td>
						  
						  
						  <div class="icon-bx"> <a href="{{ route('slider.edit', $row->id) }}"><i class="icon  cil-pencil"></i></a> 
						  <a href="{{ route('slider.show', $row->id) }}"><i class="fa fa-eye"></i></a> 
                          <a href="{{route('slider.destroy',$row->id)}}"  onclick="return confirm('Do you really want to delete?')"><i class="icon cil-trash"></i></a> </div></td>
                        </tr>
                        
                            
                      @endforeach 
                      
                      
                       
              
                      </tbody>
                    </table>
                    @else
                      <div class="alert alert-danger">No Results</div>
                        
                       @endif 
                  </div>
                  
                  {{ $sliders->links()}}
                  @include('admin.UserButtons')
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  


 



@endsection