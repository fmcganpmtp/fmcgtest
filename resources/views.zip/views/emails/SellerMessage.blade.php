<h1>New Message</h1>
   
Details Below
<table>
    <tr><td>Name:</td><td>{{ $name  }}</td></tr>
    <tr><td>Email:</td><td>{{ $email  }}</td></tr>
    <tr><td>Phone:</td><td>{{ $phone  }}</td></tr>
    <tr><td>Message</td><td>{{ $msg  }}</td></tr>
    <tr><td>Product Name</td><td>{{ $productname  }}</td></tr>
    <tr><td>Product Id</td><td>{{ $product_id  }}</td></tr>
    
    
</table>   
