@extends('admin.master')
@section('title', 'Vendor Products List')
@section('breadcrumb') Products @endsection
@section('content')

<div class="body flex-grow-1 px-3">
  
  
    <div class="container-lg">
      <div class="card-out mb-4 inner-form cr-req">
      @if(Session::has('message')) <div class="alert alert-success">{{Session::get('message') }}</div> @endif
     
        <h2> product create request</h2>
        <div class="card-body ">
          <div class="row">
            <div class="col-lg-12 col-12">
              <div class="card ">
              
              
              
              <div class="card-header">
                 
                    
                  
                  <div class="row">
                    <div class="cl-05">
                      <label>Key word:</label>
                      <input type="text" id="search_key" class="form-control">
                    </div>
                    <div class="cl-05">
                      <div class="form-group">
                        <label>Category :</label>
                        <select type="text" id="category_id"  class="form-control" >
                                        <option value="">None</option>
                                        @if($categories)
                                            @foreach($categories as $item)
                                                <?php $dash=''; ?>
                                                <option value="{{$item->id}}" >{{$item->name}}</option>
                                                @if(count($item->subcategory))
                                                @include('admin/products/subCategory',['subcategories' => $item->subcategory])
                                                @endif
                                            @endforeach
                                        @endif
                                    </select>
                      </div>
                    </div>
                    <div class="cl-05">
                      <div class="form-group">
                        <label>Seller :</label>
                         <select type="text" id="user_id"  class="form-control" >
                                        <option value="">None</option>
                                       @foreach($User as $item)
                                                <?php $dash=''; ?>
                                                <option value="{{$item->id}}" >{{$item->name}}</option>
                                       @endforeach
                          </select>
                      </div>
                    </div>
                    
                    <div class="cl-05">
                      <div class="form-group">
                        <label>Country :</label>
                         <select type="text" id="country_id"  class="form-control" >
                                        <option value="">None</option>
                                       @foreach($Country as $item)
                                                <?php $dash=''; ?>
                                                <option value="{{$item->id}}" >{{$item->name}}</option>
                                       @endforeach
                          </select>
                      </div>
                    </div>
                    
                    <div class="cl-05">
                      <button type="button" id="btnsubmit" class="bl-btn flt-right top-mrg"><i class="fa fa-search" aria-hidden="true"></i> Search</button>
                    </div>
                  </div>
                  
                  
                  
                  <div class="row">
                  
                    <div class="col-lg-12">
                      <div class="flt-right">

                            <button type="button" onclick="fnChangStatus('active')" class="btn btn-outline-success">Approve selected</button>
                            <button type="button" onclick="fnChangStatus('rejected')" class="btn btn-outline-danger">Reject selected</button>

                        </div>
                    </div>
                  </div>
                  
                  
                  
                  
                </div>
              
              
              
                <div class="card-body">
                  <div class="tableC pro-cr-req">
        <table id="datatable" class="table  table-bordered" data-page-length='50' cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th></th>
                          <th><div class="custom-control custom-checkbox">
                           <input type="checkbox" class="custom-control-input" id="customCheck1">
                            <label class="custom-control-label" for="customCheck1"> </label>
                            </div>Sl no</th>
                          <th>Product name</th>
                          <th>Image</th>
                          <th>Store</th>
                          <th>Seller</th>
                          <th> Actions</th>
                        </tr>
                      </thead>
                      
                    </table>
                  </div>
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="{{asset('/admin1/js/datatable.js')}}"></script>
  <script src="{{asset('/admin1/js/sweetalert.js')}}"></script>
<script>
  var seller_products=[];
  var Active="'active'";
  var Pending="'rejected'";
  var $ = jQuery;
  (function($) {
  $(document).ready( function () {

   
    $(document).on("keydown", disableButtonsDown);
    $("#customCheck1").click(function(){
      
       if($("#customCheck1").is(':checked'))
        {  
         seller_products=[]; 
         $(".clsallcheck").prop('checked',true);
         $(".clsallcheck").each(function() {
            seller_products.push(parseInt($(this).attr('id')));
          });
       }
      else
        {
          $(".clsallcheck").prop('checked',false);
           seller_products=[];
        }
      
    })


    var id = '12';
    var editurl="{{route('vendor_product.edit', ':id')}}";
    var viewurl="{{route('vendor_product.view', ':id')}}";

    $('#datatable').on('page.dt', function() {
       seller_products=[];
       $("#customCheck1").prop('checked',false);
    });                   
    
    $('#btnsubmit').click(function(){
    dataTable.draw();
    });
    $("#search_key").keydown(function (event) { 
     if (event.which == 13) { 
         event.preventDefault();
         dataTable.draw();
     }
    });
   var dataTable = $('#datatable').DataTable({
         processing: false,
         serverSide: true,
         'searching': false,
         "lengthChange": false,
         "order": [ 0,'desc'],
         'ajax': {
          'url':"{{ url('getvendorproductlist') }}",
          'data': function(data){
          _token="{{csrf_token()}}";
           data.search_key = $("#search_key").val();
           data.category_id =$("#category_id").val();  
           data.country_id = $("#country_id").val(); 
           data.user_id = $("#user_id").val(); 
        },
      
    },   
   
    "columnDefs":[
    {
       "targets":0, 
       "orderable": true,
       "visible":false
      },
       {
       "targets":3, 
       "orderable": false,
      },
      {
       "targets":1, 
       "orderable": false,
       "render": function(data,type,full,meta)
      {
         
         return '<div class="custom-control custom-checkbox"><input id="'+full.id+'" type="checkbox" class="custom-control-input clsallcheck"  onclick="fnPushId('+full.id+')"></div>' +(meta.row + meta.settings._iDisplayStart + 1);
      }
    },
     
      {
       "targets":6, 
       "orderable": false,
       "data":"id",
       "render": function(data,type,full,meta)
      {
        editurl = editurl.replace(':id', '');
        viewurl = viewurl.replace(':id', '');
       

        return '<div class="icon-bx"> <a href="'+viewurl+full.id+'"><i class="fa fa-eye" aria-hidden="true"></i></a><a href="'+editurl+full.id+'"><i class="icon  cil-pencil"></i></a> <a href="JavaScript:void(0);" onclick="deleteconfirm('+full.id+')"><i class="icon cil-trash"></i></a> <button title="Approve This Product" onclick="fnstatusupdator('+full.id+','+Active+')"><i class="fa fa-check-circle-o" aria-hidden="true"></i></button>  <button title="Reject This Product" onclick="fnstatusupdator('+full.id+','+Pending+')"><i class="fa fa-window-close-o" aria-hidden="true"></i></button> </div>';     
      }
    }
  ],
         columns: [
          { data: 'id' },
          { data: 'id' },
          { data: 'name' },
          { data: 'profile_pic' } ,  
          { data: 'store_name' },
          { data: 'sellername' }
         ]
      });     
  });


})(jQuery);


function disableButtonsDown(e) { 
    if(e.key=='F5'){
       $("input:checkbox").prop('checked',"");
      }
};

function fnPushId(id){


  var exists = seller_products.includes(id)

  if (exists) 
    seller_products= seller_products.filter((c) => { return c !== id })
   else
    seller_products.push(id)
  

  //console.log(seller_products);
}

function fnChangStatus(status){
  swal({
    title:"Do you really want to Change Status? " ,
    text: "",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  })
  .then((willDelete) => {
    if (willDelete) {
    if(seller_products.length>0)
    { 
      $.ajax({
               url: "{{ url('vendorproductapproval') }}",
                  type: "post",
                  data:{ 
                      _token:'{{ csrf_token() }}',
                        seller_products: seller_products,
                        status:status
                  },
                  async:true,
                  cache: false,
                  dataType: 'json',
                  success: function(data){
                    swal(data);
                    $("input:checkbox").prop('checked',"");
                    seller_products=[]; 
                    location.reload();
                     } ,
                error: function(XMLHttpRequest, textStatus, errorThrown) { 
                  swal("Error: " ); 
                }  
      
              })  ;
            } 
            else
            swal("Please Select At Least One Item");
          }
          else {
            swal("Error: " + errorThrown); 
              }
          });  
         
}


function deleteconfirm(data){
  var id=data;
  var deleteurl="{{route('delete.vendorproduct', ':id')}}".replace(':id', '')+data;

  swal({
    title:"Do you really want to delete? " ,
    text: "",
    icon: "warning",
    buttons: true,
    dangerMode: true,
  })
  .then((willDelete) => {
    if (willDelete) {
      window.location=deleteurl;
    } 
    else {
          
        }
    });  

}

function fnstatusupdator(id,type){
  
       seller_products=[];
       seller_products.push(id);
       fnChangStatus(type);
  
}
</script>


 @endsection

