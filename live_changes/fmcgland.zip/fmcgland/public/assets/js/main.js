
EmojiArea.DEFAULTS.assetPath = './{{ asset('/images')}}';
