<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Chat_contact_delete extends Model
{
    protected $fillable = ['seller_id', 'deleted_id'];
}
