<?php include("header-2.php")?>
<sectiion class="seller-page no-bg">
  <div class="pr-banner">
    <!--<img src="assets/images/pr-banner.jpg">-->
  </div>
  <div class="container">
    <div class="row"> </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="pr-bottom">
          <div class="card wow fadeInUp">
            <div class="slr-details">
              <div class="pr-logo active-border"><img src="assets/images/seller.jpg">
                <!--not-active-border-->
                <!--                <div class="vrfd"><i class="fa fa-check" aria-hidden="true"></i> </div>
-->
              </div>
              <h2>Huppins</h2>
              <div class="row">
                <div class="col-lg-4 col-12">
                  <h3>Categories</h3>
                  <ul class="cat-list">
                     <li>Health care</li>
                     <li>Household</li>
                    <li> Personal/beauty care</li>
                    <li> Food</li>
                   <li>  Beverages</li>
                    <li> Alcohol</li>
                  <li>   Baby care</li>
                  </ul>
                </div>
                <div class="col-lg-4 col-12">
                  <h3>Details</h3>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s</p>
                </div>
                <div class="col-lg-4 col-12">
                  <h3>Address</h3>
                  <ul>
                    <li>15 Green Swamp Road Nyora,</li>
                    <li> New South Wales, </li>
                    <li>2646 Australia</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="card wow fadeInUp seller-cts">
            <h3> Contact request</h3>
            <div class="row">
              <div class="col-lg-6 col-12">
                <div class="messags-C">
                  <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                      <div class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">
                        <div class="msg-bx">
                          <div class="row">
                            <div class="col-lg-1 col-3">
                              <div class="msg-ic"><img src="assets/images/chat-02.jpg"></div>
                            </div>
                            <div class="col-lg-11 col-9">
                              <div class="msg-txt">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                              </div>
                              <div class="name-and-dt">
                                <h5><i class="fa fa-user" aria-hidden="true"></i> James Robert <span><i class="fa fa-calendar" aria-hidden="true"></i> 14 - May - 2022 </span></h5>
                              </div>
                              
                              <a href="" class="add-to-nw-bt"><i class="fa fa-plus-square-o" aria-hidden="true"></i>Add to contacts</a>
                              
                              
                              
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li class="nav-item" role="presentation">
                      <div class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">
                        <div class="msg-bx">
                          <div class="row">
                            <div class="col-lg-1 col-3">
                              <div class="msg-ic"><img src="assets/images/ld4.jpg"></div>
                            </div>
                            <div class="col-lg-11 col-9">
                              <div class="msg-txt">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                              </div>
                              <div class="name-and-dt">
                                <h5><i class="fa fa-user" aria-hidden="true"></i> James Robert <span><i class="fa fa-calendar" aria-hidden="true"></i> 14 - May - 2022 </span></h5>
                              </div>
                                                            <a href="" class="add-to-nw-bt"><i class="fa fa-plus-square-o" aria-hidden="true"></i>Add to contacts</a>

                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li class="nav-item" role="presentation">
                      <div class="nav-link" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" type="button" role="tab" aria-controls="contact" aria-selected="false">
                        <div class="msg-bx">
                          <div class="row">
                            <div class="col-lg-1 col-3">
                              <div class="msg-ic"><img src="assets/images/ld3.jpg"></div>
                            </div>
                            <div class="col-lg-11 col-9">
                              <div class="msg-txt">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                              </div>
                              <div class="name-and-dt">
                                <h5><i class="fa fa-user" aria-hidden="true"></i> James Robert <span><i class="fa fa-calendar" aria-hidden="true"></i> 14 - May - 2022 </span></h5>
                              </div>
                                                            <a href="" class="add-to-nw-bt"><i class="fa fa-plus-square-o" aria-hidden="true"></i>Add to contacts</a>

                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
                <!--<a href="#" class="view-mr-btn05">View more <i class="fa fa-long-arrow-right" aria-hidden="true"></i> </a>--> </div>
              <div class="col-lg-6 col-12">
                <div class="tab-content" id="myTabContent">
                  <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                    <section class="chat-Bx05">
                      <div>
                        <div class="row05">
                          <div class="col-12">
                            <div class="card" id="chat1">
                              <!--<div
            class="card-header d-flex justify-content-between align-items-center p-3 bg-info text-white border-bottom-0"
            >
            <i class="fa fa-angle-left"></i>
            <p class="mb-0 fw-bold">Live chat</p>
            <i class="fa fa-times"></i>
          </div>-->
                              <div class="card-body1">
                                <div class="d-flex flex-row justify-content-start mb-4">
                                  <div class="chat-img1"> <img src="assets/images/chat-02.jpg"></div>
                                  <div class="p-3 ms-3 chat-bx01">
                                    <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                                      below.</p>
                                  </div>
                                </div>
                                <div class="d-flex flex-row justify-content-end mb-4">
                                  <div class="p-3 me-3 border chat-bx02" >
                                    <p class="small mb-0">Labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                                  </div>
                                  <div class="chat-img1"> <img src="assets/images/buyer.png"></div>
                                </div>
                                <div class="d-flex flex-row justify-content-start mb-4">
                                  <div class="chat-img1"> <img src="assets/images/chat-02.jpg"></div>
                                  <div class="p-3 ms-3 chat-bx01">
                                    <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                                      below.</p>
                                  </div>
                                </div>
                                <div class="d-flex flex-row justify-content-end mb-4">
                                  <div class="p-3 me-3 border chat-bx02" >
                                    <p class="small mb-0">Labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                                  </div>
                                  <div class="chat-img1"> <img src="assets/images/buyer.png"></div>
                                </div>
                                <div class="d-flex flex-row justify-content-start mb-4">
                                  <div class="chat-img1"> <img src="assets/images/chat-02.jpg"></div>
                                  <div class="p-3 ms-3 chat-bx01">
                                    <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                                      below.</p>
                                  </div>
                                </div>
                                <div class="d-flex flex-row justify-content-end mb-4">
                                  <div class="p-3 me-3 border chat-bx02" >
                                    <p class="small mb-0">Labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                                  </div>
                                  <div class="chat-img1"> <img src="assets/images/buyer.png"></div>
                                </div>
                                <div class="form-outline">
                                  <label class="form-label" for="textAreaExample">Type your message</label>
                                  
                                  
                                  
                                  <div class="chat-text-area">
                                  
                                  <textarea class="form-control" id="textAreaExample" rows="4"></textarea>
                                  
                                  <div class="item-wrapper one">
                                    <div class="item">
                                      <form data-validation="true" action="#" method="post" enctype="multipart/form-data">
                                        <div class="item-inner">
                                          <div class="item-content">
                                            <div class="image-upload">
                                              <label style="cursor: pointer;" for="file_upload">
                                              <div class="h-100">
                                                <div class="dplay-tbl">
                                                  <div class="dplay-tbl-cell"> <i class="fa fa-paperclip" aria-hidden="true"></i>
                                                   
                                                  </div>
                                                </div>
                                              </div>
                                              <!--upload-content-->
                                              <input data-required="image" type="file" name="image_name" id="file_upload" class="image-input" data-traget-resolution="image_resolution" value="">
                                              </label>
                                            </div>
                                          </div>
                                          <!--item-content-->
                                        </div>
                                        <!--item-inner-->
                                      </form>
                                    </div>
                                    <!--item-->
                                  </div>
                                  
                                  </div>
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  
                                  <button class="cht-btn">Submit</button>
                                  
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </section>
                  </div>
                  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                    <section class="chat-Bx05">
                      <div>
                        <div class="row05">
                          <div class="col-12">
                            <div class="card" id="chat1">
                              <!--<div
            class="card-header d-flex justify-content-between align-items-center p-3 bg-info text-white border-bottom-0"
            >
            <i class="fa fa-angle-left"></i>
            <p class="mb-0 fw-bold">Live chat</p>
            <i class="fa fa-times"></i>
          </div>-->
                              <div class="card-body1">
                                <div class="d-flex flex-row justify-content-start mb-4">
                                  <div class="chat-img1"> <img src="assets/images/chat-02.jpg"></div>
                                  <div class="p-3 ms-3 chat-bx01">
                                    <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                                      below.</p>
                                  </div>
                                </div>
                                <div class="d-flex flex-row justify-content-end mb-4">
                                  <div class="p-3 me-3 border chat-bx02" >
                                    <p class="small mb-0">Labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                                  </div>
                                  <div class="chat-img1"> <img src="assets/images/buyer.png"></div>
                                </div>
                                <div class="d-flex flex-row justify-content-start mb-4">
                                  <div class="chat-img1"> <img src="assets/images/chat-02.jpg"></div>
                                  <div class="p-3 ms-3 chat-bx01">
                                    <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                                      below.</p>
                                  </div>
                                </div>
                                <div class="d-flex flex-row justify-content-end mb-4">
                                  <div class="p-3 me-3 border chat-bx02" >
                                    <p class="small mb-0">Labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                                  </div>
                                  <div class="chat-img1"> <img src="assets/images/buyer.png"></div>
                                </div>
                                <div class="d-flex flex-row justify-content-start mb-4">
                                  <div class="chat-img1"> <img src="assets/images/chat-02.jpg"></div>
                                  <div class="p-3 ms-3 chat-bx01">
                                    <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                                      below.</p>
                                  </div>
                                </div>
                                <div class="d-flex flex-row justify-content-end mb-4">
                                  <div class="p-3 me-3 border chat-bx02" >
                                    <p class="small mb-0">Labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                                  </div>
                                  <div class="chat-img1"> <img src="assets/images/buyer.png"></div>
                                </div>
                                <div class="form-outline">
                                  <label class="form-label" for="textAreaExample">Type your message</label>
                                  <textarea class="form-control" id="textAreaExample" rows="4"></textarea>
                                  <button class="cht-btn">Submit</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </section>
                  </div>
                  <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                    <section class="chat-Bx05">
                      <div>
                        <div class="row05">
                          <div class="col-12">
                            <div class="card" id="chat1">
                              <!--<div
            class="card-header d-flex justify-content-between align-items-center p-3 bg-info text-white border-bottom-0"
            >
            <i class="fa fa-angle-left"></i>
            <p class="mb-0 fw-bold">Live chat</p>
            <i class="fa fa-times"></i>
          </div>-->
                              <div class="card-body1">
                                <div class="d-flex flex-row justify-content-start mb-4">
                                  <div class="chat-img1"> <img src="assets/images/chat-02.jpg"></div>
                                  <div class="p-3 ms-3 chat-bx01">
                                    <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                                      below.</p>
                                  </div>
                                </div>
                                <div class="d-flex flex-row justify-content-end mb-4">
                                  <div class="p-3 me-3 border chat-bx02" >
                                    <p class="small mb-0">Labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                                  </div>
                                  <div class="chat-img1"> <img src="assets/images/buyer.png"></div>
                                </div>
                                <div class="d-flex flex-row justify-content-start mb-4">
                                  <div class="chat-img1"> <img src="assets/images/chat-02.jpg"></div>
                                  <div class="p-3 ms-3 chat-bx01">
                                    <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                                      below.</p>
                                  </div>
                                </div>
                                <div class="d-flex flex-row justify-content-end mb-4">
                                  <div class="p-3 me-3 border chat-bx02" >
                                    <p class="small mb-0">Labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                                  </div>
                                  <div class="chat-img1"> <img src="assets/images/buyer.png"></div>
                                </div>
                                <div class="d-flex flex-row justify-content-start mb-4">
                                  <div class="chat-img1"> <img src="assets/images/chat-02.jpg"></div>
                                  <div class="p-3 ms-3 chat-bx01">
                                    <p class="small mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut 
                                      below.</p>
                                  </div>
                                </div>
                                <div class="d-flex flex-row justify-content-end mb-4">
                                  <div class="p-3 me-3 border chat-bx02" >
                                    <p class="small mb-0">Labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris </p>
                                  </div>
                                  <div class="chat-img1"> <img src="assets/images/buyer.png"></div>
                                </div>
                                <div class="form-outline">
                                  <label class="form-label" for="textAreaExample">Type your message</label>
                                  <textarea class="form-control" id="textAreaExample" rows="4"></textarea>
                                  <button class="cht-btn">Submit</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </section>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  </div>
  </div>
</sectiion>
<?php include("footer.php")?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
<script>
var xValues = ["Italy", "France", "Spain", "USA", "Argentina"];
var yValues = [55, 49, 44, 24, 15];
var barColors = ["red", "green","blue","orange","brown"];

new Chart("myChart", {
  type: "bar",
  data: {
    labels: xValues,
    datasets: [{
      backgroundColor: barColors,
      data: yValues
    }]
  },
  options: {
    legend: {display: false},
    title: {
      display: true,
      text: "Graph Title"
    }
  }
});
</script>
