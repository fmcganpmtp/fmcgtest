<?php

namespace App\Http\Controllers\Auth;

use Carbon\Carbon; 
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Providers\RouteServiceProvider;
use App\Mail\UserCreatedMail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use Session;
use DB;
use Hash;
use App\User;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
        $this->middleware('guest:admin')->except('logout');
        $this->middleware('guest:user')->except('logout');
    }
   
    public function showAdminLoginForm()
    {
        //return view('auth.login', ['url' => 'admin']);
        return view('admin.login', ['url' => 'admin']);
    }
   
    public function adminLogin(Request $request)
    {
        $this->validate($request, [
            'email'   => 'required|email',
            'password' => 'required'
        ]);

        $remember_me = $request->has('remember') ? true : false;

        if (Auth::guard('admin')->attempt(['email' => $request->email, 'password' => $request->password], $remember_me)) {

            return redirect()->intended('/admin');
        }
        else
        {
                $user = \App\Admin::where('email', $request->email)->first();
           
                if (!empty($user) && !\Hash::check($request->password, $user->password)) 
                    return back()->withErrors(['password' => 'Wrong Password!'])->withInput(); 
                else
                    return back()->withErrors(['email' => 'Wrong User Name!'])->withInput();
        }
        
    }
    public function showUserLoginForm()
    { 
        return view('auth.login', ['url' => 'user']);
    }

    public function userLogin(Request $request)
    {
        
        
        $this->validate($request, [
            'email'   => 'required|email',
            'password' => 'required'
        ]);

        if (Auth::guard('user')->attempt(['email' => $request->email, 'password' => $request->password], $request->get('remember'))) {                                                
                
        }
        $user = \App\User::where('email', $request->email)->first();
   
        if (!empty($user) && !\Hash::check($request->password, $user->password)) 
            return back()->withErrors(['password' => 'Invalid Password!']); 
        else
            return back()->withErrors(['email' => 'This E-Mail Address is not Registered!']);

  }

    public function showForgetPasswordForm() {
        return view('auth.passwords.forgot-password');
    }

    public function submitForgetPasswordForm(Request $request)
      {
          $token = Str::random(64); 
          $request->validate([
              'email' => 'required|email|exists:users',
          ]);
  
         
          
          $query =  DB::table('password_resets')->insert([
              'email' => $request->email, 
              'token' => $token, 
              'created_at' => Carbon::now()
            ]);
           
  
          Mail::send('emails.forgetPassword', ['token' => $token], function($message) use($request){
              $message->to($request->email);
              $message->subject('Reset Password - FMCG');
          });

          //Mail::to($request->email)->send(new UserCreatedMail($request));
  
          return back()->with('message', 'We have e-mailed your password reset link!');
      }
      public function showResetPasswordForm($token) { 
        return view('auth.passwords.forgetPasswordLink', ['token' => $token]);
     }
     public function submitResetPasswordForm(Request $request)
      {
          $request->validate([
              'email' => 'required|email|exists:users',
              'password' => 'required|string|min:6|confirmed',
              'password_confirmation' => 'required'
          ]);
  
          $updatePassword = DB::table('password_resets')
                              ->where([
                                'email' => $request->email, 
                                'token' => $request->token
                              ])
                              ->first();
  
          if(!$updatePassword){
              return back()->withInput()->with('error', 'Invalid token!');
          }
  
          $user = User::where('email', $request->email)
                      ->update(['password' => Hash::make($request->password)]);
 
          DB::table('password_resets')->where(['email'=> $request->email])->delete();
  
          return redirect()->route('user-login')->with('message', 'Your password has been changed!');
      }
    //   public function logout() {
    //     Session()->flush();
    //      return redirect()->route('admin.login')->with('message','Login is Invalid');
    //    }
       
       public function logout( Request $request )
{
    if(Auth::guard('admin')->check()) // this means that the admin was logged in.
    {
        Auth::guard('admin')->logout();
        return redirect()->route('admin.login.form');
    }

    $this->guard()->logout();
    $request->session()->invalidate();

    return $this->loggedOut($request) ?: redirect('/');
}
}
