<?php

namespace App\Http\Controllers\Auth;
use App\User;
use App\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Auth;
use App\Models\OrderDetail;
class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
        $this->middleware('guest:admin');
        $this->middleware('guest:user');
    }
    public function showAdminRegisterForm()
    {
        return view('auth.register', ['url' => 'admin']);
    }

    public function showUserRegisterForm()
    {
        return view('auth.register', ['url' => 'user']);
    }
    protected function createAdmin(Request $request)
    {
        request()->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:admins'],
            'username' => ['required', 'string',  'max:255', 'unique:admins'],
            'phone' => ['required', 'unique:admins'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'image' =>  'mimes:jpeg,jpg,png,gif,webp',
        ]);
        $admin = Admin::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'username' => $request['username'],
            'phone' => $request['phone'],
            'about' => $request['about'],
            'profile_pic' => $request['profile_pic'],
            'password' => Hash::make($request['password']),
        ]);
        return redirect()->intended('login/admin');
    }
    protected function createUser(Request $request)
    {   
        request()->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'surname' => ['required', 'string',  'max:255'],
            'phone' => ['required','regex:/^(^([+]+)(\d+)?$)$/', 'unique:users'],
            //'full'      => 'required|regex:/^(^([+]+)(\d+)?$)$/ ',
            //'position' => ['required'],
            // 'agree' => ['required'],
            // 'agree_privacy_policy' => ['required'],
            //'password' => ['required', 'string', 'min:8', 'confirmed']
            'password' => [
                'required',
                'string',
                'min:8', 'confirmed',         // must be at least 10 characters in length
                'regex:/[a-z]/',      // must contain at least one lowercase letter
                'regex:/[A-Z]/',      // must contain at least one uppercase letter
                'regex:/[0-9]/',      // must contain at least one digit
                'regex:/[@$!%*#?&]/', // must contain a special character
            ],
        ]);

     
        $input = [
            'name' => $request->get('name'),
            'surname' => $request->get('surname'),
            'position' => $request->get('position'),
            'email' => $request->get('email'),
            //'username' => $request->get('username'),
            'phone' => $request->get('phone'),
            'password' => Hash::make($request->get('password')),
        ];  //dd($input);
        if(request()->hasFile('image')) {
            $extension = request('image')->extension();
            $fileName = "user_pic".time().'.'.$extension;
            $destinationPath = public_path().'/uploads/userImages' ;
            request('image')->move($destinationPath,$fileName);
            $input['profile_pic'] = $fileName;
        } 
        $password = Hash::make($request->get('password'));
        $email = $request->get('email');
        $user_id = User::create( $input )->id; 
        $post = array('password' => $password, 'email' => $email); 
        Auth::guard('user')->loginUsingId($user_id);
        $id = Auth::guard('user')->user()->id;
        $user =OrderDetail::where('user_id',$id)->first(); //dd($user);
        if(!empty($user))
        return redirect(route('home')); 
        else
        return redirect(route('package.listing'));
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {  request()->validate([
        'name' => ['required', 'string', 'max:255'],
        'surname' => ['required', 'string', 'max:255'],
        'position' => ['required', 'string', 'max:255'],
        'email' => ['required', 'string', 'email', 'max:255', 'unique:admins'],
        'phone' => ['required', 'max:13', 'unique:admins'],
        'password' => ['required', 'string', 'min:8', 'confirmed'],
    ]);
        $input = [
            'name' => $request->get('name'),
            'surname' => $request->get('surname'),
            'position' => $request->get('position'),
            'email' => $request->get('email'),
            'username' => $request->get('username'),
            'phone' => $request->get('phone'),
            'about' => $request->get('about'),
            'adminrole' => $request->get('adminrole'),
            'password' => Hash::make($request->get('password')),
        ];
        if(request()->hasFile('image')) {
            $extension = request('image')->extension();
            $fileName = "user_pic".time().'.'.$extension;
            $destinationPath = public_path().'/uploads/userImages' ;
            request('image')->move($destinationPath,$fileName);
            $input['profile_pic'] = $fileName;
        } 
        $password = Hash::make($request->get('password'));
        $email = $request->get('email');
        $user_id = User::create( $input )->id;
        $post = array('password' => $password, 'email' => $email);
        Auth::guard('user')->loginUsingId($user_id);
        return redirect()->route('home'); 
    }
}
