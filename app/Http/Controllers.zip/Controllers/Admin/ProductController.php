<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\ProductImage;
use App\Models\Product;
use App\User;
use App\Models\Country;
use App\Models\Category;
use App\Models\Productbrand;
use App\Models\SellerProduct;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Excel as ExcelExcel;
use Illuminate\Validation\Rule;
use File;
use DB;
use App\Imports\SellerProductImport;
use App\Imports\AdminProductImport;


class ProductController extends Controller
{
    public function listProducts(Request $request) {

        $category_id=$request->get('category_id');
    
        $search_key=$request->get('search_key');
        $stock=$request->get('stock');
        
        $categories = Category::where('parent_id', null)->get();
        
    
         return view('admin.products.listproducts',compact('categories','category_id','search_key','stock'));
    }


    public function listSellerProducts(Request $request) {

        $category_id=$request->get('category_id');
    
        $search_key=$request->get('search_key');
        $stock=$request->get('stock');
        
        $categories = Category::where('parent_id', null)->get();
        
    
         return view('admin.products.listSellerproducts',compact('categories','category_id','search_key','stock'));
    }

    public function uploadcsvfile() {

        $sellers_list=User::where('usertype','seller')->get();
         return view('admin.products.uploadcsv',compact('sellers_list'));
    }

    public function import( Request $request) 
    {
        $seller_id=$request->seller_id;
        $result = Excel::import(new SellerProductImport($seller_id),request()->file('sellerfile'));
         
        return back()->withInput()->with('success', 'Products Imported Successfully.');
    }

    public function adminimport( Request $request) 
    {
       
        $result = Excel::import(new AdminProductImport,request()->file('file'));
         
        return back()->withInput()->with('success', 'Products Imported Successfully.');
    }
 

      public function getproductlist(Request $request)
    {  
         
        $columnIndex_arr = $request->get('order');
        $columnName_arr = $request->get('columns');
        $order_arr = $request->get('order');
        $search_arr = $request->get('search');
       
                $draw = $request->get('draw');
                $start = $request->get("start");
                $rowperpage = $request->get("length"); // total number of rows per page
                $columnIndex = $columnIndex_arr[0]['column']; // Column index
                $columnName = $columnName_arr[$columnIndex]['data']; // Column name
                $columnSortOrder = $order_arr[0]['dir']; // asc or desc
               // $searchValue = $search_arr['value']; // Search value
     
        $totalRecords = Product::select('count(*) as allcount')->count();
        $totalRecordswithFilter = Product::select('count(*) as allcount') 
        ->where(function ($query) use($request){

         if($request->get('search_key') !=""){
            $query->where('name','Like','%'.$request->get('search_key').'%');
        }
        if($request->get('category_id') !=null){
             $query->whereRaw('find_in_set("'.$request->get('category_id').'",category_id)');
        }
                        
        if($request->get('stock') !=null){
                            if($request->get('stock')=="instock")
                                $query->where("stock_count",">",0);
                            else
                                $query-> where("stock_count","<=",0);
         }})->count();

       

        // Get records, also we have included search filter as well
        $records = Product::select('*')->where(function ($query) use($request){

         if($request->get('search_key') !=""){
            $query->where('name','Like','%'.$request->get('search_key').'%');
        }
        if($request->get('category_id') !=null){
              $query->whereRaw('find_in_set("'.$request->get('category_id').'",category_id)');
        }
                        
        if($request->get('stock') !=null){
                    if($request->get('stock')=="instock")
                          $query->where("stock_count",">",0);
                    else
                            $query->where("stock_count","<=",0);
         }
     })->orderBy($columnName,$columnSortOrder)
            ->skip($start)
            ->take($rowperpage)
            ->get();
        $data_arr = array();
       
        foreach ($records as $record) {
             $strcat='';
             $Categories = explode(",",$record->category_id);
                        foreach($Categories as $item)
                            $strcat.= Category::where('id',$item)->pluck('name')->first()."<br/>";
                                  
              $strimg='';                    
              foreach( $record->ProductImages as $productimage)
               {     
                        if($productimage->thumbnail == 'yes') 
                           $strimg.= '<div class="table-prof"><img style=" width:60px !important;" class="pr_img" src="'.asset("/uploads/productImages/").'/'.$productimage->image_path.' "></div>';
               }         
                                                                                        
            $start=$start+1;
            $data_arr[] = array(  
                "id" => $record->id,
                "name" => $record->name,
                "company_name" => $record->company_name,
                "location" => $record->location,
                "product_price" => $record->product_price,
                "strcat" => $strcat,
                "strimg" => $strimg,
               );
        }

        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecordswithFilter,
            "aaData" => $data_arr,
        );
        echo json_encode($response);       
}

public function getSellerProductlist(Request $request)
    {  
         
        $columnIndex_arr = $request->get('order');
        $columnName_arr = $request->get('columns');
        $order_arr = $request->get('order');
        $search_arr = $request->get('search');
       
                $draw = $request->get('draw');
                $start = $request->get("start");
                $rowperpage = $request->get("length"); // total number of rows per page
                $columnIndex = $columnIndex_arr[0]['column']; // Column index
                $columnName = $columnName_arr[$columnIndex]['data']; // Column name
                $columnSortOrder = $order_arr[0]['dir']; // asc or desc
               // $searchValue = $search_arr['value']; // Search value
     
        $totalRecords = SellerProduct::leftJoin('users', 'users.id', '=', 'seller_products.user_id')
        ->select('count(*) as allcount')->where('users.status','<>','Deleted')->where('seller_products.status','!=','deleted')->count();
        $totalRecordswithFilter = SellerProduct::leftJoin('users', 'users.id', '=', 'seller_products.user_id')->select('count(*) as allcount')->where('users.status','<>','Deleted') ->where('seller_products.status','!=','deleted')
        ->where(function ($query) use($request){

         if($request->get('search_key') !=""){
            $query->where('name','Like','%'.$request->get('search_key').'%');
        }
        if($request->get('category_id') !=null){
             $query->whereRaw('find_in_set("'.$request->get('category_id').'",category_id)');
        }
                        
        if($request->get('stock') !=null){
                            if($request->get('stock')=="instock")
                                $query->where("stock_count",">",0);
                            else
                                $query-> where("stock_count","<=",0);
         }})->count();

       

        // Get records, also we have included search filter as well
        $records = SellerProduct::leftJoin('users', 'users.id', '=', 'seller_products.user_id')
        ->select('seller_products.*')->where('users.status','<>','Deleted')->where('seller_products.status','!=','deleted')->where(function ($query) use($request){

         if($request->get('search_key') !=""){
            $query->where('name','Like','%'.$request->get('search_key').'%');
        }
        if($request->get('category_id') !=null){
              $query->whereRaw('find_in_set("'.$request->get('category_id').'",category_id)');
        }
                        
        if($request->get('stock') !=null){
                    if($request->get('stock')=="instock")
                          $query->where("stock_count",">",0);
                    else
                            $query->where("stock_count","<=",0);
         }
     })->orderBy($columnName,$columnSortOrder)
            ->skip($start)
            ->take($rowperpage)
            ->get();
        $data_arr = array();
       
        foreach ($records as $record) {
             $strcat='';
             $Categories = explode(",",$record->category_id);
                        foreach($Categories as $item)
                            $strcat.= Category::where('id',$item)->pluck('name')->first()."<br/>";
                                  
              $strimg='';                    
              foreach( $record->SellerProductImage as $productimage)
               {     
                        if($productimage->thumbnail == 'yes') 
                           $strimg.= '<div class="table-prof"><img style=" width:60px !important;" class="pr_img" src="'.asset("/uploads/productImages/").'/'.$productimage->image_path.' "></div>';
               }         
                  $seller = User::find($record->user_id)  ;                                                                    
            $start=$start+1;
            $data_arr[] = array(  
                "id" => $record->id,
                "name" => $record->name,
                "company_name" =>  $seller->BuyerCompany->company_name??"",
                "location" => $seller->BuyerCompany->company_location ?? "",
                "product_price" => $record->product_price,
                "strcat" => $strcat,
                "strimg" => $strimg,
               );
        }

        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecordswithFilter,
            "aaData" => $data_arr,
        );
        echo json_encode($response);       
}




    public function createProduct()
    {   
        $categories = Category::where('parent_id', null)->get();
        $Productbrand = Productbrand::get();
        return view('admin.products.addproduct',compact('categories','Productbrand'));
    }
    
    public function availbleCountries(request $request) {
        $countries = Country::where('name','Like',$request->term.'%')
        ->select("id","name")
        ->limit(10)
        ->get();
        return $countries;
    

}

public function autoComplateSeller(request $request) {
    $user = User::where('name','Like',$request->name.'%')
    ->select("id","name")
    ->where('usertype','seller')
    ->limit(20)
    ->get();
    $output=[];
    foreach($user as $data){
        $array = ['id' => $data->id, 'name'  =>  $data->name];
         $output[]=$array;
    }
 
        
      return json_encode($output);
}
    
    public function autoComplateProduct(request $request) {
        $products = Product::where('name','Like',$request->term.'%')
        ->select("id","name")
        ->limit(10)
        ->get();
        return $products;
        

    }

    public function autoComplateSProduct(request $request) {
        $products = SellerProduct::where('status','active')->where('name','Like',$request->term.'%')
        ->select("id","name")
        ->limit(10)
        ->get();
        return $products;
        

    }
    public function saveProduct(Request $request){
        
       
        request()->validate([
            'name' => ['required', 'string', 'unique:products'],
            'product_price' => ['required', 'numeric'],
            'SKU' => ['required', 'string', 'unique:products'],    
        ]);

       




        $available_countries = $category_id = $variants = "";
        if(!empty($request->input('available_countries'))) {
        $available_countries  = $request->input('available_countries');
        $available_countries=implode(",",$available_countries);
        }
        if(!empty($request->input('category_id'))) {
        $category_id = $request->input('category_id');
        $category_id = implode(",",$category_id);
        }
        if(!empty($request->input('variants'))) {
        $variants = $request->input('variants');
        $variants = implode(",",$variants);
        }
        $input = $request->all();
        
        $input['available_countries'] = $available_countries;
        $input['category_id']=$category_id;
        $input['variants']=$variants;
        
        $id = Product::create($input)->id;

        if($request->hasFile("product_image")){
            $file=$request->file("product_image");
            $fileName=time().'_'.$file->getClientOriginalName();
            $destinationPath = public_path().'/uploads/productImages' ;
            $file->move($destinationPath,$fileName);
            $img['image_path'] = $fileName;
            $img['thumbnail'] = "yes";
            $img['product_id'] = $id ;
            ProductImage::create($img);

        }

            if($request->hasFile("product_gallery")){
                $files=$request->file("product_gallery");
                foreach($files as $file){
                    $imageName=time().'_'.$file->getClientOriginalName();
                    $img['product_id']=$id;
                    $img['thumbnail'] = "no";
                    $img['image_path']=$imageName;
                    $destinationPath = public_path().'/uploads/productImages' ;
                    $file->move($destinationPath,$imageName);
                    ProductImage::create($img);

                }
            }
       
        return redirect()->route('list-products')->with('success','Category has been created successfully.');
       }
      public function editProduct($productId) {
        
        $product = Product::find($productId);
        $varients = Product::all();
        $countries = Country::all();
        $product_images= ProductImage::find($productId); 
        $product_images = ProductImage::where('product_id','=',$productId)->get();
        $categories = Category::where('parent_id', null)->get();
        $Productbrand = Productbrand::get();
        if(empty($productId )) 
        return redirect() ->route('admin.products.listproducts')->with('message','Product not exists');
        return view('admin.products.edit-product' ,compact('product','categories','varients','countries','product_images','Productbrand'));
    
    }

    

    public function updateProduct(Request $request) {
        
        request()->validate([
            'name' => ['required', 'string',Rule::unique('products')->ignore($request->get('id'))],
            'product_price' => ['required', 'numeric'],
            'SKU' => ['required', 'string',Rule::unique('products')->ignore($request->get('id'))],
            
        ]);
        $productId = $request->get('id');
        $product = Product::find($productId);
       
        $available_countries = $category_id = $variants = "";
        if(!empty($request->input('available_countries'))) {
        $available_countries  = $request->input('available_countries');
        $available_countries=implode(",",$available_countries);
        }
        if(!empty($request->input('category_id'))) {
        $category_id = $request->input('category_id');
        $category_id = implode(",",$category_id);
        }
        if(!empty($request->input('variants'))) {
        $variants = $request->input('variants');
        $variants = implode(",",$variants);
        }
        $input = $request->all();
        
        $input['available_countries'] = $available_countries;
        $input['category_id']=$category_id;
        $input['variants']=$variants;

        if($request->hasFile("product_image")){ 
            $file=$request->file("product_image");
            $fileName=time().'_'.$file->getClientOriginalName();
            $destinationPath = public_path().'/uploads/productImages' ;
            $file->move($destinationPath,$fileName);
            $img['image_path'] = $fileName;
            $img['thumbnail'] = "yes";
            $img['product_id'] = $productId ;
            DB::table('product_images')->where([
                ['product_id', '=', $productId],
                ['thumbnail', '=', 'yes'],
            ])->delete();
            ProductImage::create($img);

        }

            if($request->hasFile("product_gallery")){
                $files=$request->file("product_gallery");
                foreach($files as $file){
                    $imageName=time().'_'.$file->getClientOriginalName();
                    $img['product_id']=$productId;
                    $img['thumbnail'] = "no";
                    $img['image_path']=$imageName;
                    $destinationPath = public_path().'/uploads/productImages' ;
                    $file->move($destinationPath,$imageName);
                    ProductImage::create($img);

                }
            }
      
        $product->update($input);
        return redirect()->route('list-products')->with('message','Product Updated');
    }

    public function viewProduct($productId){
        $product = Product::find($productId); 
        $categories = Category::where('parent_id', null)->get();
        $country_ids = explode(',',$product->available_countries);
        $countries = Country::whereIn('id',$country_ids)->pluck('name');
        
          if(empty($product)) {
                return redirect()->route('product.list')->with('message','No Product Found');
            } 
          return view('admin/products/view-product',compact('product','countries','categories'));  
        }

        public function viewSellerProduct($productId){
            $product = SellerProduct::find($productId); 
            $categories = Category::where('parent_id', null)->get();
            $country_ids = explode(',',$product->available_countries);
            $countries = Country::whereIn('id',$country_ids)->pluck('name');
            
              if(empty($product)) {
                    return redirect()->route('product.list')->with('message','No Product Found');
                } 
              return view('admin/products/view-SellerProduct',compact('product','countries','categories'));  
            }
	
	 public function deleteimage(Request $request){ 
        $id=$request->get('id');
        $images=ProductImage::findOrFail($id);
        if (File::exists("/uploads/productImages/".$images->image_path)) {
           File::delete("/uploads/productImages/".$images->image_path);
       }

       $output=ProductImage::find($id)->delete();
       return json_encode($output);
   }

   public function deleteProduct($productId)
    {
        $product=  Product::find($productId);
        if(empty($product)){ 
            return redirect()->route('list-products')->with('message', 'Product not Exists');
        }

        $productImages =  ProductImage::where('product_id','=',$product->id)->get();      
        if(!empty($productImages)){
            foreach($productImages as $productImage)
            {
                $path = public_path()."/uploads/productImages/".$productImage->image_path;             
                unlink($path );               
            }
        
        }
        
        $product->delete();
        return redirect()->route('list-products')->with('message', 'Product Deleted!');
    }


    public function deleteSellerProduct($productId)
    {
        $product=  SellerProduct::find($productId);
        if(empty($product)){ 
            return redirect()->route('list-products')->with('message', 'Product not Exists');
        }

       
        
        
        $product->update(['status'=>'deleted']);
        return redirect()->route('list-Sellerproducts')->with('message', 'Product Deleted!');
    }
    
}
