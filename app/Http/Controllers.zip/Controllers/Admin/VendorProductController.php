<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Admin;
use DB;
use File;
use App\Models\SellerProduct;
use App\Models\SellerProductImage;
use App\Models\Category;
use App\Models\Country;
use App\Models\Productbrand;
use App\User;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Cookie\Middleware\EncryptCookies as Middleware;

class VendorProductController extends Controller
{
    
    public function listVendorProduct() {

        $categories = Category::where('parent_id', null)->get();
        $User = User::where('usertype','seller')->get();
        $Country = Country::get();
        return view('admin.vendor_product.vendor_product_list',compact('categories','User','Country'));
    }

    public function getvendorproductlist(Request $request)
    {  
        
        $columnIndex_arr = $request->get('order');
        $columnName_arr = $request->get('columns');
        $order_arr = $request->get('order');
        $search_arr = $request->get('search');
      
                $draw = $request->get('draw');
                $start = $request->get("start");
                $rowperpage = $request->get("length"); // total number of rows per page
                $columnIndex = $columnIndex_arr[0]['column']; // Column index
                $columnName = $columnName_arr[$columnIndex]['data']; // Column name
                $columnSortOrder = $order_arr[0]['dir']; // asc or desc
               // $searchValue = $search_arr['value']; // Search value
        $searchValue=$request->get('search_key');
        $category_id=$request->get('category_id');
        $country_id=$request->get('country_id');
        $user_id=$request->get('user_id');

        $totalRecords =DB::table('seller_products')->leftJoin('users', 'users.id', '=', 'seller_products.user_id')
        ->select('count(*) as allcount')->where('users.status','<>','Deleted')
        ->where('seller_products.status','!=','deleted')->count();

        $totalRecordswithFilter = DB::table('seller_products')  
        ->leftJoin('users', 'users.id' ,"=" ,'seller_products.user_id')
        ->select('count(*) as allcount')
        // ->where('admins.id', '!=', Auth::guard('admin')->user()->id)
         ->where('seller_products.name', 'like', '%' . $searchValue . '%')
         ->where('seller_products.status','!=','deleted')
         ->where('users.status','<>','Deleted')
        ->where(function ($query) use($country_id){
         if($country_id !=""){
            $query->where('users.country_id',$country_id);
        }})
        ->where(function ($query) use($user_id){
         if($user_id !=""){
            $query->where('users.id',$user_id);
        }})
        ->where(function ($query) use($category_id){
         if($category_id !=""){
           $query->whereRaw('find_in_set("'.$category_id.'",category_id)');
        }})    
              
        ->count();
        
        // Get records, also we have included search filter as well
        $records = SellerProduct::leftJoin('users', 'users.id' ,"=" ,'seller_products.user_id')
        ->select('seller_products.*','users.name as sellername','users.store_name')
            ->orderBy($columnName,$columnSortOrder)
            ->where('seller_products.status','!=','deleted')
            ->where('users.status','<>','Deleted')
        ->where('seller_products.name', 'like', '%' . $searchValue . '%')
        ->where(function ($query) use($country_id){
         if($country_id !=""){
            $query->where('users.country_id',$country_id);
        }})
        ->where(function ($query) use($user_id){
         if($user_id !=""){
            $query->where('users.id',$user_id);
        }})
        ->where(function ($query) use($category_id){
         if($category_id !=""){
           $query->whereRaw('find_in_set("'.$category_id.'",category_id)');
        }})    
        ->skip($start)
        ->take($rowperpage)
        ->get();
        $data_arr = array();
       

        foreach ($records as $record) {
               $strimg= '<div class="table-prof"><img style=" width:60px !important;" class="pr_img" src="'.asset("/uploads/defaultImages/no_image.jpg").'"></div>';
             foreach( $record->SellerProductImage as $productimage)
               {     
                        if($productimage->thumbnail == 'yes') 
                           $strimg= '<div class="table-prof"><img style=" width:60px !important;" class="pr_img" src="'.asset("/uploads/productImages/").'/'.$productimage->image_path.' "></div>';
               }


         $status = (
                ($record->status=='pending' || $record->status=='') ? '<span style="color:white;background-color:red;padding:5px;line-height:12px;border-radius:2px;margin-top:5px;display:inline-block;">Pending</span>':
                (($record->status=='active') ? '<span style="color:white;background-color:green;padding:5px;line-height:12px;border-radius:2px;margin-top:5px;display:inline-block;">'.$record->status.'</span>' :
                (($record->status=='rejected') ?'<span style="color:white;background-color:orange;padding:5px;line-height:12px;border-radius:2px;margin-top:5px;display:inline-block;">'.$record->status.'</span>' :
                '')));      

           
           
            $data_arr[] = array(
                "id" => $record->id,
                "profile_pic" => $strimg,
                "name" => $record->name. '<br>'.$status,
                "store_name" => $record->store_name,
                "sellername" => $record->sellername
                
                
               );
        }

        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecordswithFilter,
            "aaData" => $data_arr,
        );
        echo json_encode($response);       
}


 public function viewProduct($productId){
        $product = SellerProduct::find($productId); 
        $company_info = User::find($product->user_id);
        $categories = Category::where('parent_id', null)->get();
        $country_ids = explode(',',$product->available_countries);
        $countries = Country::whereIn('id',$country_ids)->pluck('name');
        
        if(empty($product)) 
                return redirect()->route('admin.listVendorProduct')->with('message','No Product Found');
            
        return view('admin/vendor_product/view-vendor-product',compact('product','countries','categories','company_info'));  
        }
     public function deleteimage($id){ 

        $images=SellerProductImage::findOrFail($id);
        if (File::exists("/uploads/productImages/".$images->image_path)) {
           File::delete("/uploads/productImages/".$images->image_path);
       }

       SellerProductImage::find($id)->delete();
       return back();
   }


   public function editProduct($productId) {
        
        $product = SellerProduct::find($productId);
        $varients = SellerProduct::all();
        $countries = Country::all(); 
        $product_images = SellerProductImage::where('product_id','=',$productId)->get();
        $categories = Category::where('parent_id', null)->get();

        $Productbrand = Productbrand::get();

        if(empty($productId )) 
            return redirect() ->route('admin.listVendorProduct')->with('message','Product not exists');

        return view('admin/vendor_product/edit-vendor-product' ,compact('product','categories','varients','countries','product_images','Productbrand'));
    
    }

    
  public function vendorproductapproval(Request $request)
    {
        $seller_products=$request->get('seller_products');
        $status=$request->get('status');

        foreach($seller_products as $item){
            $SellerProduct=SellerProduct::find($item);
            $SellerProduct->status =$status;
            $SellerProduct->save();
        }
           echo json_encode("Status Changed");
    }    
 
   public function updateProduct(Request $request) {
        
        request()->validate([
            'name' => ['required', 'string'],
            'product_price' => ['required', 'numeric'],
            'SKU' => ['required', 'string',Rule::unique('seller_products')->ignore($request->id)],
            
        ]);
        $productId = $request->get('id');
        $product = SellerProduct::find($productId);
       
        $available_countries = $category_id = $variants = "";
        if(!empty($request->input('available_countries'))) {
        $available_countries  = $request->input('available_countries');
        $available_countries=implode(",",$available_countries);
        }
        if(!empty($request->input('category_id'))) {
        $category_id = $request->input('category_id');
        $category_id = implode(",",$category_id);
        }
        if(!empty($request->input('variants'))) {
        $variants = $request->input('variants');
        $variants = implode(",",$variants);
        }
        $input = $request->all();
        
        $input['available_countries'] = $available_countries;
        $input['category_id']=$category_id;
        $input['variants']=$variants;

        if($request->hasFile("product_image")){ 
            $file=$request->file("product_image");
            $fileName=time().'_'.$file->getClientOriginalName();
            $destinationPath = public_path().'/uploads/productImages' ;
            $file->move($destinationPath,$fileName);
            $img['image_path'] = $fileName;
            $img['thumbnail'] = "yes";
            $img['product_id'] = $productId ;
            DB::table('seller_product_images')->where([
                ['product_id', '=', $productId],
                ['thumbnail', '=', 'yes'],
            ])->delete();
            SellerProductImage::create($img);

        }

            if($request->hasFile("product_gallery")){
                $files=$request->file("product_gallery");
                foreach($files as $file){
                    $imageName=time().'_'.$file->getClientOriginalName();
                    $img['product_id']=$productId;
                    $img['thumbnail'] = "no";
                    $img['image_path']=$imageName;
                    $destinationPath = public_path().'/uploads/productImages' ;
                    $file->move($destinationPath,$imageName);
                    SellerProductImage::create($img);

                }
            }
       
        $product->update($input);
        return redirect()->route('admin.listVendorProduct')->with('message','Product Updated');
    }


     public function deleteProduct($productId)
    {
        $product=  SellerProduct::find($productId);
        if(empty($product)){ 
            return redirect()->route('admin.listVendorProduct')->with('message', 'Product not Exists');
        }

        $productImages =  SellerProductImage::where('product_id','=',$product->id)->get();      
        if(!empty($productImages)){
            foreach($productImages as $productImage)
            {
                $path = public_path()."/uploads/productImages/".$productImage->image_path;             
                unlink($path );               
            }
        
        }
        
        $product->delete();
        return redirect()->route('admin.listVendorProduct')->with('message', 'Product Deleted!');
    }
  

}
