<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use DB;
use App\Models\ProfileAccountDeleteRequest;
use App\User;
use Illuminate\Http\Request;

class RequestDeleteController extends Controller
{


    public function __construct()
    {
        $this->middleware('auth:admin');
    }

   
    public function index(Request $request) {

        return view('admin.account_request_delete.request_delete');

    } 
    public function adminprofiledelete (Request $request)
    {
        $status=$request->get('status');
        $id=$request->get('id');
        $requestdelete=  ProfileAccountDeleteRequest::find($id);
        $requestdelete->status =$status;
        $requestdelete->save();


        if($status=='Deleted')
        {
                $User=  User::find($requestdelete->user_id);
                $User->status ='Deleted';
                $update=$User->save();
        }
        
        echo json_encode("Status Changed");
    } 
     
 
    public function getrequestdeletelist(Request $request)
    {  
        
        $columnIndex_arr = $request->get('order');
        $columnName_arr = $request->get('columns');
        $order_arr = $request->get('order');
        $search_arr = $request->get('search');
      
                $draw = $request->get('draw');
                $start = $request->get("start");
                $rowperpage = $request->get("length"); // total number of rows per page
                $columnIndex = $columnIndex_arr[0]['column']; // Column index
                $columnName = $columnName_arr[$columnIndex]['data']; // Column name
                $columnSortOrder = $order_arr[0]['dir']; // asc or desc
             
        $searchValue=$request->get('search_key');
        $status=$request->get('status');
        $totalRecords =ProfileAccountDeleteRequest::select('count(*) as allcount')
        ->when($request->get('status')!='', function ($query) use ($request) {
                $query->where('status',$request->get('status'));
        })->count();
        
        $totalRecordswithFilter = ProfileAccountDeleteRequest::leftJoin('users', 'profile_account_delete_requests.user_id', '=', 'users.id')
          ->leftJoin('buyer_companies', 'buyer_companies.user_id', '=', 'users.id')
          ->when($request->get('status')!='', function ($query) use ($request) {
                $query->where('profile_account_delete_requests.status',$request->get('status'));
            })

        ->when($searchValue!='', function ($query) use ($searchValue) {
            $query->where(DB::raw('CONCAT_WS(users.name,email,phone,buyer_companies.company_name)'), 'LIKE','%'.$searchValue.'%');
          })
        ->count();       

        // Get records, also we have included search filter as well
        $records = ProfileAccountDeleteRequest::leftJoin('users', 'profile_account_delete_requests.user_id', '=', 'users.id')
          ->leftJoin('buyer_companies', 'buyer_companies.user_id', '=', 'users.id')
          ->select('users.*','buyer_companies.company_name','profile_account_delete_requests.status as reqstatus','profile_account_delete_requests.reason','profile_account_delete_requests.created_at' ,'profile_account_delete_requests.id as req_id')  
        ->when($request->get('status')!='', function ($query) use ($request) {
            $query->where('profile_account_delete_requests.status',$request->get('status'));
        })
        ->when($searchValue!='', function ($query) use ($searchValue) {
            $query->where(DB::raw('CONCAT_WS(users.name,email,phone,buyer_companies.company_name)'), 'LIKE','%'.$searchValue.'%');
        })
         ->orderBy($columnName,$columnSortOrder) 
            
        ->skip($start)
        ->take($rowperpage)
        ->get();
        $data_arr = array();
           
        foreach ($records as $record) {


            $data_arr[] = array(
                "id" => $record->req_id,
                "name" =>$record->name, 
                "company_name" => $record->company_name,
                "phone" => $record->phone,
                "email" => $record->email,
                "reason" => $record->reason,
                'reqstatus'=>$record->reqstatus,
                'created_at' => date('d-m-Y', strtotime($record->created_at))
               );
             
         }

        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecordswithFilter,
            "aaData" => $data_arr,
        );
        echo json_encode($response);       
    }


  
	
	
}
