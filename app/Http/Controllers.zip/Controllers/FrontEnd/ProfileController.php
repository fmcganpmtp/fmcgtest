<?php

namespace App\Http\Controllers\FrontEnd;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use DB;
use App\Models\BuyerCompany;
use App\Models\SellerOpeningTime;
use App\Models\OrderDetail;
use App\Models\Country;
use App\Models\BusinessInsight;
use App\Models\KycFile;
use App\Models\Subscription;
use App\Models\SellerMessage;
use App\Models\Category;
use App\Models\Mynetworks;
use App\Models\Message;
use App\Models\SellerProduct;
use App\Models\SellerProductImage;
use Illuminate\Support\Facades\Hash;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\FrontEnd\PublicMiddlewareController;
use Carbon\Carbon;

class ProfileController extends Controller
{

    protected $PublicMiddlewareController;
    public function __construct(PublicMiddlewareController $PublicMiddlewareController)
    {
        $this->PublicMiddlewareController = $PublicMiddlewareController;
    }

    public function CreateSellerProfile(){


       if(Auth::guard('user')->check())
       {

         if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }
        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
       }

      
       
        $user_id = Auth::guard('user')->user()->id;
        $user = User::find($user_id);
        $countries =Country::select('id','name')->get();
        $usertype = Auth::guard('user')->user()->usertype;

        if($usertype!="seller") //if not seller redirect to home
        return redirect()->route('home');
        return view('frontEnd.profile-creation.CreateSeller',compact('user','countries'));
    }
   
    public function SendKYCMail(Request $request)
    {   
        $token = Str::random(60).Auth::guard('user')->user()->id.date('Ymdss');   
        $user_id = Auth::guard('user')->user()->id;
         DB::table('users') ->where('id', $user_id)->update(['token_number'=>$token]);
      

        Mail::send('emails.KYCApprovalMailTemplate', ['token' => $token,'user_id' =>Auth::guard('user')->user()->id], function($message) use($request){
            $email = Auth::guard('user')->user()->email; 
        $message->to($email);
        $message->subject('Verify Email - FMCG');
    });
     return back()->with('message', 'Verfication Mail has Been Send to your Email!');
}


public function sendBuyerApprovalMail(Request $request)
{   
    $token = Str::random(60).Auth::guard('user')->user()->id.date('Ymdss');   
    $user_id = Auth::guard('user')->user()->id;
     DB::table('users') ->where('id', $user_id)->update(['token_number'=>$token]);
  

    Mail::send('emails.BuyerApprovalMail', ['token' => $token,'user_id' =>Auth::guard('user')->user()->id], function($message) use($request){
    $email = Auth::guard('user')->user()->email; 
    $message->to($email);
    $message->subject('Verify Email - FMCG');
});
 return back()->with('message', 'Verfication Mail has Been Send to your Email!');
}
    
    public function SellerKYCApproval(){

      if(Auth::guard('user')->check())
      {

         if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }

        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
      }
        if(Auth::guard('user')->user()->seller_type=='Co-Seller')
           return redirect()->route('home');
        $user_id = Auth::guard('user')->user()->id;
        $email_status = User::where('id',$user_id)->value('email_status');  
        return view('frontEnd.profile-creation.SellerKYCAprroval',compact('email_status'));
    }
    public function ApprovedKYC($token,$user_id){
        
        //$user_id = Auth::guard('user')->user()->id;
		
		$kycdocs_varified = DB::table('kyc_files')
        ->select(DB::raw("count('*') as status_cnt"))
        ->where('user_id',$user_id)
        ->where('status','Active')
        ->pluck('status_cnt')->first();
       
        $user = User::where('id',$user_id)->where('token_number',$token)->get();
        if(count($user)>0)
        {  
	        $input['varification_status'] = 'not varified';  
			if($kycdocs_varified == 3) 
		    $input['varification_status'] = 'varified'; 
            $input['email_status'] = 'Yes'; 
            DB::table('users')->where('id', $user_id)->where('token_number',$token)->update($input);
           $msg='Email Verified';
        }
        else
              $msg='Email Not Verified';    

             if(Auth::guard('user')->check()) 
                   return redirect()->route('seller.kyc.approval')->with('message', $msg);
            else
                    return redirect('/')->with('message', $msg);

    }





    public function ApprovedBuyerEmail($token,$user_id){
        
        //$user_id = Auth::guard('user')->user()->id;
       
        $user = User::where('id',$user_id)->where('token_number',$token)->get();
        if(count($user)>0)
        { 
            $input = ['email_status' => 'Yes']; 
            DB::table('users')->where('id', $user_id)->where('token_number',$token)->update($input);
           $msg='Email Verified';
        }
        else
              $msg='Email Not Verified';    

             if(Auth::guard('user')->check()) 
                   return redirect()->route('buyer.profile')->with('message', $msg);
            else
                    return redirect('/')->with('message', $msg);

    }




  public function UpdateKycDoc(Request $request){
        $file_type = request('file_type');
        $user_id = Auth::guard('user')->user()->id;
        $extension = request('image')->extension();
        $fileName = "kyc_doc".time().'.'.$extension;
        $destinationPath = public_path().'/uploads/KYCFiles' ;
        request('image')->move($destinationPath,$fileName);
        $data = [
        'user_id'=>$user_id,
        'file_path'=>$fileName,
        'reason'=>'',
        'file_type'=>$file_type,
        ]; 
        $KycDoc = "";
//checking doc already exists or not
$KycDoc = KycFile::select('id','status')->where([
    ['user_id',$user_id],
    ['file_type', '=', $file_type],
    ])->first();

if(!empty($KycDoc->id)) {
    if($KycDoc->status=='Rejected') $data['status'] = "In-Active";
    $update = DB::table('kyc_files')->where('id', $KycDoc->id)->update($data);
} else {

$update = KycFile::create($data); 
}

return redirect()->route('seller.kyc.approval')->with('message','File Uploaded');
}



    public function UpdateSeller( Request $request ) { 
    $userId = Auth::guard('user')->user()->id;
    $user = User::find($userId);

       

    if(Auth::guard('user')->user()->seller_type!='Co-Seller'){
         $request->validate([
            'name'      => 'required',
            'surname'      =>'required',
            'email'      =>['required','email',  Rule::unique('users')->ignore($userId)], 
            'country_id'      => 'required',
            'position'      => 'required',
            'accepted_payments'      => 'required',
            'phone'      => ['required','regex:/^(^([+]+)(\d+)?$)$/', Rule::unique('users')->ignore($userId)],
          ]);
    }
    else
    {
       $request->validate([
            'name'      => 'required',
            'surname'      =>'required',
            'email'      =>['required','email',  Rule::unique('users')->ignore($userId)], 
            'phone'      => ['required','regex:/^(^([+]+)(\d+)?$)$/', Rule::unique('users')->ignore($userId)],
          ]); 
    }
        
        $input['name'] =  $request->get('name');
        $input['surname'] =  $request->get('surname');
        $input['email'] =  $request->get('email');
        $input['phone'] =  $request->get('phone');
        $input['position'] =  $request->get('position');
        $input['country_id'] =  $request->get('country_id');
        $input['usertype'] = 'seller';
        $input['company'] = 'Yes';
        $input['hide_promo_email'] = $request->get('hide_promo_email');
        $input['newsletter_status'] = $request->get('newsletter_status');

       // dd($input);
       
    DB::table('users')
    ->where('id', $userId)
    ->update($input);
        
    
        
        $languages_speak = $deliver_options = $accepted_payments = "";
        if(!empty($request->get('languages_speak'))) 
            $languages_speak  = $request->get('languages_speak');
          
        if(!empty($request->get('deliver_options'))) 
            $deliver_options  = $request->get('deliver_options');
         
        if(!empty($request->get('accepted_payments'))) 
            $accepted_payments  = $request->input('accepted_payments');
           
      
      
		$input = [
            'user_id' => $userId,
            'company_name' => $request->get('company_name'),
            'company_street' => $request->get('company_street'),
            'company_zip' => $request->get('company_zip'),
            'company_location' => $request->get('company_location'),
            'company_land' => $request->get('company_land'),
            'registration_no' => $request->get('registration_number'),
            'deliver_options' => $deliver_options,
            'accepted_payments' => $accepted_payments,
            'languages_speak' => $languages_speak,
            //'gst_no' => $request->get('gst_no'),
            'tax_reg_no' => $request->get('tax_reg_no'),
            'about_company' => $request->get('about_company'),
           
        ]; 
        if(request()->hasFile('imgpicture')) {
            $validator = $request->validate([
                'imgpicture' => 'required|image|mimes:jpeg,png,bmp,gif,svg',
            ]);
            $extension = request('imgpicture')->extension();
            $fileName = "company_pic".time().'.'.$extension;
            $destinationPath = public_path().'/uploads/BuyerCompany' ;
            request('imgpicture')->move($destinationPath,$fileName);
            $input['company_image'] = $fileName;
        } 
		// Check seller company already or not if exists update else create
       
             $user =  BuyerCompany::where('user_id','=', $userId)->first();
             if(isset($user->id)){
                $id = $user->id;
               $sellercmpy = DB::table('buyer_companies')
                ->where('id',$id)
                ->update($input);
             } 
            else $sellercmpy= BuyerCompany::create( $input );


            $input = [
                'seller_id' => $userId,
            ];

        

        $checkSun =  $request->get('chSunday'); 
        $input['day'] =  "Sunday";
        $input['opening_time'] = $request->get('opSundayhr');
        $input['closing_time'] = $request->get('clSundayhr');
        $input['Open_am_pm'] = $request->get('SunOpen_am_pm');
        $input['Close_am_pm'] = $request->get('WedClose_am_pm');
        
        if ($checkSun=="Yes")
        {    
            $input['closed'] = 'Yes';
            $input['opening_time'] ='';
            $input['closing_time'] = '';
            $input['Open_am_pm'] ='';
            $input['Close_am_pm'] = '';
        }
        else 
            $input['closed'] = 'No';
         $sunday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Sunday')->first();  
		 if(isset($sunday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$sunday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input);
       
        $chMonday =  $request->get('chMonday');
        $input['day'] =  "Monday";
        $input['opening_time'] = $request->get('opMondayhr');
        $input['closing_time'] = $request->get('clMondayhr');
        $input['Open_am_pm'] = $request->get('MonOpen_am_pm');
        $input['Close_am_pm'] = $request->get('MonClose_am_pm');
        if ($chMonday=="Yes")
        {    
            $input['closed'] = 'Yes';
            $input['opening_time'] ='';
            $input['closing_time'] ='';
            $input['Open_am_pm'] = '';
            $input['Close_am_pm'] = '';
        }
        else 
            $input['closed'] = 'No'; 

        $monday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Monday')->first();  
		 if(isset($monday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$monday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input); 

        $chTuesday =  $request->get('chTuesday');
        $input['day'] =  "Tuesday";
        $input['opening_time'] = $request->get('opTuesdayhr');
        $input['closing_time'] = $request->get('clTuesdayhr');
        $input['Open_am_pm'] = $request->get('TueOpen_am_pm');
        $input['Close_am_pm'] = $request->get('TueClose_am_pm');
        if ($chTuesday=="Yes")
        {    
            $input['closed'] = 'Yes';
            $input['opening_time'] ='';
            $input['closing_time'] ='';
            $input['Open_am_pm'] = '';
            $input['Open_am_pm'] = '';
        }
        else 
            $input['closed'] = 'No';
        $tuesday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Tuesday')->first();  
		 if(isset($tuesday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$tuesday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input);   
 
            $chWednesday =  $request->get('chWednesday');
            $input['day'] =  "Wednesday";
            $input['opening_time'] = $request->get('opWednesdayhr');
            $input['closing_time'] = $request->get('clWednesdayhr');
            $input['Open_am_pm'] = $request->get('WedOpen_am_pm');
            $input['Close_am_pm'] = $request->get('WedClose_am_pm');
            if ($chWednesday=="Yes")
            {    
                $input['closed'] = 'Yes';
                $input['opening_time'] ='';
                $input['closing_time'] ='';
                $input['Open_am_pm'] = '';
                $input['Close_am_pm'] = '';
            }
            else 
                $input['closed'] = 'No';

            $wednesday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Wednesday')->first();  
		 if(isset($wednesday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$wednesday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input);   
            $chThursday =  $request->get('chThursday'); 
            $input['day'] =  "Thursday";
            $input['opening_time'] = $request->get('opThursdayhr');
            $input['closing_time'] = $request->get('clThursdayhr');
            $input['Open_am_pm'] = $request->get('ThuOpen_am_pm');
            $input['Close_am_pm'] = $request->get('ThuClose_am_pm');
            if ($chThursday=="Yes")
            {    
                $input['closed'] = 'Yes';
                $input['opening_time'] ='';
                $input['closing_time'] ='';
                $input['Open_am_pm'] = '';
                $input['Close_am_pm'] = '';

            }
            else 
                $input['closed'] = 'No'; 
                
           $thursday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Thursday')->first();  
		 if(isset($thursday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$thursday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input); 

            $chFriday =  $request->get('chFriday'); 
            $input['day'] =  "Friday";
            $input['opening_time'] = $request->get('opFridayhr');
            $input['closing_time'] = $request->get('clFridayhr');
            $input['Open_am_pm'] = $request->get('FriOpen_am_pm');
            $input['Close_am_pm'] = $request->get('FriClose_am_pm');
            if ($chFriday=="Yes")
            {    
                $input['closed'] = 'Yes';
                $input['opening_time'] ='';
                $input['closing_time'] ='';
                $input['Open_am_pm'] = '';
                $input['Close_am_pm'] = '';
            }
            else 
                $input['closed'] = 'No';   

            $friday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Friday')->first();  
		 if(isset($friday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$friday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input); 

                $chSaturday =  $request->get('chSaturday'); 
                $input['day'] =  "Saturday";
                $input['opening_time'] = $request->get('opSaturdayhr');
                $input['closing_time'] = $request->get('clSaturdayhr');
                $input['Open_am_pm'] = $request->get('SatOpen_am_pm');
                $input['Close_am_pm'] = $request->get('SatClose_am_pm');
                if ($chSaturday=="Yes")
                {    
                    $input['closed'] = 'Yes';
                    $input['opening_time'] ='';
                    $input['closing_time'] ='';
                    $input['Open_am_pm'] = '';
                    $input['Close_am_pm'] = '';
                }
                else 
                    $input['closed'] = 'No';           
        
                $satday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Saturday')->first();  
		 if(isset($satday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$satday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input);  
    
            return redirect()->route('create.seller.profile')->with('message','Profile Updated');

        
    }

    public function UpdateCompany( Request $request ) {
        $user_id = Auth::guard('user')->user()->id;
        
        request()->validate([
           
        ]);
        
        
        
        $input = [
            'user_id' => $user_id,
            'store_name' => $request->get('company_name'),
            'company_street' => $request->get('company_street'),
            'company_zip' => $request->get('company_zip'),
            'company_location' => $request->get('company_location'),
            'company_land' => $request->get('company_land'),
            'deliver_options' => $request->get('deliver_options'),
            'opening_hours' => $request->get('opening_hours'),
            'accepted_payments' => $request->get('accepted_payments'),
            'languages_speak' => $request->get('languages_speak'),
           
        ];
        
        
           
        if($request->has('image') ){ 

            $validator = $request->validate([
                'image' => 'required|image|mimes:jpeg,png,bmp,gif,svg',
            ]);
            $extension = request('image')->extension(); 
            $fileName = "company_pic".time().'.'.$extension;
            $destinationPath = public_path().'/uploads/BuyerCompany' ;
            request('image')->move($destinationPath,$fileName);
            $input['company_image'] = $fileName;  
         }
        //  Company already exists or not
         $user =  BuyerCompany::where('user_id','=',$user_id)->first();
         if(isset($user->id)){
            $id = $user->id;
            DB::table('buyer_companies')
            ->where('id',$id)
            ->update($input);
         } 
        else  BuyerCompany::create( $input );
         return redirect()->route('home');
    }
public function EditBuyerProfile()
{   

    if(Auth::guard('user')->check())
    {
     if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }
    }    

    $usertype = Auth::guard('user')->user()->usertype;  
    if($usertype =="seller" ) //if not buyer or guest redirect to home
    return redirect()->route('home'); 
    $countries =Country::select('id','name')->get();
    $user_id = Auth::guard('user')->user()->id;
    $user = User::find($user_id);
    return view('frontEnd.profile-creation.EditBuyer',compact('user','countries')); 
}
public function update_image(Request $request){
    $validator = $request->validate([
        'image' => 'required|image|mimes:jpeg,png,bmp,gif,svg',
    ]);
            $extension = request('image')->extension();
            $fileName = "user_pic".time().'.'.$extension;
            $destinationPath = public_path().'/uploads/userImages' ;
            request('image')->move($destinationPath,$fileName);
            $data = [
            'profile_pic'=>$fileName,
            ]; 
        
     $user_id = Auth::guard('user')->user()->id;
     $update = User::find($user_id)->update($data); 
    if($update){
        $response['success'] = true;
        $response['message'] = 'Success! Record Updated Successfully.';
        $response['image_path'] = 'uploads/userImages/'.$fileName;
    }else{
        $response['success'] = false;
        $response['message'] = 'Error! Record Not Updated.';
    }
    return $response;
}

public function UpdateCompanyImage(Request $request){
    $extension = request('image')->extension(); 
    $fileName = "company_pic".time().'.'.$extension;
    $destinationPath = public_path().'/uploads/BuyerCompany' ;
    request('image')->move($destinationPath,$fileName);
    $data = [
    'company_image'=>$fileName,
    ]; 
    
$user_id = Auth::guard('user')->user()->id;
$update = DB::table('buyer_companies')
        ->where('user_id',$user_id)
        ->update($data);
if($update){
$response['success'] = true;
$response['message'] = 'Success! Record Updated Successfully.';
$response['image_path'] = 'uploads/BuyerCompany/'.$fileName;
}else{
$response['success'] = false;
$response['message'] = 'Error! Record Not Updated.';
}
return $response;
}
public function UpdateBuyer(Request $request) {
    
    
    $userId = Auth::guard('user')->user()->id; 
    $user = User::find($userId);
    $request->validate([
        'name'      => 'required',
        'surname'      =>'required',
        'email'      =>['required','email', Rule::unique('users')->ignore($userId)], 
        'phone'      => ['required','regex:/^(^([+]+)(\d+)?$)$/', Rule::unique('users')->ignore($userId)],
       'address'      => 'required',
       'country_id'      => 'required',
       'accepted_payments'      => 'required ',
       //'company_image' =>  'mimes:jpeg,jpg,png,gif,webp|max:1000||dimensions:max_width=150,max_height=100',
        //'company_name'      => 'required',
        // 'company_street'      => 'required',
        // 'company_zip'      => 'required',
        // 
        // 'languages_speak'      => 'required ',
        // 'about_company'      => 'required ',
        // 'company_location'      => 'required ',
        
        
        
    ]);

     
    
   
    $input = [
        'name' => $request->get('name'),
        'surname' => $request->get('surname'),
        'email' => $request->get('email'),
        'phone' => $request->get('phone'),
        'position' => $request->get('position'),
        'address' => $request->get('address'),
        'about' => $request->get('about'),
        'country_id' => $request->get('country_id'),
        'hide_promo_email' => $request->get('hide_promo_email'),
        'newsletter_status' => $request->get('newsletter_status'),
    ]; //dd($input);
    DB::table('users')
    ->where('id', $userId)
    ->update($input);


    $languages_speak = $deliver_options = $accepted_payments = "";
    if(!empty($request->get('languages_speak'))) 
        $languages_speak  = $request->get('languages_speak');
      
    if(!empty($request->get('deliver_options'))) 
        $deliver_options  = $request->get('deliver_options');
    
    if(!empty($request->get('accepted_payments'))) 
        $accepted_payments  = $request->input('accepted_payments');
     

    $input = [
        'company_name' => $request->get('company_name'),
        'company_street' => $request->get('company_street'),
        'company_zip' => $request->get('company_zip'),
        'company_location' => $request->get('company_location'),
        'company_land' => $request->get('company_land'),
        'opening_hours' => $request->get('opening_hours'),
        'about_company' => $request->get('about_company'),
        'accepted_payments' => $accepted_payments,
        
        'user_id' => $userId,
        'languages_speak' => $languages_speak,
    ];



    if($request->has('company_image') ){ 
        $validator = $request->validate([
            'company_image' => 'required|image|mimes:jpeg,png,bmp,gif,svg',
        ]);
        $extension = request('company_image')->extension(); 
        $fileName = "user_pic".time().'.'.$extension;
        $destinationPath = public_path().'/uploads/BuyerCompany' ;
        request('company_image')->move($destinationPath,$fileName);
        $input['company_image'] = $fileName;  
     }  //dd($input);
     //  Company already exists or not
     $user =  BuyerCompany::where('user_id','=',$userId)->first();
    
     if(isset($user->id)){
        DB::table('buyer_companies')
        ->where('user_id',$userId)
        ->update($input);
     } 
    else  BuyerCompany::create( $input );


    $input = [
        'seller_id' => $userId,
    ];

    $checkSun =  $request->get('chSunday'); 
        $input['day'] =  "Sunday";
        $input['opening_time'] = $request->get('opSundayhr');
        $input['closing_time'] = $request->get('clSundayhr');
        $input['Open_am_pm'] = $request->get('SunOpen_am_pm');
        $input['Close_am_pm'] = $request->get('WedClose_am_pm');
        
        if ($checkSun=="Yes")
        {    
            $input['closed'] = 'Yes';
            $input['opening_time'] ='';
            $input['closing_time'] = '';
            $input['Open_am_pm'] ='';
            $input['Close_am_pm'] = '';
        }
        else 
            $input['closed'] = 'No';
         $sunday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Sunday')->first();  
		 if(isset($sunday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$sunday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input);
       
        $chMonday =  $request->get('chMonday');
        $input['day'] =  "Monday";
        $input['opening_time'] = $request->get('opMondayhr');
        $input['closing_time'] = $request->get('clMondayhr');
        $input['Open_am_pm'] = $request->get('MonOpen_am_pm');
        $input['Close_am_pm'] = $request->get('MonClose_am_pm');
        if ($chMonday=="Yes")
        {    
            $input['closed'] = 'Yes';
            $input['opening_time'] ='';
            $input['closing_time'] ='';
            $input['Open_am_pm'] = '';
            $input['Close_am_pm'] = '';
        }
        else 
            $input['closed'] = 'No'; 

        $monday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Monday')->first();  
		 if(isset($monday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$monday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input); 

        $chTuesday =  $request->get('chTuesday');
        $input['day'] =  "Tuesday";
        $input['opening_time'] = $request->get('opTuesdayhr');
        $input['closing_time'] = $request->get('clTuesdayhr');
        $input['Open_am_pm'] = $request->get('TueOpen_am_pm');
        $input['Close_am_pm'] = $request->get('TueClose_am_pm');
        if ($chTuesday=="Yes")
        {    
            $input['closed'] = 'Yes';
            $input['opening_time'] ='';
            $input['closing_time'] ='';
            $input['Open_am_pm'] = '';
            $input['Open_am_pm'] = '';
        }
        else 
            $input['closed'] = 'No';
        $tuesday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Tuesday')->first();  
		 if(isset($tuesday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$tuesday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input);   
 
            $chWednesday =  $request->get('chWednesday');
            $input['day'] =  "Wednesday";
            $input['opening_time'] = $request->get('opWednesdayhr');
            $input['closing_time'] = $request->get('clWednesdayhr');
            $input['Open_am_pm'] = $request->get('WedOpen_am_pm');
            $input['Close_am_pm'] = $request->get('WedClose_am_pm');
            if ($chWednesday=="Yes")
            {    
                $input['closed'] = 'Yes';
                $input['opening_time'] ='';
                $input['closing_time'] ='';
                $input['Open_am_pm'] = '';
                $input['Close_am_pm'] = '';
            }
            else 
                $input['closed'] = 'No';

            $wednesday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Wednesday')->first();  
		 if(isset($wednesday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$wednesday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input);   
            $chThursday =  $request->get('chThursday'); 
            $input['day'] =  "Thursday";
            $input['opening_time'] = $request->get('opThursdayhr');
            $input['closing_time'] = $request->get('clThursdayhr');
            $input['Open_am_pm'] = $request->get('ThuOpen_am_pm');
            $input['Close_am_pm'] = $request->get('ThuClose_am_pm');
            if ($chThursday=="Yes")
            {    
                $input['closed'] = 'Yes';
                $input['opening_time'] ='';
                $input['closing_time'] ='';
                $input['Open_am_pm'] = '';
                $input['Close_am_pm'] = '';

            }
            else 
                $input['closed'] = 'No'; 
                
           $thursday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Thursday')->first();  
		 if(isset($thursday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$thursday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input); 

            $chFriday =  $request->get('chFriday'); 
            $input['day'] =  "Friday";
            $input['opening_time'] = $request->get('opFridayhr');
            $input['closing_time'] = $request->get('clFridayhr');
            $input['Open_am_pm'] = $request->get('FriOpen_am_pm');
            $input['Close_am_pm'] = $request->get('FriClose_am_pm');
            if ($chFriday=="Yes")
            {    
                $input['closed'] = 'Yes';
                $input['opening_time'] ='';
                $input['closing_time'] ='';
                $input['Open_am_pm'] = '';
                $input['Close_am_pm'] = '';
            }
            else 
                $input['closed'] = 'No';   

            $friday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Friday')->first();  
		 if(isset($friday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$friday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input); 

                $chSaturday =  $request->get('chSaturday'); 
                $input['day'] =  "Saturday";
                $input['opening_time'] = $request->get('opSaturdayhr');
                $input['closing_time'] = $request->get('clSaturdayhr');
                $input['Open_am_pm'] = $request->get('SatOpen_am_pm');
                $input['Close_am_pm'] = $request->get('SatClose_am_pm');
                if ($chSaturday=="Yes")
                {    
                    $input['closed'] = 'Yes';
                    $input['opening_time'] ='';
                    $input['closing_time'] ='';
                    $input['Open_am_pm'] = '';
                    $input['Close_am_pm'] = '';
                }
                else 
                    $input['closed'] = 'No';           
        
                $satday =  SellerOpeningTime::where('seller_id','=',$userId)->where('day','=','Saturday')->first();  
		 if(isset($satday->id)){
               $SellerOpeningTime = DB::table('seller_opening_times')
                ->where('id',$satday->id)
                ->update($input);
             } 
            else $SellerOpeningTime=SellerOpeningTime::create($input);   






    return redirect()->route('edit.buyer.profile')->with('message','Profile Updated');
}



public function submitUserResetPasswordForm(Request $request)
    { 
        $userId = Auth::guard('user')->user()->id;
        $request->validate([
            'oldPassword' =>'required',
            'password' => 'required|string|min:6|confirmed',
            'password_confirmation' => 'required'
        ]); 
    if (!Hash::check($request['oldPassword'], Auth::guard('user')->user()->password)) {
    return redirect()->route('edit.buyer.profile',$userId)->with('message','The old password does not match our records.');
    
    }
    
        $user = User::where('id', $userId)
                    ->update(['password' => Hash::make($request->password)]);

       
        return redirect()->route('edit.buyer.profile',$userId)->with('message','Your password has been changed!'); 
    
    
    }


    public function EditSellerProfile($userId)
    {
        $user = User::find($userId);
        return view('frontEnd.profile-creation.EditSellerProfile',compact('user')); 
    }

    public function SellerProfile()
    {

        if(Auth::guard('user')->check())
        {

        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }
        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
        } 
        $userId = Auth::guard('user')->user()->id;
        $user = User::find($userId);
        $usertype = Auth::guard('user')->user()->usertype; //dd($usertype);
        if($usertype!="seller") return redirect()->route('home');
        
        
        $values = [];
        $sellerProducts = $user->SellerProduct;
        foreach ($sellerProducts as $sproduct) {
            foreach(explode(',', $sproduct->category_id) as $value) {
                $values[] = trim($value);
            }
        } 
        $values = array_unique($values);
        $category_product_count = [];
        foreach($values as $row){
            $prdt_count = SellerProduct::where('status','active')->where('user_id',$userId)->WhereRaw('find_in_set("'.$row.'",category_id)')->count(); 
            $category_name = Category::find($row,['name','category_pic']);
            $category_product_count[]=array('product_count'=>$prdt_count,'category'=>$category_name);
        }
        arsort($category_product_count);
        $category_product_count = array_splice($category_product_count, 0, 3);  
       // dd($category_product_count);
        $categorylists=Category::whereIn('id',$values)->pluck('name')->all();



    $my_products = SellerProduct::select('*')->where('status','active')->where('user_id',$userId)->latest()->take(4)->get(); 
    $network=false;

    $my_networks=Mynetworks::where('user_id',$userId)->pluck('mynetwork_id')->first();
    $network_id=explode(',', $my_networks); 
    $network_list =User::select('name','id','profile_pic')->whereIn('id',$network_id)->get();
    $chat_data = array();
    if (!$network_list->isEmpty()) {
        foreach($network_list as $key=>$row){
            $unreadCount = Message::where('from_user', $row->id)->where('to_user',$userId)->where('message_status', 'unread')->count();
            $latestMessage = Message::where(function ($query) use ($userId, $row) {
            $query->where('from_user', $userId)
                            ->where('to_user', $row->id);
                    })
                    ->orWhere(function ($query) use ($userId, $row) {
                        $query->where('from_user', $row->id)
                            ->where('to_user', $userId);
                    })->orderBy('id', 'desc')->take(5)->get();
                 // })->latest()->first();
            $chat_data[$key] = array('contact'=>$row,'latestMessage'=>$latestMessage,'unreadcount'=>$unreadCount);
    
        }
    } 
    $profile_visit_count = BusinessInsight::where('profile_id', $userId)->count();
    $product_count = SellerProduct::where('user_id', $userId)->count();
    $network_count = Mynetworks::where('user_id',$userId)->count();
    $sellerProducts = $user->SellerProduct;
    if(count($sellerProducts)>0)
    {
        foreach ($sellerProducts as $sproduct) {
                     $category=explode(',', $sproduct->category_id);
                     foreach($category as $value) 
                         $values[] = trim($value);
                     
             }
        $values = array_unique($values); 
    } 
   
    $categorylists=Category::whereIn('id',$values)->pluck('name')->all();


    return view('frontEnd.profile-creation.SellerProfile',compact('user','categorylists','network','my_products','profile_visit_count','product_count','network_count','category_product_count')); 
    }

    public function SellerDashboard()
    {

        if(Auth::guard('user')->check()){

             if(!$this->PublicMiddlewareController->checkUserlogin()) 
             {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
             }
            if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ){
                Auth::guard('user')->logout(); 
                return redirect(route('home')); 
            }
        } 
        $userId = Auth::guard('user')->user()->id;
        $user = User::leftjoin('buyer_companies', 'buyer_companies.user_id', 'users.id')->where('users.id',$userId)->first();
        $usertype = Auth::guard('user')->user()->usertype; //dd($usertype);
        if($usertype!="seller") return redirect()->route('home');
        $values = [];
		$sellerProducts = SellerProduct::Select('category_id')->where('user_id',$userId)->get();
        foreach ($sellerProducts as $sproduct) {
            foreach(explode(',', $sproduct->category_id) as $value) {
                $values[] = trim($value);
            }
        } 
        $values = array_unique($values);
        $category_product_count = [];
        foreach($values as $row){
            $prdt_count = SellerProduct::where('status','active')->where('user_id',$userId)->WhereRaw('find_in_set("'.$row.'",category_id)')->count(); 
            $category_name = Category::find($row,['name','category_pic']);
            $category_product_count[]=array('product_count'=>$prdt_count,'category'=>$category_name);
        }
        arsort($category_product_count);
        $category_product_count = array_splice($category_product_count, 0, 3);  
        $categorylists=Category::whereIn('id',$values)->pluck('name')->all();
        $my_products = SellerProduct::select('*')->where('status','active')->where('user_id',$userId)->latest()->take(4)->get(); 
        $my_networks=Mynetworks::where('user_id',$userId)->pluck('mynetwork_id')->first();
        $network_id=explode(',', $my_networks);
        $user = User::find($userId); 
        $network_list =User::select('name','id','profile_pic')->whereIn('id',$network_id)->get();
        $chat_data = array();
        if (!$network_list->isEmpty()) {
            foreach($network_list as $key=>$row){
                $unreadCount = Message::where('from_user', $row->id)->where('to_user',$userId)->where('message_status', 'unread')->count();
                $latestMessage = Message::where(function ($query) use ($userId, $row) {
                $query->where('from_user', $userId)
                                ->where('to_user', $row->id);
                        })
                        ->orWhere(function ($query) use ($userId, $row) {
                            $query->where('from_user', $row->id)
                                ->where('to_user', $userId);
                        })->orderBy('id', 'desc')->take(5)->get();
                     // })->latest()->first();
                $chat_data[$key] = array('contact'=>$row,'latestMessage'=>$latestMessage,'unreadcount'=>$unreadCount);
        
            }
        } 
        $network='false';
        $profile_visit_count = BusinessInsight::where('profile_id', $userId)->count();
        $product_count = SellerProduct::where('user_id', $userId)->count();
        $network_count = Mynetworks::where('user_id',$userId)->count();
        return view('frontEnd.profile-creation.dashboard',compact('user','categorylists','network','network_list','chat_data','my_products','profile_visit_count','product_count','network_count','category_product_count')); 
    }

public function BuyerDashboard()
{
     if(Auth::guard('user')->check())
     {   
     if(!$this->PublicMiddlewareController->checkUserlogin()) 
     {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
     }
    }

    $userId = Auth::guard('user')->user()->id;
    $usertype = Auth::guard('user')->user()->usertype;
    $email_status = User::where('id',$userId)->value('email_status'); 
    $subsription = Subscription::where('user_id',$userId)
    ->where('status','Active')
    ->latest('updated_at')
    ->first(); 

    $my_networks=Mynetworks::where('user_id',$userId)->pluck('mynetwork_id')->first();
    $network_id=explode(',', $my_networks);
    $user = User::find($userId); 
    $network_list =User::select('name','id','profile_pic')->whereIn('id',$network_id)->get();

    $chat_data = array();
    if (!$network_list->isEmpty()) {
      foreach($network_list as $key=>$row){
        $unreadCount = Message::where('from_user', $row->id)->where('to_user',$userId)->where('message_status', 'unread')->count();
        $latestMessage = Message::where(function ($query) use ($userId, $row) {
                $query->where('from_user', $userId)
                                ->where('to_user', $row->id);
                        })
                        ->orWhere(function ($query) use ($userId, $row) {
                            $query->where('from_user', $row->id)
                                ->where('to_user', $userId);
                        })->orderBy('id', 'desc')->take(5)->get();
                     // })->latest()->first();
        $chat_data[$key] = array('contact'=>$row,'latestMessage'=>$latestMessage,'unreadcount'=>$unreadCount);
        
      }
    }

    if($usertype=="seller" ) //if not seller redirect to home
   return redirect()->route('home'); 

    $user = User::find($userId);
    $network=false;
    return view('frontEnd.profile-creation.buyer-dashboard',compact('user','chat_data','subsription','network','email_status'));
}




public function BusinessInsight()
{
    if(Auth::guard('user')->check()){


        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }
        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ){
            Auth::guard('user')->logout(); 
            return redirect(route('home')); 
        }
    } 
    $userId = Auth::guard('user')->user()->id;
    $user = User::leftjoin('buyer_companies', 'buyer_companies.user_id', 'users.id')->where('users.id',$userId)->first();
    $usertype = Auth::guard('user')->user()->usertype; //dd($usertype);
    if($usertype!="seller") return redirect()->route('home');
    $values = [];
    $sellerProducts = SellerProduct::Select('category_id')->where('user_id',$userId)->get();
    foreach ($sellerProducts as $sproduct) {
        foreach(explode(',', $sproduct->category_id) as $value) {
            $values[] = trim($value);
        }
    } 
    $values = array_unique($values);
    $category_product_count = [];
    foreach($values as $row){
        $prdt_count = SellerProduct::where('status','active')->where('user_id',$userId)->WhereRaw('find_in_set("'.$row.'",category_id)')->count(); 
        $category_name = Category::find($row,['name','category_pic']);
        $category_product_count[]=array('product_count'=>$prdt_count,'category'=>$category_name);
    }
    arsort($category_product_count);
    $category_product_count = array_splice($category_product_count, 0, 4);
   // dd($category_product_count);
    $categoryinsight=Category::whereIn('id',$values)->paginate(5);
    
    $categorylists=Category::whereIn('id',$values)->get();
    if(!$categoryinsight->isEmpty()){
        foreach($categoryinsight as $key => $list){
            $my_products = SellerProduct::where('user_id', '=', $userId)->WhereRaw('find_in_set("'.$list->id.'",category_id)')->pluck('id')->toArray();
            $categoryinsight[$key]->insight_count = BusinessInsight::whereIn('product_id', $my_products)->count();
            $categoryinsight[$key]->month_count = BusinessInsight::whereIn('product_id', $my_products)->where('created_at', '>=', Carbon::now()->subdays(30))->count();
            $categoryinsight[$key]->week_count = BusinessInsight::whereIn('product_id', $my_products)->where('created_at','>=',Carbon::now()->subdays(7))->count();
            $categoryinsight[$key]->repeat_count = BusinessInsight::whereIn('product_id', $my_products)->groupBy('product_id')->having('product_id', '>', 1)->count();
        }
    }


    $profile_views_week1 = BusinessInsight::where('profile_id', $userId)
    ->where('created_at','>=',Carbon::now()->subdays(7))->count();
    
    
    $profile_views_week2 = BusinessInsight::where('profile_id', $userId)
    ->where('created_at','<=',Carbon::now()->subdays(7))
     ->where('created_at','>=',Carbon::now()->subdays(14))->count();

     $profile_views_week3 = BusinessInsight::where('profile_id', $userId)
    ->where('created_at','<=',Carbon::now()->subdays(14))
     ->where('created_at','>=',Carbon::now()->subdays(21))->count();

     $profile_views_week4 = BusinessInsight::where('profile_id', $userId)
    ->where('created_at','<=',Carbon::now()->subdays(21))
     ->where('created_at','>=',Carbon::now()->subdays(28))->count();
    
    

    



    $productlists=SellerProduct::where('user_id', '=', $userId)->paginate(5);
    if(!$productlists->isEmpty()){
        foreach($productlists as $key => $list){
            $productlists[$key]->insight_count = BusinessInsight::where('product_id', $list->id)->count();
            $productlists[$key]->month_count = BusinessInsight::where('product_id', $list->id)->where('created_at', '>=', Carbon::now()->subdays(30))->count();
            $productlists[$key]->week_count = BusinessInsight::where('product_id', $list->id)->where('created_at','>=',Carbon::now()->subdays(7))->count();
            $productlists[$key]->repeat_count = BusinessInsight::where('product_id', $list->id)->groupBy('product_id')->having('product_id', '>', 1)->count();
        }
    }
   
 
        $inr=7;
        $dates_name=$repeated_userdata=$new_userdata=[];
        while ( $inr>0) {
        $date=Carbon::now()->subdays($inr);
           array_push($dates_name,  $date->format('l'));
           $repeated_user = BusinessInsight::where('profile_id',  $userId)
                         ->whereDate('visited_at','=',  $date->format('Y-m-d'))
                         ->select(DB::raw('count(*) as count'))
                         ->groupBy('user_id')
                         ->havingRaw('COUNT(*) > 1')
                         ->count();
                       
           $new_user = BusinessInsight::where('profile_id',  $userId)
                         ->whereDate('visited_at','=',  $date->format('Y-m-d'))
                          ->select(DB::raw('count(*) as count'))
                         ->groupBy('user_id')
                         ->havingRaw('COUNT(*) = 1')
                         ->count();              
       
            array_push($repeated_userdata,$repeated_user);
            array_push($new_userdata, $new_user);

           $inr--;
        }



    return view('frontEnd.profile-creation.business-insight',compact('user','profile_views_week1','profile_views_week2','profile_views_week3','profile_views_week4','category_product_count','categoryinsight','productlists','categorylists', 'dates_name','repeated_userdata','new_userdata')); 
}

public function getbusinessCategories(Request $request)
  
   {  
       $userId = Auth::guard('user')->user()->id;
       $user = User::find($userId);
       $columnIndex_arr = $request->get('order');
       $columnName_arr = $request->get('columns');
       $order_arr = $request->get('order');
       $search_arr = $request->get('search');
      
               $draw = $request->get('draw');
               $start = $request->get("start");
               $rowperpage = $request->get("length"); // total number of rows per page
               $columnIndex = $columnIndex_arr[0]['column']; // Column index
               $columnName = $columnName_arr[$columnIndex]['data']; // Column name
               $columnSortOrder = $order_arr[0]['dir']; // asc or desc
               
            

	$values = [];
    $sellerProducts = $user->SellerProduct;
    foreach ($sellerProducts as $sproduct) {
        foreach(explode(',', $sproduct->category_id) as $value) {
            $values[] = trim($value);
        }
    } 
    $values = array_unique($values);			
  
               
              // $searchValue = $search_arr['value']; // Search value
       $totalRecords = Category::select('count(*) as allcount')
                       ->whereIn('id',$values)->count();
       $totalRecordswithFilter = Category::select('count(*) as allcount')
                                 ->whereIn('id',$values)->count(); 

      

       // Get records, also we have included search filter as well
       $records = Category::select('*')
           ->whereIn('id',$values)
           ->orderBy($columnName,$columnSortOrder)
           ->skip($start)
           ->take($rowperpage)
           ->get();
       $data_arr = array();
      
      
             
    if(!$records->isEmpty()){
        foreach($records as $record){
			$my_products = SellerProduct::where('user_id', '=', $userId)->WhereRaw('find_in_set("'.$record->id.'",category_id)')->pluck('id')->toArray();
            $status = BusinessInsight::whereIn('product_id', $my_products)->count();
            $last_month = BusinessInsight::whereIn('product_id', $my_products)->where('created_at', '>=', Carbon::now()->subdays(30))->count();
            $last_week = BusinessInsight::whereIn('product_id', $my_products)->where('created_at','>=',Carbon::now()->subdays(7))->count();
            $repeat_count = BusinessInsight::whereIn('product_id', $my_products)->groupBy('product_id')->having('product_id', '>', 1)->count();
                $data_arr[] = array(  
               "id" => $record->id,
               "name" => $record->name,
               "status" => $status,
               "last_week" => $last_week,
               "last_month" => $last_month,
               "repeat_count" => $repeat_count,
              );
     
      
        }
    }        
                                                                               
          
          

       $response = array(
           "draw" => intval($draw),
           "iTotalRecords" => $totalRecords,
           "iTotalDisplayRecords" => $totalRecordswithFilter,
           "aaData" => $data_arr,
       );
       echo json_encode($response);       
}



public function getbusinessproducts(Request $request)
  
   {  
       $userId = Auth::guard('user')->user()->id;
       $columnIndex_arr = $request->get('order');
       $columnName_arr = $request->get('columns');
       $order_arr = $request->get('order');
       $search_arr = $request->get('search');
      
               $draw = $request->get('draw');
               $start = $request->get("start");
               $rowperpage = $request->get("length"); // total number of rows per page
               $columnIndex = $columnIndex_arr[0]['column']; // Column index
               $columnName = $columnName_arr[$columnIndex]['data']; // Column name
               $columnSortOrder = $order_arr[0]['dir']; // asc or desc
               
               
  
               
              // $searchValue = $search_arr['value']; // Search value
       $totalRecords = SellerProduct::select('count(*) as allcount')
       ->where('user_id',$userId)
       ->where('status','!=','deleted')->count();
       $totalRecordswithFilter = SellerProduct::select('count(*) as allcount')
       ->where('user_id',$userId)
       ->where('status','!=','deleted')
       ->where(function ($query) use($request){

        if($request->get('search_key') !=""){
           $query->where('name','Like','%'.$request->get('search_key').'%');
       }
       
                       
      })
        ->count(); 

      

       // Get records, also we have included search filter as well
       $records = SellerProduct::select('*')
       ->where('user_id',$userId)
       ->where('status','!=','deleted')
       ->where('user_id',$userId)->where(function ($query) use($request){

        if($request->get('search_key') !=""){
           $query->where('name','Like','%'.$request->get('search_key').'%');
       }
                       
       
    })
    ->orderBy($columnName,$columnSortOrder)
           ->skip($start)
           ->take($rowperpage)
           ->get();
       $data_arr = array();
      
      
             
    if(!$records->isEmpty()){
        foreach($records as $record){
            $status = BusinessInsight::where('product_id', $record->id)->count();
            $last_month = BusinessInsight::where('product_id', $record->id)->where('created_at', '>=', Carbon::now()->subdays(30))->count();
            $last_week = BusinessInsight::where('product_id', $record->id)->where('created_at','>=',Carbon::now()->subdays(7))->count();
            $repeat_count = BusinessInsight::where('product_id', $record->id)->groupBy('product_id')->having('product_id', '>', 1)->count();
                $data_arr[] = array(  
               "id" => $record->id,
               "name" => $record->name,
               "status" => $status,
               "last_week" => $last_week,
               "last_month" => $last_month,
               "repeat_count" => $repeat_count,
              );
     
      
        }
    }        
                                                                               
          
          

       $response = array(
           "draw" => intval($draw),
           "iTotalRecords" => $totalRecords,
           "iTotalDisplayRecords" => $totalRecordswithFilter,
           "aaData" => $data_arr,
       );
       echo json_encode($response);       
}



public function BuyerContactRequest(){
    if(Auth::guard('user')->check())
    $userId = Auth::guard('user')->user()->id;
    $usertype=  Auth::guard('user')->user()->usertype;
    if($usertype!="buyer") return redirect()->route('home');
    $sellermessages = SellerMessage::select('*')->where('user_id',$userId)->latest()->paginate(5);
   
    return view('frontEnd.profile-creation.buyer-contact-request',compact('sellermessages')); 
    
}



    public function SellerProductPendingApprovals()
    {

        if(Auth::guard('user')->check())
        {

          if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }   
        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
        } 
        $userId = Auth::guard('user')->user()->id;
        $user = User::find($userId);
        $usertype = Auth::guard('user')->user()->usertype; //dd($usertype);
        if($usertype!="seller") return redirect()->route('home');
        $values = [];
        $sellerProducts = $user->SellerProduct;
        foreach ($sellerProducts as $sproduct) {
        foreach(explode(',', $sproduct->category_id) as $value) {
        $values[] = trim($value);
    }
    } 
    $values = array_unique($values); 
    $categorylists=Category::whereIn('id',$values)->pluck('name')->all();
    $categories = Category::all();
    $my_products = SellerProduct::select('*')->where('status','pending')->where('user_id',$userId)->get(); 
   
    return view('frontEnd.profile-creation.Sproduct-pending-approve',compact('user','categories','categorylists','my_products')); 
    }



    public function getSellerPendingProductlist(Request $request)
    {  
        $usertype = Auth::guard('user')->user()->usertype; 
        if($usertype!="seller") return redirect()->route('home');
        $columnIndex_arr = $request->get('order');
        $columnName_arr = $request->get('columns');
        $order_arr = $request->get('order');
        $search_arr = $request->get('search');
       
                $draw = $request->get('draw');
                $start = $request->get("start");
                $rowperpage = $request->get("length"); // total number of rows per page
                $columnIndex = $columnIndex_arr[0]['column']; // Column index
                $columnName = $columnName_arr[$columnIndex]['data']; // Column name
                $columnSortOrder = $order_arr[0]['dir']; // asc or desc
               // $searchValue = $search_arr['value']; // Search value
        $userId = Auth::guard('user')->user()->id;
        $totalRecords = SellerProduct::select('count(*) as allcount')
        ->where('status','pending')
        ->where('user_id',$userId)
        ->count();
        $totalRecordswithFilter = SellerProduct::select('count(*) as allcount')
        ->where('status','pending')
        ->where('user_id',$userId)
        ->where(function ($query) use($request){

         if($request->get('search_key') !=""){
            $query->where('name','Like','%'.$request->get('search_key').'%');
        }
        if($request->get('category_id') !=null){
             $query->whereRaw('find_in_set("'.$request->get('category_id').'",category_id)');
        }
                        
        if($request->get('stock') !=null){
                            if($request->get('stock')=="instock")
                                $query->where("stock_count",">",0);
                            else
                                $query-> where("stock_count","<=",0);
         }})->count();

       

        // Get records, also we have included search filter as well
        $records = SellerProduct::select('*')
        ->where('status','pending')
        ->where('user_id',$userId)
        ->where(function ($query) use($request){

         if($request->get('search_key') !=""){
            $query->where('name','Like','%'.$request->get('search_key').'%');
        }
        if($request->get('category_id') !=null){
              $query->whereRaw('find_in_set("'.$request->get('category_id').'",category_id)');
        }
                        
        if($request->get('stock') !=null){
                    if($request->get('stock')=="instock")
                          $query->where("stock_count",">",0);
                    else
                            $query->where("stock_count","<=",0);
         }
     })->orderBy($columnName,$columnSortOrder)
            ->skip($start)
            ->take($rowperpage)
            ->get();
        $data_arr = array();
       
        foreach ($records as $record) {
            
                            
                 $strcat_parent = $strcat='';
            $Categories = explode(",",$record->category_id);
                       foreach($Categories as $item) {
                        $strcat_parent.= Category::where('id',$item)->where('parent_id', null)->pluck('name')->first()."<br/>";
                        $strcat.= Category::where('id',$item)->where('parent_id','!=', null)->pluck('name')->first()."<br/>";
                       }
                                     
                            
                            
                            
                            
                            
                            
                            
                                  
              $strimg='';   
              
              
              foreach( $record->SellerProductImage as $productimage)
               {     
                        if($productimage->thumbnail == 'yes') 
                           $strimg.= '<div class="table-prof"><img style=" width:60px !important;" class="pr_img" src="'.asset("/uploads/productImages/").'/'.$productimage->image_path.' "></div>';
               }         
                  $seller = User::find($userId)  ;                                                                    
            $start=$start+1;
            $data_arr[] = array(  
                "id" => $record->id,
                "name" => $record->name,
                "company_name" =>  $seller->BuyerCompany->company_name??"",
                "location" => $seller->BuyerCompany->company_location ?? "",
                "product_price" => $record->product_price,
                "strcat_parent" => $strcat_parent,
               "strcat" => $strcat,
               "status" => $record->status,
                "created_at" => date("d/m/Y   \&\\n\b\s\p\; \&\\n\b\s\p\; \&\\n\b\s\p\;  g:i A", strtotime($record->created_at)),
                "strimg" => $strimg,
               );
        }

        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $totalRecords,
            "iTotalDisplayRecords" => $totalRecordswithFilter,
            "aaData" => $data_arr,
        );
        echo json_encode($response);       
}





    public function profile_to_network(Request $request)
    {
        $login_id = Auth::guard('user')->user()->id;
        $to_network_id=$request->get('user_id');
        $networks=Mynetworks::where('user_id',$login_id)->first();
        if(empty($networks))
        {  
            $network_users=$to_network_id.',';
            Mynetworks::create(['user_id'=>$login_id,'mynetwork_id'=>$network_users]);
            $msg="Added to Networks";         
            
        }
        else
        { 
            $network_users=$networks->mynetwork_id.$to_network_id.',';
            $networks->update(['mynetwork_id'=>$network_users]);
            $msg="Added to Networks";
        }
        

         echo json_encode($msg);  
    }
    public function ViewSellerProfile($profId)
    {

        $userId = $profId;
        $user = User::find($userId);
        
        $values = [];
        $sellerProducts = $user->SellerProduct;
        foreach ($sellerProducts as $sproduct) {
            foreach(explode(',', $sproduct->category_id) as $value) {
                $values[] = trim($value);
            }
        } 
        $values = array_unique($values);
        $category_product_count = [];
        foreach($values as $row){
            $prdt_count = SellerProduct::where('status','active')->where('user_id',$userId)->WhereRaw('find_in_set("'.$row.'",category_id)')->count(); 
            $category_name = Category::find($row,['name','category_pic']);
            $category_product_count[]=array('product_count'=>$prdt_count,'category'=>$category_name);
        }
        arsort($category_product_count);
        $category_product_count = array_splice($category_product_count, 0, 3);  
       // dd($category_product_count);
        $categorylists=Category::whereIn('id',$values)->pluck('name')->all();
		
		 $login_id =  null;
        if(Auth::guard('user')->check())
         $login_id = Auth::guard('user')->user()->id;
        $counts=Mynetworks::where('user_id',$login_id)->whereRaw('find_in_set("'.$profId.'",mynetwork_id)')->count();
        if($counts>0||($profId==$login_id))
            $network=false;
        else
            $network=true;
		
		
        $my_products = SellerProduct::select('*')->where('status','active')->where('user_id',$userId)->latest()->take(4)->get(); 
        $my_networks=Mynetworks::where('user_id',$userId)->pluck('mynetwork_id')->first();
        $network_id=explode(',', $my_networks); 
        $network_list =User::select('name','id','profile_pic')->whereIn('id',$network_id)->get();
        $chat_data = array();
        if (!$network_list->isEmpty()) {
            foreach($network_list as $key=>$row){
                $unreadCount = Message::where('from_user', $row->id)->where('to_user',$userId)->where('message_status', 'unread')->count();
                $latestMessage = Message::where(function ($query) use ($userId, $row) {
                $query->where('from_user', $userId)
                                ->where('to_user', $row->id);
                        })
                        ->orWhere(function ($query) use ($userId, $row) {
                            $query->where('from_user', $row->id)
                                ->where('to_user', $userId);
                        })->orderBy('id', 'desc')->take(5)->get();
                     // })->latest()->first();
                $chat_data[$key] = array('contact'=>$row,'latestMessage'=>$latestMessage,'unreadcount'=>$unreadCount);
        
            }
        } 
        $profile_visit_count = BusinessInsight::where('profile_id', $userId)->count();
        $product_count = SellerProduct::where('user_id', $userId)->count();
        $network_count = Mynetworks::where('user_id',$userId)->count();
        $sellerProducts = $user->SellerProduct;
        if(count($sellerProducts)>0)
        {
            foreach ($sellerProducts as $sproduct) {
                         $category=explode(',', $sproduct->category_id);
                         foreach($category as $value) 
                             $values[] = trim($value);
                         
                 }
            $values = array_unique($values); 
        } 
       
        $categorylists=Category::whereIn('id',$values)->pluck('name')->all();
       

            $clientIP = \Request::ip();
            $insight=array();
            $insight = [
            'user_id' => $login_id,
            'profile_id' => $profId,
            'ip_address' => $clientIP,
     ];
     BusinessInsight::create($insight);

        return view('frontEnd.profile-creation.SellerProfile',compact('user','categorylists','network','profile_visit_count','product_count','network_count','category_product_count')); 
    }

    public function BuyerProfile()
    {
        $userId = Auth::guard('user')->user()->id;
        $usertype = Auth::guard('user')->user()->usertype;
        $email_status = User::where('id',$userId)->value('email_status'); 
        $order = OrderDetail::where('user_id',$userId)->latest('updated_at')
        ->first();
        
        $subscriptions = Subscription::where('user_id',$userId)
                ->where('status','Active')
                ->whereDate('expairy_date', '>', now())
                ->groupBy('package_id')
                ->orderBy('id','DESC')
                ->latest('updated_at')
        ->first();
                if(empty($subscriptions)) { $subscriptions = ""; }

        if($usertype=="seller" ) //if not seller redirect to home
       return redirect()->route('home'); 

        $user = User::find($userId);
        $network=false;


        $clientIP = \Request::ip();
        $insight=array();
        

        return view('frontEnd.profile-creation.BuyerProfile',compact('user','order','network','subscriptions','email_status'));
    }
    public function UpdateSellerProfile(Request $request) {
    
    
        $userId = Auth::guard('user')->user()->id; 
        $user = User::find($userId);
        request()->validate([
            'store_name' => ['required', 'string', 'max:255'],
             'email' => ['required', 'email', Rule::unique('users')->ignore($userId)],
             'phone' => ['required', 'max:12'],
        ]);
    
        $input = [
            'store_name' => $request->get('store_name'),
            'email' => $request->get('email'),
            'phone' => $request->get('phone'),
            'hide_promo_email' => $request->get('hide_promo_email'),
            'newsletter_status' => $request->get('newsletter_status'),
            
        ];  
        DB::table('users')
        ->where('id', $userId)
        ->update($input);
    return redirect()->route('edit.seller.profile',$userId)->with('message','Profile Updated');
    }
	
	 public function NewsletterSubscription(Request $request)
    {  
        $request->validate([
            'email' => 'required|unique:users,email|unique:newsletter_subscriptions,email'
        ]);
        $query =  DB::table('newsletter_subscriptions')->insert(['email' => $request->email ]);       
        echo json_encode( "Newsletter Subscribed !");  
    }


public function loadproducts(Request $request)
{ 
  

    $start_from=$request->input('start_from');
    $per_page=$request->input('per_page'); 
    $userId=$request->input('user_id'); 
    
    //$productId=$request->input('user_id');   
    $loadProducts = SellerProduct::where('user_id','=',$userId)->where('status','active');
    $count = $loadProducts->count();
    $loadProducts= $loadProducts->skip($start_from)->take($per_page)->get();

   $data_return=[];
   foreach($loadProducts as $data){
    $created_at = date('M d , Y', strtotime($data->created_at));
    $product_images = SellerProductImage::where('product_id','=',$data->id)->get();

    $cnt=count($product_images) ;
    if($cnt>0) {
 if(!empty($product_images)) {
    foreach( $product_images as $productimage)
    {     
             if($productimage->thumbnail == 'yes') 
               $prd_img  = asset("/uploads/productImages/").'/'.$productimage->image_path;
    }    
} }  else    $prd_img  = asset("images/no-image.jpg");
      


    $data_return[]= array('name'=>$data->name,'user_id'=>$userId,'prd_img'=>$prd_img ,'prd_id'=>$data->id );
  }
  $return_array=['count'=>$count,'loadProducts'=>$data_return];
  return json_encode($return_array);
 
}

}
