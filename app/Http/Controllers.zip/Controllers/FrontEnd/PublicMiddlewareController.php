<?php

namespace App\Http\Controllers\FrontEnd;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;

class PublicMiddlewareController extends Controller
{

 public function checkUserValidity(){

     if(Auth::guard('user')->user()) {

                        if(Auth::guard('user')->user()->status=='Deleted'||Auth::guard('user')->user()->status=='Blocked'||Auth::guard('user')->user()->status=='Rejected')
                            return false;
                        if(Auth::guard('user')->user()->seller_type=='Co-Seller')
                            $parent_id=Auth::guard('user')->user()->parent_id;
                        else
                            $parent_id = Auth::guard('user')->user()->id;
                        
                            $package_data = DB::table('subscriptions')
                                            ->leftJoin('order_details', 'subscriptions.order_id', '=', 'order_details.id')
                                            ->leftJoin('packages', 'packages.id', '=', 'order_details.package_id')
                                            ->leftJoin('package_accounts', 'package_accounts.id', '=', 'order_details.accounts_id')
                                            ->where('subscriptions.user_id', '=',$parent_id)
                                            ->where('subscriptions.status','active')
                                            ->orderBy('subscriptions.id','DESC')->first();
                                                     
                            if(!empty($package_data)){  
                                if( $package_data->subscription_type=='Extended' && $package_data->expairy_date>=date('Y-m-d'))
                                    return true;
                                else
                                    return false;                        
                            }
                            else
                                    return false;  

                    }
                    else
                                    return false; 
        }

    public function checkUserContactValidity(){

     if(Auth::guard('user')->user()) {

                        if(Auth::guard('user')->user()->status=='Deleted'||Auth::guard('user')->user()->status=='Blocked'||Auth::guard('user')->user()->status=='Rejected')
                            return false;
                        
                        if(Auth::guard('user')->user()->seller_type=='Co-Seller')
                            $parent_id=Auth::guard('user')->user()->parent_id;
                        else
                            $parent_id = Auth::guard('user')->user()->id;
                        
                            $package_data = DB::table('subscriptions')
                                            ->leftJoin('order_details', 'subscriptions.order_id', '=', 'order_details.id')
                                            ->leftJoin('packages', 'packages.id', '=', 'order_details.package_id')
                                            ->leftJoin('package_accounts', 'package_accounts.id', '=', 'order_details.accounts_id')
                                            ->where('subscriptions.user_id', '=',$parent_id)
                                            ->where('subscriptions.status','active')
                                            ->orderBy('subscriptions.id','DESC')->first();
                                                     
                            if(!empty($package_data)){  
                                if($package_data->expairy_date>=date('Y-m-d'))
                                    return true;
                                else
                                    return false;                        
                            }
                            else
                                    return false;  

                    }
                    else
                                    return false; 
        }


        public function checkUserlogin()
        {

            if(Auth::guard('user')->user()) {
                if(Auth::guard('user')->user()->status=='Deleted'||Auth::guard('user')->user()->status=='Blocked'||Auth::guard('user')->user()->status=='Rejected')
                        return false;
                else 
                        return true;               
            }
             return false;

         }  
}