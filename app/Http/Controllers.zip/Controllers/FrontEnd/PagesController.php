<?php

namespace App\Http\Controllers\FrontEnd;
use App\Http\Controllers\Controller;
use App\Models\Slider;
use App\Models\SellerProduct;
use App\Models\SellerProductImage;
use App\Models\Category;
use App\Models\Product;
use App\Models\Country;
use App\Models\Contentpage;
use App\Models\Mynetworks;
use App\Models\Message;
use App\Models\Advertisement;
use App\User;
use DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\FrontEnd\PublicMiddlewareController;
class PagesController extends Controller
{


    protected $PublicMiddlewareController;
    public function __construct(PublicMiddlewareController $PublicMiddlewareController)
    {
        $this->PublicMiddlewareController = $PublicMiddlewareController;
    }

    public function HomePage()
    {


      if(Auth::guard('user')->check())
      {


        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }


        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
      } 

      $products = SellerProduct::leftJoin('users', 'users.id', '=', 'seller_products.user_id')
              ->select('seller_products.*')
              ->where('users.status','Active')->where('seller_products.status','active')
              ->latest('seller_products.created_at')->take(10)->get();

      $featured_products = SellerProduct::leftJoin('users', 'users.id', '=', 'seller_products.user_id')
            ->select('seller_products.*')
           ->where('users.status','Active')->where('seller_products.status','active')
            ->latest('seller_products.created_at')->take(8)->get();

      $countries = Country::all();   
      $slider = Slider::where('show_home',"Yes")->with('Sliderimage')->first();
       $welcome_page_adds = Advertisement::leftJoin('contentpages', 'contentpages.id', '=', 'advertisements.page_id')
      ->whereRaw('? between start_date and end_date', [date('Y-m-d')])
      ->where('page','Welcome Page')->select('media_type','media_file','link_url','advertisements.title','position')->get();
   $all_categories =  DB::table('categories')
        ->where('parent_id', null)->latest()->take(12)->get(); 
      return view('welcome',compact('slider','products','welcome_page_adds','featured_products','countries','all_categories'));
    }
    public function TermsAndCondition()
    {
      $terms = Contentpage::where('page',"Terms & Conditions")->first();  
      return view('frontEnd.pages.TermsAndCondition',compact('terms'));
    }

    public function PrivacyPolicy()
    {
      $privacy = Contentpage::where('page',"Privacy Policy")->first();  
      return view('frontEnd.pages.PrivacyPolicy',compact('privacy'));
    }
    public function RefundPolicy()
    {
      $refund_policy = Contentpage::where('page',"Refund Policy")->first();
      return view('frontEnd.pages.RefundPolicy',compact('refund_policy'));
    }

    public function CookiePolicy()
    {
      $cookie_policy = Contentpage::where('page',"Cookie Policy")->first();
      return view('frontEnd.pages.CookiePolicy',compact('cookie_policy'));
    }

    
    public function AboutUs()
    {
      $about_us =  Contentpage::where('page',"About Us")->first();
      return view('frontEnd.pages.AboutUs',compact('about_us'));
    }

    public function mynetwork()
    {

       if(Auth::guard('user')->check())
      {

        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }

        
        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
      } 
      $user_id = $login_id = Auth::guard('user')->user()->id;
      $my_networks=Mynetworks::where('user_id',$login_id)->pluck('mynetwork_id')->first();
      $network_id=explode(',', $my_networks);
      $user = User::find($login_id); 
      $network_list =User::select('name','id','profile_pic')->whereIn('id',$network_id)->get();






      $chat_data = array();
      if (!$network_list->isEmpty()) {
        foreach($network_list as $key=>$row){
          $unreadCount = Message::where('from_user', $row->id)->where('to_user',$user_id)->where('message_status', 'unread')->count();
          $latestMessage = Message::where(function ($query) use ($user_id, $row) {
                  $query->where('from_user', $user_id)
                                  ->where('to_user', $row->id);
                          })
                          ->orWhere(function ($query) use ($user_id, $row) {
                              $query->where('from_user', $row->id)
                                  ->where('to_user', $user_id);
                          })->orderBy('id', 'desc')->take(5)->get();
                       //   dd($latestMessage);
          $chat_data[$key] = array('contact'=>$row,'latestMessage'=>$latestMessage,'unreadcount'=>$unreadCount);
          
        }
       } 



      $usertype = Auth::guard('user')->user()->usertype; 
      $values = [];
      if($usertype=="seller")
      {  
        
              $sellerProducts = $user->SellerProduct;
              foreach ($sellerProducts as $sproduct) {
                  foreach(explode(',', $sproduct->category_id) as $value) {
                    $values[] = trim($value);
                  }
              } 
              $values = array_unique($values);
      }
       
      $categorylists=Category::whereIn('id',$values)->pluck('name')->all();
      $allcategorylists=Category::select('name','id')->orderBy('name','asc')->get();
      return view('frontEnd.pages.my_networks',compact('chat_data','user','categorylists','allcategorylists'));
    }


    public function revokeFrom_network(Request $request)
    {
        $login_id = Auth::guard('user')->user()->id;
        $revok_userid=$request->get('user_id');
        $networks=Mynetworks::where('user_id',$login_id)->pluck('mynetwork_id')->first();
        $arrayData=explode(',', $networks);
        $network_users='';
        foreach( $arrayData as $value) {
          if($value==$revok_userid|| $value=='')
            continue;
          $network_users.=trim($value).',';
         }
        DB::table('mynetworks')
            ->where('user_id',$login_id)->update(['mynetwork_id'=>$network_users]);
        $msg="Removed from Networks";
        
        echo json_encode($msg);  
    }
    
    
    public function BuyerInstructions()
    {
      $data =  Contentpage::where('page',"Buyer Instructions")->first();
      return view('frontEnd.pages.BuyerInstructions',compact('data'));
    }
    public function SellerInstructions()
    {
      $data =  Contentpage::where('page',"Seller Instructions")->first();
      return view('frontEnd.pages.SellerInstructions',compact('data'));
    }
    public function ContactUs()
    {
      return view('frontEnd.pages.ContactUs');
    }

    
    public function TwitterSearch()
    {
      return view('frontEnd.pages.TwitterSearch');
    }

    public function ContactSubmit(Request $request)
    {
      request()->validate([
        "name" => ['required','string', 'max:255'],
        "email" =>['required'],
        "phone" =>['required'],
        "message" =>['required'],
      ]);

      $name = $request->input('name');
      $email = $request->input('email'); 
      $phone = $request->input('phone');
      $msg = $request->input('message');
      
       
      Mail::send('emails.ContactPageMail', ['name' => $name,'email' => $email,'phone' => $phone,'msg' => $msg], function($message) use($request){
        $message->to('info@fmcg.com');
      //$message->to($request->input('email'));
      $message->subject('New Contact Us - FMCG');
  });
   return back()->with('message', 'Mail has Been Send. We will contact you soon.');
    }



    

public function headsearch(Request $request)
    {
          $query = $request->get('search'); 
         return \Redirect::route('Product.Listing',['search_key'=>$query]);
          } 

  
    public function TypeaheadSearch(Request $request)
    {
          $query = $request->get('term');
          $productResult = SellerProduct::leftJoin('users', 'users.id', '=', 'seller_products.user_id')
                ->where('users.status','Active')
                ->where('seller_products.status','active')
                ->where(DB::raw('lower(seller_products.name)'), 'LIKE', '%'. strtolower($query). '%')
                ->select(DB::raw('seller_products.id AS new_id'),'seller_products.name','seller_products.product_price')
                ->with('SellerProductImage')
                ->take(5)->get();

          $categoryResult = Category::where(DB::raw('lower(name)'), 'LIKE', '%'. strtolower($query). '%')->select(DB::raw('id AS new_id'),'name','category_pic')->take(5)->get();
          $new_array=[];
          foreach($productResult as $data)
          { 
            $product_image=$data->SellerProductImage ;

            $img_url  = asset('/uploads/defaultImages/no_image.jpg');
            $product_images = SellerProductImage::where('product_id','=',$data->new_id)->get();
            $cnt=count($product_images) ;
           if($cnt>0) {
             if(!empty($product_images)) {
               foreach( $product_images as $productimage)
                  {     
                    if($productimage->thumbnail == 'yes') 
                    $img_url  = asset("/uploads/productImages/").'/'.$productimage->image_path;
                  }    
               } }    


          
            
            $new_row['title']= $data->name." (".$data->product_price.")";
            $new_row['image']= $img_url;
            $new_row['url']= route('view.Sproduct',$data->new_id);
            $row_set[] = $new_row;

          
            // $new_array[]=array('id'=>$data->new_id,'name'=>$data->name." (".$data->product_price.")",'image_path'=>$img_url);
          }
          
          foreach($categoryResult as $data)
          { 

            if($data->category_pic=="")
                $img_url =asset('/uploads/defaultImages/no_image.jpg');
             else
                $img_url =asset('/uploads/categoryImages/'.$data->category_pic); 
         
            $new_array[]=array('id'=>$data->new_id,'name'=>$data->name,'image_path'=>$img_url);

            $new_row['title']= $data->name;
            $new_row['image']= $img_url;
            $new_row['url']= route("Product.Listing", $data->name);
            $row_set[] = $new_row;
          }
          return response()->json($row_set);



    } 


    public function getsellerslist_search(Request $request)
{ 
  
    $start_from=$request->input('start_from');
    $per_page=$request->input('per_page');
    $seller_name_search= $request->input('seller_name');
    $category_id= $request->input('category_id');
    
    $sellers_list =SellerProduct::leftJoin('users', 'users.id', '=', 'seller_products.user_id')  
                       ->where('users.status','Active')->where('users.usertype','seller')
                       ->select('seller_products.*','users.name as user_name','users.profile_pic');                   

    if($seller_name_search!='')
            $sellers_list = $sellers_list->where(DB::raw('UPPER(CONCAT_WS(users.name,email,phone))'), 'LIKE','%'.$seller_name_search.'%');
          

     if($category_id!='0')
           $sellers_list = $sellers_list ->WhereRaw('find_in_set("'.$category_id.'",category_id)');
     
      
      $count = $sellers_list->groupby('seller_products.user_id')->get()->count();
      $sellers_list= $sellers_list->groupby('seller_products.user_id')->orderby('users.name','ASC')
      ->skip($start_from)->take($per_page)->get();

      
      $list_array=[];
      $userId = Auth::guard('user')->user()->id;
      $my_networks=Mynetworks::where('user_id',$userId)->pluck('mynetwork_id')->first();
      $network_id=explode(',', $my_networks); 
      foreach ($sellers_list as $data) {

            if(!empty($data->profile_pic)) 
                            $img_path = asset('/uploads/userImages/').'/'.$data->profile_pic;
            else  
                            $img_path = asset('uploads/defaultImages/default_avatar.png');

            if(in_array($data->user_id, $network_id)) 
              $network_exist=true;
            else 
              $network_exist=false;  

            $user = User::find($data->user_id);               

            $list_array[]=array(
              'id'=>$data->user_id,
              'name'=>$data->user_name,
              'company_street'=>$user->BuyerCompany->company_street??"",
              'company_name'=>$user->BuyerCompany->company_name??"",
              'company_location'=>$user->BuyerCompany->company_location??"",
              'img_path'=>$img_path,
              'network_exist'=>$network_exist
            );

      }
      $return_array=['count'=>$count,'sellers'=>$list_array];
      return json_encode($return_array);       

}




public function getnetwork_users_list()
{ 
  
      $login_id = Auth::guard('user')->user()->id;
      $my_networks=Mynetworks::where('user_id',$login_id)->pluck('mynetwork_id')->first();
      $network_id=explode(',', $my_networks);
      $network_list =User::select('name','id','profile_pic')->whereIn('id',$network_id)->orderBy('id','desc')->get();

      $mynetwork_list=[];
      foreach ($network_list as $data) {


        if(!empty($data->profile_pic)) 
                        $img_path = asset('/uploads/userImages/').'/'.$data->profile_pic;
        else  
                        $img_path = asset('uploads/defaultImages/default_avatar.png');

        $mynetwork_list[]=array(
          'id'=>$data->id,
          'name'=>$data->name,
          'company_street'=>$data->BuyerCompany->company_street??"",
          'company_name'=>$data->BuyerCompany->company_name??"",
          'company_location'=>$data->BuyerCompany->company_location??"",
          'img_path'=>$img_path,
        );
      }

      return json_encode($mynetwork_list);    
 }




}
