<?php

namespace App\Http\Controllers\FrontEnd;
use App\Http\Controllers\Controller;
use App\Models\OrderDetail;
use App\Models\Subscription;
use Carbon\Carbon;
use App\Models\Package;
use App\Models\PackageAccount;
use Session;
use App\Models\Country;
use DB;
use Illuminate\Support\Facades\Auth;
//use Request;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\User;
use App\Http\Controllers\FrontEnd\PublicMiddlewareController;
class PackageController extends Controller
{

    protected $PublicMiddlewareController;
    public function __construct(PublicMiddlewareController $PublicMiddlewareController)
    {
        $this->PublicMiddlewareController = $PublicMiddlewareController;
    }
    public function PackageListing(Request $request) {


      if(Auth::guard('user')->check())
       {

        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }
        if(Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               //Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
       }
        
      //$pkg_type = Request::get('pkg_type');
      $pkg_type = $request->get('pkg_type');  //
      if($pkg_type=='seller') //buyer profile become a seller button 
      $packages = Package::where('user_type','Seller')->get();
      elseif($pkg_type=='buyer') //buyer profile become a seller button 
      $packages = Package::where('user_type','Buyer')->get();  
      else  
      $packages = Package::all(); 
        
        return view('frontEnd.profile-creation.listPackages', compact('packages'));
    }



    public function PackageDetails(Request $request){
    
      if($request->get('extended') == 'yes') { // dd($request);
       $this->validate(
        $request, 
        ['accounts_id' => 'required'],
        ['required' => 'Please choose number of profiles']
    );
  //  dd($this->validate);
   }
      
      $packageId = $request->get('package_id');
      $accounts_id = $request->get('accounts_id');
      $order_type = "";
      if(!empty($request->order_type))
      $order_type =  $request->order_type; 
  $old_pkg_id =  $request->old_pkg_id; 
        $package = Package::find($packageId); 
          if(empty($package)) {
                return redirect()->route('package.listing')->with('message','No Package Found');
            } 
          $lowest = Package::orderBy('package_basic_price', 'asc')->where('id','!=',$packageId)->first(); //lowext price package at right side 
          return view('frontEnd.profile-creation.packageDetails',compact('package','lowest','accounts_id','order_type','old_pkg_id')); 
        }





        public function PackgeInvoice(Request $request){

          
          
          $packageId = $request->get('package_id'); 
          $subscription_id = $request->get('subscription_id');
          $subscription = Subscription::find($subscription_id);
         
          if(!empty($request->order_type))
          $order_type =  $request->order_type; 
      $old_pkg_id =  $request->old_pkg_id; 
            $package = Package::find($packageId); 
              if(empty($package)) {
                    return redirect()->route('package.listing')->with('message','No Package Found');
                } 
            
              return view('frontEnd.profile-creation.packageInvoice',compact('package','subscription')); 
            }








        public function Cart() {
          
          return view('frontEnd.profile-creation.Cart');  
        }
        public function SubscriptionCheckout(Request $request) {
          $countries = Country::all();
          $package_id =  $request->pkg_id;
          $accounts_id =  $request->accounts_id;
       
          $order_type = $old_pkg_id= "";
          if(!empty($request->order_type)) {
          $order_type =  $request->order_type;
      $old_pkg_id =  $request->old_pkg_id;
      }
          $accounts = PackageAccount::where('id',$accounts_id)->first();
          $package = Package::where('id',$package_id)->first();
          return view('frontEnd.profile-creation.subscriptionCheckout', compact('countries','package','accounts','order_type','old_pkg_id'));  
        }



 public function submitCheckout(Request $request) {
          $user_id = Auth::guard('user')->user()->id;
          request()->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255'],
            'phone' => ['required', 'string'],
            'address' => ['required', 'string'],
            'city' => ['required', 'string'],
            'zip' => ['required', 'string','max:6'],
            'country' => ['required'],
        ]);
        $input = [
            'name' => $request->get('name'),
            'accounts_id' => $request->get('accounts_id'),
            'order_type' => $request->get('order_type'),
            'package_id' => $request->get('package_id'),
            'user_id' => $user_id,
            'email' => $request->get('email'),
            'phone' => $request->get('phone'),
            'address' => $request->get('address'),
            'city' => $request->get('city'),
            'zip' => $request->get('zip'),
            'country' => $request->get('country'),
            'package_id' => $request->get('package_id'),
            
        ];  

        $package_id = $request->get('package_id');
        $accounts_id = $request->get('accounts_id');
        $accounts = PackageAccount::where('id',$accounts_id)->first();
        $package = Package::where('id',$package_id)->first();
        $order_type = $old_pkg_id = "";
          if(!empty($request->order_type)) {
     $order_type =  $request->order_type;
      $old_pkg_id = Session::get('old_pkg_id');
      }
        $order_id = OrderDetail::create( $input )->id;
        
        
        return view('frontEnd.profile-creation.Cart' ,compact('package','accounts','order_id','order_type','old_pkg_id'));

        }


        public function submitCart(Request $request) { 

         
          $user_id = Auth::guard('user')->user()->id;
        //   request()->validate([
        //     'terms_check' => ['accepted'],
        //     'privacy_check' => ['accepted'],
        // ]); 
        
        $package_id = $request->get('package_id'); 

        $accounts_id = $request->get('accounts_id');
      
        $order_type = $old_pkg_id ="";
          if(!empty(Session::get('order_type')))
         {  
          $order_type = Session::get('order_type');
         $old_pkg_id = Session::get('old_pkg_id');

   } // dd($order_type);
        $order_id = $request->get('order_id');

        $accounts = PackageAccount::where('id',$accounts_id)->first();
        $package = Package::where('id',$package_id)->first();
        
        
        
           
        
        $input = [
          'user_id' =>  $user_id,
          'package_id' => $package_id,
         // 'auto_renewal' => $request->get('auto_renewal'),
          'type' => $package->user_type,
          'date' => Carbon::today(),
          'order_id' => $request->get('order_id'),
      ];  

       $package_validity = $package->package_validity;
       
   if($order_type == "Renew") 
      { //dd(Session::get('old_pkg_id'));
              $input['status'] = "Renewed";
              DB::table('subscriptions')
            ->where('user_id', $user_id)
            ->where('package_id', Session::get('old_pkg_id'))
            ->limit(1)
            ->update(['status' => 'Renewed']);


              $old_subscription = Subscription::where('user_id',$user_id)->where('package_id',$old_pkg_id)
              ->orderBy('id', 'DESC')
              ->first(); //prev subscription detail to calculate exp dt
              
              $id = $old_subscription->id;
              $current_endDate = $old_subscription->expairy_date;// dd($current_endDate);
              $current_endDate = Carbon::createFromFormat('Y-m-d', $current_endDate); 
              
              if($current_endDate->isPast())  {    //expired packages 
                
              if($package_validity=="3 months")  $EndDate = Carbon::now()->addMonths(3);
              if($package_validity=="6 months")  $EndDate = Carbon::now()->addMonths(6);
              if($package_validity=="One year")  $EndDate = Carbon::now()->addMonths(12);
             
              $input['expairy_date'] = $EndDate->toDateString(); // carbon date format to noramal date
              }
              else { //active packages
                
              if($package_validity=="3 months") { $EndDate1 = $current_endDate->addMonths(3); } 
              if($package_validity=="6 months") { $EndDate1 = $current_endDate->addMonths(6); }
              if($package_validity=="One year") { $EndDate1 = $current_endDate->addMonths(12); }
              $input['expairy_date'] = $EndDate1->toDateString(); // carbon date format to noramal date
              }


            $input['status'] = "Active";
            Subscription::create( $input );

            }  

            else if($order_type == "Upgrade") {
             $input['status'] = "Upgraded";  //dd(Session::get('old_pkg_id'));
             DB::table('subscriptions')
            ->where('user_id', $user_id)
            ->where('package_id', Session::get('old_pkg_id'))
            ->limit(1)
            ->update(['status' => 'Upgraded']);
      
       $input['status'] = "Active";
        $purchsed_date = Carbon::today(); 
        if($package_validity=="3 months")
        $Enddate = Carbon::now()->addMonths(3);//add 3 months from date of purchase
        if($package_validity=="6 months")
        $Enddate = Carbon::now()->addMonths(6);//add 3 months from date of purchase
        if($package_validity=="One year")
        $Enddate = Carbon::now()->addMonths(12);//add 3 months from date of purchase

        $input['expairy_date'] = $Enddate; 
        Subscription::create( $input );
            }

        else {
        $input['status'] = "Active";
        $purchsed_date = Carbon::today(); 
        if($package_validity=="3 months")
        $Enddate = Carbon::now()->addMonths(3);//add 3 months from date of purchase
        if($package_validity=="6 months")
        $Enddate = Carbon::now()->addMonths(6);//add 3 months from date of purchase
        if($package_validity=="One year")
        $Enddate = Carbon::now()->addMonths(12);//add 3 months from date of purchase

        $input['expairy_date'] = $Enddate; 
        Subscription::create( $input );
            }
        
        // Update User Type
        $usertype = Package::find($package_id)->user_type;  
        $input = [
          'usertype' => $usertype,
        ];
        Session::forget('old_pkg_id');
        Session::forget('order_type');
       DB::table('users')
            ->where('id', $user_id)
            ->update($input);
            
            return view('frontEnd.profile-creation.orderSuccess');

        }
        
        
        public function OrderSuccess(Request $request) {
       return view('frontEnd.profile-creation.orderSuccess');
    }


    public function SubscriptionDetails() {


       if(Auth::guard('user')->check())
      {

        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }

        
        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
      } 

      if(Auth::guard('user')->user()->seller_type=='Co-Seller')
           return redirect()->route('home');
        
      $userId = Auth::guard('user')->user()->id;
      $user=User::find($userId) ;
     // $orders = $user->OrderDetail;//orders  of logged in users

     $subscriptions = Subscription::where('user_id',$userId)
                // ->where('status','Active')
                ->groupBy('package_id')
                ->orderBy('id','DESC')
                ->get();
      // $orders = OrderDetail::where('user_id',$userId)
      //           ->groupBy('package_id')
      //           ->orderBy('id','DESC')
      //           ->get();

      
      return view('frontEnd.profile-creation.SubscriptionDetails', compact('user','subscriptions'));
  }

  public function UpgradePackage(Request $request) {
    Session::put('old_pkg_id', $request->get('old_pkg_id'));
    Session::put('order_type', $request->get('order_type'));
    $packagePrice = $request->get('package_basicPrice');
    $order_type = $request->get('order_type');
    $old_pkg_id = $request->get('old_pkg_id');
    $userId = Auth::guard('user')->user()->id;
    $user=User::find($userId) ;
    $orders = $user->OrderDetail;//orders  of current user
    $package_ids = $orders->pluck('package_id')->all(); //all package ids purchased
    $userType = Auth::guard('user')->user()->usertype;
    
      $packages = Package::select('*')
      ->when($userType == 'seller', function ($q) use ($packagePrice) {
        return $q->where('package_basic_price', '>', $packagePrice)->where('user_type','Seller');})
      ->when($userType == 'buyer', function ($q) use ($packagePrice) {
          return $q->where('user_type','Seller')->orwhere('user_type','Buyer')->where('package_basic_price', '>', $packagePrice)
          ;})
      ->whereNotIn('id', $package_ids)->get(); 
      
    return view('frontEnd.profile-creation.listPackages', compact('packages','packagePrice','order_type','old_pkg_id'));
}

public function RenewPackage(Request $request) {
  Session::put('old_pkg_id', $request->get('old_pkg_id'));
  Session::put('order_type', $request->get('order_type'));
      $packageId = $request->get('package_id');
      $accounts_id = $request->get('accounts_id');
      $order_type = $request->get('order_type');
      $old_pkg_id = $request->get('old_pkg_id');
        $package = Package::find($packageId); 
          if(empty($package)) {
                return redirect()->route('package.listing')->with('message','No Package Found');
            } 
          $lowest = Package::orderBy('package_basic_price', 'asc')->where('id','!=',$packageId)->first(); //lowext price package at right side 
          return view('frontEnd.profile-creation.packageDetails',compact('package','lowest','accounts_id','order_type','old_pkg_id')); 
}
   
} 
