<?php

namespace App\Http\Controllers\FrontEnd;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Category;
use App\Models\Product;
use App\Models\Country;
use App\Models\ProductImage;
use App\Models\ProductReview;
use App\Models\SellerMessage;
use App\Models\SellerProduct;
use App\Models\Wishlist;
use App\Models\Productbrand;
use App\Models\SearchCondition;
use DB;
use Mail;
use App\Models\ReviewSubmit;
use App\User;
use URL;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use App\Http\Controllers\FrontEnd\PublicMiddlewareController;

class ProductController extends Controller
{

    protected $PublicMiddlewareController;
    public function __construct(PublicMiddlewareController $PublicMiddlewareController)
    {
        $this->PublicMiddlewareController = $PublicMiddlewareController;
    }



//     public function ProductDetails($productId){
//     $product = Product::where('id',$productId)->first();
//   if( empty($product)) return redirect('home');
//   $user_id = $user="";
//   if(Auth::guard('user')->check()) { 
    
//     $user_id = Auth::guard('user')->user()->id;
//     $user = User::find($user_id);
//     } 

//     $categories = Category::where('parent_id', null)->get();

//     if(!empty($product->available_countries))
//     $country_ids = explode(",",$product->available_countries); 
//     else
//     $country_ids =[];

//       // $country_ids = explode(',',$product->available_countries);
//         $varients = Product::all();
//         $productReviews = ProductReview::where('product_id','=',$productId)->get();
//         $product_images = ProductImage::where('product_id','=',$productId)->get();
//         $countries = Country::all(); 
//         $user_exists = 'no'; dd($user_id);
//         if($user_id!="")
//         $user_exists =  ProductReview::where('product_id',$productId)->where('user_id', $user_id)->exists();
//         $TotalStar = ProductReview::where('product_id',$productId)->sum('star_rating');
//         $Starcount = ProductReview::where('product_id',$productId)->count(); 
//         $avgStar =0;
//         if($Starcount>0)
//         $avgStar = $TotalStar/$Starcount; 
        
//     return view('frontEnd.products.product-details',compact('user','Starcount','user_exists','avgStar','productReviews','productId','product','categories','countries','varients','product_images'));
   
// }

public function ReviewSubmit(Request $request)
    {
      request()->validate([
        "name" => ['required','string', 'max:255'],
        "email" =>['required'],
        "review_title" =>['required'],
        "review" =>['required'],
      ]);
      $user_id = Auth::guard('user')->user()->id;
      $input = [
        'user_id' => $user_id,
        'product_id' => $request->get('product_id'),
        'name' => $request->get('name'),
        'email' => $request->get('email'),
        'review_title' => $request->get('review_title'),
        'review' => $request->get('review'),
        'star_rating' => $request->get('star_rating'),
        
   ];
  $product_review = ProductReview::create( $input );
 
   return back()->with('message', 'Thank you for your review.');

}

  public function autocompleteSproductFrontend(request $request) {
      $user_id = Auth::guard('user')->user()->id;
        $products = SellerProduct::where('status','active')
        ->where('name','Like',$request->term.'%')
        ->where('user_id',$user_id)
        ->select("id","name")
        ->limit(10)
        ->get();
        return $products;
        

    }

public function SelleMessage(Request $request)
    {
      request()->validate([
        "name" => ['required','string', 'max:255'],
        "email" =>['required'],
        "phone" =>['required'],
        "message" =>['required'],
      ]);

    $input['name'] = $name = $request->input('name');
    $input['email'] =   $email = $request->input('email'); 
    $input['phone'] =   $phone = $request->input('phone');
    $input['message'] =   $msg = $request->input('message');
    $input['product_id'] =   $product_id = $request->input('product_id');
    $input['seller_id'] =   $seller_id = $request->input('seller_id');
    $input['user_id'] =   $user_id = Auth::guard('user')->user()->id;

//dd($request->input('seller_email'));

      $seller_email = $request->input('seller_email');


      SellerMessage::create($input);
      $productname=SellerProduct::where('id',$product_id)->pluck('name')->first();
      Mail::send('emails.SellerMessage', ['name' => $name,'product_id' => $product_id,'productname' => $productname,'email' => $email,'phone' => $phone,'msg' => $msg], function($message) use($request){
     
       
      $message->to($request->input('seller_email'));
      $message->subject('New Message - FMCG');
  });
   //return back()->with('message', 'Mail has Been Send. We will contact you soon.');
   return response()->json(['success'=>'<div class="alert alert-success" >Message has been send successfully.</dv>']);
    }


 public function searchcat()
{

    $cat = \Input::get('cat');

    $cat = (int) $cat;

    $vacancies = \Vacancy::where('category_id', '=', $cat)->get();

    return \View::make('vacancies.empty')->with('vacancies', $vacancies); 

}



// public function loadsubcategory(Request $request)
// { 

//   if($request->input('category_id')!='')
//         $category_id= explode(",", $request->input('category_id'));
//   else
//         $category_id=[];

//    if(!empty($category_id))   
//    {

//     $mainarray=[];
//     foreach ($category_id as $value) {
//            $categorylist=Category::where('parent_id',$value)->pluck('id')->all();
            
//            foreach ($categorylist as $value) {
//              $category=Category::where('parent_id',$value)->pluck('id')->all();
//              array_push($mainarray,$value);
              
//              for ($i=0; $i<count($mainarray);$i++)
//                    {
//                      $category1=Category::where('parent_id',$mainarray[$i])->pluck('id')->all();
//                       foreach ($category1 as  $value2) 
//                            array_push($mainarray,$value2);                             
//                   }
//                 }
//      }
//           $sub_category_list=Category::whereIn('id',array_unique($mainarray))->orderBy('id','asc')->pluck('id','name')->all();
//          return json_encode($sub_category_list);
//        }
//        else
//          return json_encode([]);
// }




public function extendedidSearch(Request $request)
{ 
    $start_from=$request->input('start_from');
    $per_page=$request->input('per_page');

    $central_listing=[];
    $category_id=[];

      $price_range= explode("-", $request->input('price_range'));
      $start_range=$price_range[0];
      $end_range=$price_range[1];
      $search_key= $request->input('search');
	  
$header_search_key=$request->input('header_search_key');
	if($header_search_key!=''){  // No Category only serch terms
	
                
                
               
	             $products = SellerProduct::leftJoin('users', 'users.id', '=', 'seller_products.user_id')
		  
                ->select(['seller_products.name AS prd_name', 'seller_products.*'])
                ->where('users.status','Active')
                ->where('seller_products.status','active')
                ->where(DB::raw('lower(seller_products.name)'), 'LIKE', '%'. strtolower($header_search_key). '%')
                ->with('SellerProductImage');
				
		if($request->input('category_id')!='') {
        $categorylist= explode(",", $request->input('category_id'));         
        foreach ($categorylist as $value) 
                {
                    if(!in_array($value, $category_id))
                        array_push($category_id,$value);
                                              
                for ($i=0; $i<count($category_id);$i++)
                {
                    $category1=Category::where('parent_id',$category_id[$i])->get();
                        foreach ($category1 as  $value2) 
                        {   
                              if(!in_array($value2->id, $category_id))
                                     array_push($category_id,$value2->id);
                        }                             
                 }
				  $products= $products->where(function ($query) use ($category_id,$start_range,$end_range,$search_key) {
                    foreach ($category_id as $id)
                    {
                        $query->orWhereRaw('find_in_set("'.$id.'",category_id)')
                        ->whereBetween('product_price', [$start_range, $end_range])
                        ->where('seller_products.status','active');
                    }
            });
                
               }
			   
			   $products= $products->skip($start_from)->take($per_page)->get();  
			   
	}
				
				
				
			if($search_key!='')
              $products = $products->where(DB::raw('UPPER(CONCAT(name,COALESCE(product_description,"")))'), 'LIKE','%'.strtoupper($search_key).'%');
		  
		
     
        
          
        if($request->input('country_id')!=''){
               $country_id= $request->input('country_id');
               $products = $products ->WhereRaw('find_in_set("'.$country_id.'",available_countries)');
        }   

        if($request->input('brand_id')!=''){
               $brand_id= explode(",", $request->input('brand_id'));
               $products= $products->whereIn('brands',$brand_id );
        }  
				
			$count = $products->count();
             $products= $products->skip($start_from)->take($per_page)->get();  
				
				
				
			$brand_lists = $central_listing =[];
	        $search_key =  "";
	       
           $left_menu_list=[];
       $values = [];
	   $sellerProducts  = SellerProduct::select('seller_products.*')->with('SellerProductImage')
      ->leftJoin('users', 'users.id', '=', 'seller_products.user_id')  
      ->where('users.status','Active')
	  ->where(DB::raw('lower(seller_products.name)'), 'LIKE', '%'. strtolower($header_search_key). '%')
	  ->where('seller_products.status','active')
      ->latest('seller_products.created_at')->get(); 
	  
          foreach ($sellerProducts as $sproduct) {
          foreach(explode(',', $sproduct->category_id) as $value) {
         $values[] = trim($value);
         }
         } 
$values = array_unique($values); 
$categorylist=Category::where('parent_id',null)->whereIn('id',$values)->get(); 
foreach ($categorylist as  $value2) 
array_push($left_menu_list,['id'=>$value2->id,'name'=>$value2->name]);
                                                                   
  
	  $Trendingproducts = SellerProduct::select('seller_products.*')->with('SellerProductImage')
      ->leftJoin('users', 'users.id', '=', 'seller_products.user_id')  
      ->where('users.status','Active')
	  ->where('seller_products.status','active')
      ->latest('seller_products.created_at')->take(5)->get();
	  
	  
	 $data_return=[];
             foreach($products as $data) 
             {

                  $prd_img = URL::asset('/images/no-image.jpg'); 
                  foreach($data->SellerProductImage as $prod_img) {
                         if($prod_img->thumbnail=='yes')
                              $prd_img = URL::asset('/uploads/productImages/'.$prod_img->image_path);
                  }

                    $country_name=Country::whereIn("id",explode(",", $data->available_countries))->pluck('name')->all();


                    $data_return[]= array('product_name'=>$data->prd_name,'product_thumbnail'=>$prd_img,'available_countries'=>$country_name,'price'=>$data->product_price,'stock_count'=>$data->stock_count,'product_id'=>$data->id);
            }


             $return_array=['count'=>$count,'product_data'=>$data_return,'central_listing'=>$central_listing];			
				
				
                       
}

else{


   if($request->input('category_id')!='')
         
        $categorylist= explode(",", $request->input('category_id'));         
    

    else
    {  
                $category=Category::where('name', 'LIKE',$request->input('topcategorysearch'))->first() ;
                $categorylist=Category::where('parent_id',$category->id)->pluck('id')->all();                          
                array_push($category_id,$category->id); 
    }


                foreach ($categorylist as $value) 
                {
                    if(!in_array($value, $category_id))
                        array_push($category_id,$value);
                                              
                for ($i=0; $i<count($category_id);$i++)
                {
                    $category1=Category::where('parent_id',$category_id[$i])->get();
                        foreach ($category1 as  $value2) 
                        {   
                              if(!in_array($value2->id, $category_id))
                                     array_push($category_id,$value2->id);
                        }                             
                 }
                
               }
			   
		$products = SellerProduct::leftJoin('users', 'users.id', '=', 'seller_products.user_id')  
          ->select(['seller_products.name AS prd_name', 'seller_products.*'])
                       ->where('users.status','Active')
                        ->where(function ($query) use ($category_id,$start_range,$end_range,$search_key) {
                    foreach ($category_id as $id)
                    {
                        $query->orWhereRaw('find_in_set("'.$id.'",category_id)')
                        ->whereBetween('product_price', [$start_range, $end_range])
                        ->where('seller_products.status','active');
                    }
            });

      
        if($search_key!='')
              $products = $products->where(DB::raw('UPPER(CONCAT(name,COALESCE(product_description,"")))'), 'LIKE','%'.strtoupper($search_key).'%');
		  
		
     
        
          
        if($request->input('country_id')!=''){
               $country_id= $request->input('country_id');
               $products = $products ->WhereRaw('find_in_set("'.$country_id.'",available_countries)');
        }   

        if($request->input('brand_id')!=''){
               $brand_id= explode(",", $request->input('brand_id'));
               $products= $products->whereIn('brands',$brand_id );
        }  


        


             $count = $products->count();
             $products= $products->skip($start_from)->take($per_page)->get();     


             $data_return=[];
             foreach($products as $data) 
             {

                  $prd_img = URL::asset('/images/no-image.jpg'); 
                  foreach($data->SellerProductImage as $prod_img) {
                         if($prod_img->thumbnail=='yes')
                              $prd_img = URL::asset('/uploads/productImages/'.$prod_img->image_path);
                  }

                    $country_name=Country::whereIn("id",explode(",", $data->available_countries))->pluck('name')->all();


                    $data_return[]= array('product_name'=>$data->prd_name,'product_thumbnail'=>$prd_img,'available_countries'=>$country_name,'price'=>$data->product_price,'stock_count'=>$data->stock_count,'product_id'=>$data->id);
            }


             $return_array=['count'=>$count,'product_data'=>$data_return,'central_listing'=>$central_listing];

}
  return json_encode($return_array);    



}






public function ProductListing($search_key=null)
{
 $header_search_key = $search_key;

    if(Auth::guard('user')->check())
       {


        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }

        
        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
       }

    $user_id = $user = $wish_listed = "";
    if(Auth::guard('user')->check()) { 
      $user_id = Auth::guard('user')->user()->id;
      $user = User::find($user_id);
      $usertype = Auth::guard('user')->user()->usertype;
     // $wish_listed=  Wishlist::where('product_id','=',$productId)->where('user_id','=',$user_id)->pluck('wishlist')->first();
    }
 
    $countries = Country::all(); 
		$categoryCount = Category::where(DB::raw('lower(name)'), 'LIKE', ''. strtolower($search_key). '')->count();
	
	$search_conditions = SearchCondition::pluck('search_name')->all();   
       
//this if category exists
 if($categoryCount>0){
	
    $category_id=Category::where('name', 'LIKE',$search_key)->pluck('id')->all() ;
    $categorylist=Category::whereIn('parent_id',$category_id)->get();
    $category_id_all=$central_listing=[];
    foreach ($categorylist as $value) 
    {
        if(!in_array($value->id, $category_id_all))
            array_push($category_id_all,$value->id);


        array_push($central_listing,['id'=>$value->id,'name'=>$value->name]);  
        
                                  
    for ($i=0; $i<count($category_id_all);$i++)
    {
        $category1=Category::where('parent_id',$category_id_all[$i])->get();
            foreach ($category1 as  $value2) 
            {   
                  if(!in_array($value2->id, $category_id_all))
                         array_push($category_id_all,$value2->id); 
            }                             
     }
   }

   $left_menu_list=[]; 
    for ($i=0; ($i<count($category_id_all) && count($categorylist)>0);$i++)
    {
           $categorylist=Category::where('id',$category_id_all[$i])->get();
           foreach ($categorylist as  $value2) 
                        array_push($left_menu_list,['id'=>$value2->id,'name'=>$value2->name]);
                                                                   
    }

    
    //if(count($category_id_all)==0)
     $category_id_all[]=$category_id[0];

    

    $brand_lists = SellerProduct::leftJoin('productbrands', 'productbrands.id', '=', 'seller_products.brands')
          ->leftJoin('users', 'users.id', '=', 'seller_products.user_id')
          ->orWhere(function($query) use($category_id_all) {
              foreach($category_id_all as $term) {
                  $query->orWhereRaw('find_in_set("'.$term.'",category_id)')->where('seller_products.status','active');
              };
        })
    ->where('users.status','Active')
    ->select('productbrands.id','productbrands.name',DB::raw('count(*) as count'))
    ->groupBy('seller_products.brands')->get();


    $search_conditions = SearchCondition::pluck('search_name')->all();    
   
   

    $Trendingproducts = SellerProduct::select('seller_products.*')->with('SellerProductImage')
      ->leftJoin('users', 'users.id', '=', 'seller_products.user_id')  
      ->where('users.status','Active')
      ->Where(function($query) use($category_id_all) {
              foreach($category_id_all as $term) {
                  $query->orWhereRaw('find_in_set("'.$term.'",category_id)')->where('seller_products.status','active');
              };
        })
    ->latest('seller_products.created_at')->take(5)->get();
	
$header_search_key = '';
    return view('frontEnd.products.product-listing',compact('user','header_search_key','brand_lists','search_conditions','search_key','Trendingproducts','left_menu_list','central_listing'));
}


else {
	  $brand_lists = $central_listing =[];
	  $search_key =  "";
	       
       $left_menu_list=[];
          
	   $values = [];
	   $sellerProducts  = SellerProduct::select('seller_products.*')->with('SellerProductImage')
      ->leftJoin('users', 'users.id', '=', 'seller_products.user_id')  
      ->where('users.status','Active')
	  ->where(DB::raw('lower(seller_products.name)'), 'LIKE', '%'. strtolower($header_search_key). '%')
	  ->where('seller_products.status','active')
      ->latest('seller_products.created_at')->get(); 
	  
          foreach ($sellerProducts as $sproduct) {
          foreach(explode(',', $sproduct->category_id) as $value) {
         $values[] = trim($value);
         }
         } 
$values = array_unique($values); 
$categorylist=Category::where('parent_id',null)->whereIn('id',$values)->get(); 
foreach ($categorylist as  $value2) 
array_push($left_menu_list,['id'=>$value2->id,'name'=>$value2->name]);
		   
		                                             
  
	  $Trendingproducts = SellerProduct::select('seller_products.*')->with('SellerProductImage')
      ->leftJoin('users', 'users.id', '=', 'seller_products.user_id')  
      ->where('users.status','Active')
      ->latest('seller_products.created_at')->take(5)->get();
	  
		   return view('frontEnd.products.product-listing',compact('user','header_search_key','brand_lists','search_conditions','search_key','Trendingproducts','left_menu_list','central_listing'));
     }














}














}
