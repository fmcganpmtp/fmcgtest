<?php

namespace App\Http\Controllers\FrontEnd;
use App\Http\Controllers\Controller;
 use App\Models\User;
use App\Models\Message;
use App\Models\Mynetworks;
use App\Models\Wishlist;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;
class MessageController extends Controller
{
    public function __construct()
    {
      //  $this->middleware('auth');
    }


    /**
     * getLoadLatestMessages
     *
     *
     * @param Request $request
     */
    public function getMyContacts(Request $request){
        $user_id =  Auth::guard('user')->user()->id;
        //$contacts = Mynetworks::select('users.id','users.name','users.profile_pic','mynetworks.mynetwork_id')->join('users', 'users.id', 'mynetworks.mynetwork_id')->where('mynetworks.user_id',$user_id)->get();
        $a = Message::select('messages.to_user as mynetwork_id')->where('from_user', $user_id)->groupBy('to_user')->pluck('mynetwork_id')->toArray();

        $b = Message::select('messages.from_user as mynetwork_id')->where('to_user', $user_id)->groupBy('from_user')->pluck('mynetwork_id')->toArray();
        if(is_array($a)&&is_array($b))
        $unioncontacts = array_merge($a,$b);
        else if(is_array($a))
        $unioncontacts = $a;
        else if(is_array($b))
        $unioncontacts =  $b;
        else
        $unioncontacts =[];
        $unioncontacts = array_unique($unioncontacts);
		$return_array=array();
		$chat_data = array();
		$contacts = User::select('users.id','users.name','users.profile_pic','buyer_companies.company_name')->leftJoin('buyer_companies', 'users.id', '=', 'buyer_companies.user_id')->whereIn('users.id',$unioncontacts)->get();
		if (!$contacts->isEmpty()) {
			foreach($contacts as $key=>$row){  
				$unreadCount = Message::where('from_user', $row->id)->where('to_user',$user_id)->where('message_status', 'unread')->count();
				$latestMessage = Message::where(function ($query) use ($user_id, $row) {
								$query->where('from_user', $user_id)
                                ->where('to_user',$row->id);
                        })
                        ->orWhere(function ($query) use ($user_id, $row) {
                            $query->where('from_user', $row->idd)
                                ->where('to_user', $user_id);
                        })->latest()
                        ->first();
				$chat_data[$key] = array('contact'=>$row,'latestMessage'=>$latestMessage,'unreadcount'=>$unreadCount);
				
			}
		}
		 $return_array = array('ajax_status' => true, 'chat_data' => $chat_data);
        return response()->json($return_array);
    }
     public function getMyMessages($id = null){
       $user_id =  Auth::guard('user')->user()->id;
         Message::where('from_user', $id)->where('to_user', $user_id)->update([ 'message_status' => 'read', ]);
    	$chat_data = Message::select('id','from_user','to_user','message_type','message','file','message_status',DB::raw('DATE(created_at) as Date'),
       DB::raw('DATE_FORMAT(TIME(created_at) ,"%H:%i")as Time'))->where(function ($query) use ($user_id, $id) {
							$query->where('from_user', $user_id)
                            ->where('to_user', $id);
                    })
                    ->orWhere(function ($query) use ($user_id, $id) {
                        $query->where('from_user', $id)
                            ->where('to_user', $user_id);
                    })->orderBy('id', 'DESC')->paginate(50);;
        $userdetails = User::select('name','profile_pic')->where('id', $id)->first();
		$return_array = array('ajax_status' => true, 'chat_data' => $chat_data,'userdetails'=>$userdetails);
        return response()->json($return_array);
    }
    public function sentMessages(Request $request){
        $user_id =  Auth::guard('user')->user()->id;
        $file = $request->file('file');
        $insert_id=  0;
        if($file){
            $file = $request->file('file');
            $fileName = time().'.'.$request->file->extension();
            $request->file->move(public_path('/assets/uploads/chat/'), $fileName);
            $insert_id= Message::create([
            'from_user' => $user_id,
            'to_user' => $request->selected_id,
            'message_type' => $request->message_type,
            'message' => $request->message,
            'file'=>$fileName,
            'message_status' => 'unread', 
            ])->id;
        }else{
            $insert_id= Message::create([
            'from_user' => $user_id,
            'to_user' => $request->selected_id,
            'message_type' => $request->message_type,
            'message' => $request->message,
            'message_status' => 'unread', 
        ])->id;
        } 
        $chat_data = Message::find( $insert_id);
		$return_array = array('ajax_status' => true,'chat_data'=>$chat_data);
        return response()->json($return_array);
    }
    public function checkNewMessage($senter_id =null,$last_message =null){
         
        $user_id =  Auth::guard('user')->user()->id;
    	$chat_data = Message::where(function ($query) use ($user_id, $senter_id,$last_message) {
							$query->where('from_user', $user_id)
                            ->where('to_user', $senter_id)->where('id','>',$last_message);
                    })
                    ->orWhere(function ($query) use ($user_id, $senter_id,$last_message) {
                        $query->where('from_user', $senter_id)
                            ->where('to_user', $user_id)->where('id','>',$last_message);
                    })->orderBy('id', 'ASC')->get();
        $userdetails = User::select('name','profile_pic')->where('id', $senter_id)->first();
		$return_array = array('ajax_status' => true, 'chat_data' => $chat_data,'userdetails'=>$userdetails);
        return response()->json($return_array);
    } 
    public function checkNotifications(Request $request){
        $user_id =  Auth::guard('user')->user()->id;
        $wishlist_count = Wishlist::where('user_id','=',$user_id)->where('wishlist','=','Yes')->count();
        $chat_count = Message::where('to_user',$user_id)->where('message_status', 'unread')->count();
        $return_array = array('ajax_status' => true,'wishlist_count'=>$wishlist_count,'chat_count'=>$chat_count);
        return response()->json($return_array);
    } 
}