<?php

namespace App\Http\Controllers\FrontEnd;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Models\Category;
use App\User;
use App\Models\ProductImage;
use App\Models\SellerProduct;
use App\Models\SellerProductImage;
use App\Models\Wishlist;
use App\Models\ProductReview;
use App\Models\Productbrand;
use App\Models\BusinessInsight;
use App\Models\ProfileAccountDeleteRequest;
use File;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use App\Imports\SellerProductImport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Excel as ExcelExcel;
use Illuminate\Support\Facades\Mail;
use App\Models\Product;
use App\Models\Country;
use App\Http\Controllers\FrontEnd\PublicMiddlewareController;
use Illuminate\Http\Request;
use Response;
use Carbon\Carbon;

class SellerController extends Controller
{

    protected $PublicMiddlewareController;
    public function __construct(PublicMiddlewareController $PublicMiddlewareController)
    {
        $this->PublicMiddlewareController = $PublicMiddlewareController;
    }

    public function SellerProductList(){

      if(Auth::guard('user')->check())
      {


        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }

        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
      }

        $user_id = Auth::guard('user')->user()->id;
        $usertype = Auth::guard('user')->user()->usertype;
        $user = User::find($user_id);
        //$products = SellerProduct::where('user_id',$user_id)->get();
        $products = SellerProduct::where('user_id',$user_id)->with('SellerProductImage')->latest()->paginate(20);
        $categories = Category::where('parent_id', null)->get();
        if($usertype=="seller") //if not seller redirect to home
        return view('frontEnd.seller.ListProducts',compact('user','products','categories'));
        else
        return redirect()->route('home');
    }

    public function AddSellerProduct(){ 

        if(Auth::guard('user')->check())
        {

        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }
        } 
        $user_id = Auth::guard('user')->user()->id;
        $usertype = Auth::guard('user')->user()->usertype;

        $user = User::find($user_id); 
        $varients = Product::all();
        $Productbrand = Productbrand::orderBy('name')->get();
        $countries = Country::all();
        $categories = Category::where('parent_id', null)->orderBy('name')->get();
        if($usertype=="seller") //if not seller redirect to home
       return view('frontEnd.seller.AddSellerProduct',compact('user','varients','countries','categories','Productbrand')); 
        else
        return redirect()->route('home');
    }


function  ajaxSubcat(Request $request) { 
$cat_id = $request->cat_id;
$subcategories = DB::table('categories')->where('parent_id','=',$cat_id)->get();
return Response::json($subcategories);}

    public function AddUsingExistingProduct(){ 
        $user_id = Auth::guard('user')->user()->id;
        $usertype = Auth::guard('user')->user()->usertype;
        $user = User::find($user_id);
        if($usertype=="seller") //if not seller redirect to home
        return view('frontEnd.seller.AddExistingSellerProduct',compact('user'));
        else
        return redirect()->route('home');
    }

    public function autoCompleteProduct(request $request) {
        if($request->ajax()){ 
            $products = Product::where('name','Like',$request->name.'%')->get();
            $output='';
            if(count($products)>0){
                $output='<ulclass="list-group" style="dispaly:block;position:relative;z-index:1">';
                foreach($products as $product){
                    $output .= '<li class="list-group-item" id="'.$product->id.'">'.$product->name.'</li>';
                }
                $output .= '</ul>';
                
            }
            else{
                $output .= '<li class="list-group-item">No Data Found</li>';
            }
            return $output;
        }
    }


    public function AddProductSellerExisting( Request $request){
         $request->validate([
                'product_id'      => 'required',
            ]);
            $productId = $request->input('product_id'); 
            $product = Product::find($productId);
            $varients = Product::all();
            $countries = Country::all();
            $Productbrand = Productbrand::orderBy('name')->get();
           // $product_images= ProductImage::find($productId); 
            $product_images = ProductImage::where('product_id','=',$productId)->get();
            $product_id_list=  ProductImage::where('product_id','=',$productId)->pluck('id')->all();
            $categories = Category::where('parent_id', null)->orderBy('name')->get();
            return view('frontEnd.seller.AddSellerProduct3' , compact('product','Productbrand','categories','varients','countries','product_images','product_id_list'));
    }
    
    public function InsertSproduct ( Request $request){   // dd($request);
        $data = $request->validate([
                    'name'      => 'required',
                    'product_price'      =>'required|numeric',
                    'stock_count'      =>'required|numeric',
                    'SKU'      => 'required|unique:seller_products',
                ]);
               
        $user_id = Auth::guard('user')->user()->id;
        $usertype = Auth::guard('user')->user()->usertype; 
        $user = User::find($user_id);  
        if($usertype=="seller") //if not seller redirect to home
        {
                

            $available_countries = $category_id = $variants = "";
            if(!empty($request->input('available_countries'))) {
            $available_countries  = $request->input('available_countries');
            $available_countries=implode(",",$available_countries);
            }
            $category_id ="";
            if(!empty($request->input('category_id'))) 
			$category_id = $request->input('category_id');
		
			if(!empty($request->input('subcategory_id'))) 
			$category_id = $category_id .",".$request->input('subcategory_id');
		     
			if(!empty($request->input('subsubcategory_id'))) 
			$category_id = $category_id .",".$request->input('subsubcategory_id');
		
            if(!empty($request->input('variants'))) {
            $variants = $request->input('variants');
            $variants = implode(",",$variants);
            }
            $input = $request->all();
						// Brand Insert section below
if(!empty($request->input('brands'))) { 
    $brand_data=Productbrand::where(DB::raw('lower(name)'),strtolower(trim($request->input('brands'))))->pluck('id')->first(); 
    if(!empty($brand_data))
      $input['brands']=$brand_data;
    else{
        $newbrand=array('name'=>$request->input('brands'));
        $brand_data=Productbrand::create($newbrand);
        $input['brands']=$brand_data->id;
    }
}  
else
     $input['brands']= "";
            
            $input['available_countries'] = $available_countries;
            $input['category_id']=$category_id;
            $input['variants']=$variants;
            $input['user_id']=$user_id;
			$input['status']='pending';
           
           $id = SellerProduct::create($input)->id;

            $prev_imgs = $request->input('prev_imgs');
            
            $prev_imgs = explode(',', $prev_imgs);
            foreach($prev_imgs as $prev_img_id)
            {
                $preve_img = ProductImage::find($prev_img_id); 
                if(!empty($preve_img)) {
               $img['thumbnail']  = $preve_img->thumbnail;
               $img['image_path'] = $preve_img->image_path;
               $img['product_id'] = $id ;
               SellerProductImage::create($img);
                }
               
            }
    
            if($request->hasFile("product_image")){ 
                $file=$request->file("product_image"); //dd($request->file("product_image"));
                $fileName=time().'_'.$file->getClientOriginalName();
                $destinationPath = public_path().'/uploads/productImages' ;
                $file->move($destinationPath,$fileName);
                $img['image_path'] = $fileName;
                $img['thumbnail'] = "yes";
                $img['product_id'] = $id ;
                SellerProductImage::create($img);
            }
            
            if($request->hasFile("product_gallery")){
                $files=$request->file("product_gallery");
                foreach($files as $file){
                    $imageName=time().'_'.$file->getClientOriginalName();
                    $img['product_id']=$id;
                    $img['thumbnail'] = "no";
                    $img['image_path']=$imageName;
                    $destinationPath = public_path().'/uploads/productImages' ;
                    $file->move($destinationPath,$imageName);
                    SellerProductImage::create($img);

                }
                
        }
        return redirect()->route('seller.products')->with('message', 'Product added successfully');
    }
        else
        return redirect()->route('home');
    }



    public function addnewSproduct ( Request $request){   // dd($request);
        $data = $request->validate([
                    'name'      => 'required',
                    'stock_count'      => 'required',
                    'product_price'      =>'required|numeric',
                    'SKU'      => 'required|unique:seller_products',
                ]);
               
        $user_id = Auth::guard('user')->user()->id;
        $usertype = Auth::guard('user')->user()->usertype; 
        $user = User::find($user_id);  
        if($usertype=="seller") //if not seller redirect to home
        {
                

            $available_countries = $category_id = $variants = "";
            if(!empty($request->input('available_countries'))) {
            $available_countries  = $request->input('available_countries');
            $available_countries=implode(",",$available_countries);
            }
			
			$category_id ="";
            if(!empty($request->input('category_id'))) 
			$category_id = $request->input('category_id');
		
			if(!empty($request->input('subcategory_id'))) 
			$category_id = $category_id .",".$request->input('subcategory_id');
		     
			if(!empty($request->input('subsubcategory_id'))) 
			$category_id = $category_id .",".$request->input('subsubcategory_id');
		
            if(!empty($request->input('variants'))) {
            $variants = $request->input('variants');
            $variants = implode(",",$variants);
            }
            $input = $request->all();
			
			
			
			// Brand Insert section below
if(!empty($request->input('brands'))) { 
    $brand_data=Productbrand::where(DB::raw('lower(name)'),strtolower(trim($request->input('brands'))))->pluck('id')->first(); 
    if(!empty($brand_data))
      $input['brands']=$brand_data;
    else{
        $newbrand=array('name'=>$request->input('brands'));
        $brand_data=Productbrand::create($newbrand);
        $input['brands']=$brand_data->id;
    }
}  
else
     $input['brands']= "";
			
			

            $input['available_countries'] = $available_countries;
            $input['category_id']=$category_id;
            $input['variants']=$variants;
            $input['user_id']=$user_id;
			$input['status']='pending';
        //  dd($input);
           $id = SellerProduct::create($input)->id;

            $prev_imgs = $request->input('prev_imgs');
            
            $prev_imgs = explode(',', $prev_imgs);
            foreach($prev_imgs as $prev_img_id)
            {
                $preve_img = ProductImage::find($prev_img_id); 
                if(!empty($preve_img)) {
               $img['thumbnail']  = $preve_img->thumbnail;
               $img['image_path'] = $preve_img->image_path;
               $img['product_id'] = $id ;
               SellerProductImage::create($img);
                }
               
            }
    
            if($request->hasFile("product_image")){ 
                $file=$request->file("product_image"); //dd($request->file("product_image"));
                $fileName=time().'_'.$file->getClientOriginalName();
                $destinationPath = public_path().'/uploads/productImages' ;
                $file->move($destinationPath,$fileName);
                $img['image_path'] = $fileName;
                $img['thumbnail'] = "yes";
                $img['product_id'] = $id ;
                SellerProductImage::create($img);
            }
            
            if($request->hasFile("product_gallery")){
                $files=$request->file("product_gallery");
                foreach($files as $file){
                    $imageName=time().'_'.$file->getClientOriginalName();
                    $img['product_id']=$id;
                    $img['thumbnail'] = "no";
                    $img['image_path']=$imageName;
                    $destinationPath = public_path().'/uploads/productImages' ;
                    $file->move($destinationPath,$imageName);
                    SellerProductImage::create($img);

                }
                
        }
        return redirect()->route('seller.products')->with('message', 'Product added successfully');
    }
        else
        return redirect()->route('home');
    }








    public function deleteSellerProductimage($id){ 
    //     $images=ProductImage::findOrFail($id);
    //     if (File::exists("/uploads/SellerproductImages/".$images->image_path)) {
    //        File::delete("/uploads/SellerproductImages/".$images->image_path);
    //    }
       SellerProductImage::find($id)->delete();
       return back();
   }

   public function import( Request $request) 
   {
       $result = Excel::import(new SellerProductImport,request()->file('file'));
        
       return back()->with('success', 'Products Imported Successfully.');
   }


   public function getSellerproductlist(Request $request)
   {  
       $userId = Auth::guard('user')->user()->id;
       $columnIndex_arr = $request->get('order');
       $columnName_arr = $request->get('columns');
       $order_arr = $request->get('order');
       $search_arr = $request->get('search');
      
               $draw = $request->get('draw');
               $start = $request->get("start");
               $rowperpage = $request->get("length"); // total number of rows per page
               $columnIndex = $columnIndex_arr[0]['column']; // Column index
               $columnName = $columnName_arr[$columnIndex]['data']; // Column name
               $columnSortOrder = $order_arr[0]['dir']; // asc or desc
              // $searchValue = $search_arr['value']; // Search value
    $userId = Auth::guard('user')->user()->id;
       $totalRecords = SellerProduct::select('count(*) as allcount')
       ->where('user_id',$userId)
       ->where('status','!=','deleted')->count();
       $totalRecordswithFilter = SellerProduct::select('count(*) as allcount')
       ->where('user_id',$userId)
       ->where('status','!=','deleted')
       ->where(function ($query) use($request){

        if($request->get('search_key') !=""){
           $query->where('name','Like','%'.$request->get('search_key').'%');
       }
       if($request->get('category_id') !=null){
            $query->whereRaw('find_in_set("'.$request->get('category_id').'",category_id)');
       }
                       
       if($request->get('stock') !=null){
                           if($request->get('stock')=="instock")
                               $query->where("stock_count",">",0);
                           else
                               $query-> where("stock_count","<=",0);
        }})
        ->count(); 

      

       // Get records, also we have included search filter as well
       $records = SellerProduct::select('*')
       ->where('user_id',$userId)
       ->where('status','!=','deleted')
       ->where('user_id',$userId)->where(function ($query) use($request){

        if($request->get('search_key') !=""){
           $query->where('name','Like','%'.$request->get('search_key').'%');
       }
       if($request->get('category_id') !=""){
             $query->whereRaw('find_in_set("'.$request->get('category_id').'",category_id)');
       }
                       
       if($request->get('stock') !=""){
                   if($request->get('stock')=="instock")
                         $query->where("stock_count",">",0);
                   else
                           $query->where("stock_count","<=",0);
        }
    })
    ->orderBy($columnName,$columnSortOrder)
           ->skip($start)
           ->take($rowperpage)
           ->get();
       $data_arr = array();
      
       foreach ($records as $record) {
            $strcat_parent = $strcat='';
            $Categories = explode(",",$record->category_id);
                       foreach($Categories as $item) {
                        $strcat_parent.= Category::where('id',$item)->where('parent_id', null)->pluck('name')->first()."<br/>";
                        $strcat.= Category::where('id',$item)->where('parent_id','!=', null)->pluck('name')->first()."<br/>";
                       }
                           
                                 
             $strimg='';                    
             foreach( $record->SellerProductImage as $productimage)
              {     
                       if($productimage->thumbnail == 'yes') 
                          $strimg.= '<div class="table-prof"><img style=" width:60px !important;" class="pr_img" src="'.asset("/uploads/productImages/").'/'.$productimage->image_path.'"></div>';
              }         
                                                                                       
          
           $data_arr[] = array(  
               "id" => $record->id,
               "name" => $record->name,
               "status" => $record->status,
               "created_at" => date("d/m/Y   \&\\n\b\s\p\; \&\\n\b\s\p\; \&\\n\b\s\p\;  g:i A", strtotime($record->created_at)),
               "strcat_parent" => $strcat_parent,
               "strcat" => $strcat,
               "strimg" => $strimg,
              );
       }

       $response = array(
           "draw" => intval($draw),
           "iTotalRecords" => $totalRecords,
           "iTotalDisplayRecords" => $totalRecordswithFilter,
           "aaData" => $data_arr,
       );
       echo json_encode($response);       
}


public function SellerProductDetails($productId){ 


    if(Auth::guard('user')->check())
    {



        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }
            if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
                  {
                                   Auth::guard('user')->logout(); 
                                   return redirect(route('home')); 
                  }
    } 
    $is_active_subscriber=$this->PublicMiddlewareController->checkUserContactValidity();
    


    $product = SellerProduct::where('id',$productId)->first(); 
    $seller_id = $product->user_id;
    $category_id = $product->category_id;
    $seller = User::find($seller_id);


   if( empty($product)) return redirect('home');
   
   $varients = $user_id = $user = $wish_listed = "";
   $login_id = null;
   if(Auth::guard('user')->check()) { 
    
    $login_id = $user_id = Auth::guard('user')->user()->id;
    $user = User::find($user_id);

    $wish_listed=  Wishlist::where('product_id','=',$productId)->where('user_id','=',$user_id)->pluck('wishlist')->first();

    } 
    $clientIP = \Request::ip();
    $insight=array();
    $insight = [
        'user_id' => $login_id,
        'product_id' => $productId,
        'category_id' => $category_id,
        'ip_address' => $clientIP,
     ];
     BusinessInsight::create($insight);
    if(!empty($product->available_countries))
    $country_ids = explode(",",$product->available_countries); 
    else
    $country_ids =[];


    if(!empty($product->category_id))
    $category_id = explode(",",$product->category_id); 
    else
    $cats = $category_id =[]; 
    $cats = Category::select('id','name')->whereIn('id',$category_id)->get(); 
    
        //Varients
        foreach ($category_id as $id)
        {
        $varients = SellerProduct::
        whereRaw('find_in_set("'.$id.'",category_id)')
        ->where('status','active')
        ->where('id','!=',$productId)
        ->latest()->take(8)->get(); 
        }
       
       
        $productReviews = ProductReview::where('product_id','=',$productId)->latest()->paginate(5);
        $product_images = SellerProductImage::where('product_id','=',$productId)->get();
        $countries = Country::all(); 
        $user_review_exists = 'no';
        if($user_id!="")
        $user_review_exists =  ProductReview::where('product_id',$productId)->where('user_id', $user_id)->exists();
       
        $productReviewCounts = ProductReview::select('*')->selectRaw('count(*) as Starcount')->selectRaw('SUM(star_rating) as TotalStar')
        ->where('product_id',$productId)
        ->first();

   
       
       
    return view('frontEnd.products.product-details',compact('user','cats','wish_listed','seller','user_review_exists','productReviews','productId','product','countries','varients','product_images','productReviewCounts','is_active_subscriber'));
   
}



public function EditSellerProduct($productId){



    $product = SellerProduct::where('id',$productId)->with('SellerProductImage')->first();
   

   if( empty($product)) return redirect('home');
    $categories = Category::where('parent_id', null)->get();

    if(!empty($product->available_countries))
    $country_ids = explode(",",$product->available_countries); 
    else
    $country_ids =[];

       // $country_ids = explode(',',$product->available_countries);
        $varients = Product::all();
        $Productbrand = Productbrand::orderBy('name')->get();
        $product_images = SellerProductImage::where('product_id','=',$productId)->get();
        $countries = Country::all(); 
        $user_id = Auth::guard('user')->user()->id;
        $user = User::find($user_id);
    return view('frontEnd.seller.edit-Sproduct',compact('productId','product','Productbrand','categories','countries','user','varients','product_images'));
   
}

public function deleteSellerimage( Request $request){ 
    $images=SellerProductImage::findOrFail($request->id);
    if (File::exists("/uploads/productImages/".$images->image_path)) {
       File::delete("/uploads/productImages/".$images->image_path);
   }

   SellerProductImage::find($request->id)->delete();
   $returnArray['result'] = true;
   $returnArray['message'] = 'Testimonial image removed successfully.';
   return response()->json($returnArray);
   //return back();
}
   


public function updateSellerProduct(Request $request) { 
        
    request()->validate([
        'name' => ['required', 'string'],
        'product_price' => ['required', 'numeric'],
        'SKU' => ['required', 'string',Rule::unique('seller_products')],
        
    ]);
    $productId = $request->get('id');
    $product = SellerProduct::find($productId);
   
    $available_countries = $category_id = $variants = "";
    if(!empty($request->input('available_countries'))) {
    $available_countries  = $request->input('available_countries');
    $available_countries=implode(",",$available_countries);
    }
    if(!empty($request->input('category_id'))) {
    $category_id = $request->input('category_id');
    $category_id = implode(",",$category_id);
    }
    if(!empty($request->input('variants'))) {
    $variants = $request->input('variants');
    $variants = implode(",",$variants);
    }
    $input = $request->all();
	
				// Brand Insert section below
if(!empty($request->input('brands'))) { 
    $brand_data=Productbrand::where(DB::raw('lower(name)'),strtolower(trim($request->input('brands'))))->pluck('id')->first(); 
    if(!empty($brand_data))
      $input['brands']=$brand_data;
    else{
        $newbrand=array('name'=>$request->input('brands'));
        $brand_data=Productbrand::create($newbrand);
        $input['brands']=$brand_data->id;
    }
}  
else
     $input['brands']= "";
    
    $input['available_countries'] = $available_countries;
    $input['category_id']=$category_id;
    $input['variants']=$variants;

    if($request->hasFile("product_image")){ 
        $file=$request->file("product_image");
        $fileName=time().'_'.$file->getClientOriginalName();
        $destinationPath = public_path().'/uploads/productImages' ;
        $file->move($destinationPath,$fileName);
        $img['image_path'] = $fileName;
        $img['thumbnail'] = "yes";
        $img['product_id'] = $productId ;
        DB::table('seller_product_images')->where([
            ['product_id', '=', $productId],
            ['thumbnail', '=', 'yes'],
        ])->delete();
        SellerProductImage::create($img);

    }
}

public function profile_account_delete(Request $request)
{ 
   

    $input=[];
    $input['reason']=$request->input('reason');
    $input['user_id']=$request->input('user_id');
    $input['status']='New';
           
    $value = ProfileAccountDeleteRequest::create($input);

    return json_encode($value->id);
}

public function updateSProduct(Request $request) { 
        
    request()->validate([
        'name' => ['required', 'string'],
        'product_price' => ['required', 'numeric'],
        'stock_count' => ['required', 'numeric'],
       // 'SKU' => ['required', 'string',Rule::unique('seller_products')->$request->get('id')],
        
    ]);
    $productId = $request->get('id'); 
    $product = SellerProduct::find($productId);
    
    $available_countries = $category_id = $variants = "";
    if(!empty($request->input('available_countries'))) {
    $available_countries  = $request->input('available_countries');
    $available_countries=implode(",",$available_countries);
    }
    if(!empty($request->input('category_id'))) {
    $category_id = $request->input('category_id');
    $category_id = implode(",",$category_id);
    }
    if(!empty($request->input('variants'))) {
    $variants = $request->input('variants');
    $variants = implode(",",$variants);
    }
    $input = $request->all();
					// Brand Insert section below
if(!empty($request->input('brands'))) { 
    $brand_data=Productbrand::where(DB::raw('lower(name)'),strtolower(trim($request->input('brands'))))->pluck('id')->first(); 
    if(!empty($brand_data))
      $input['brands']=$brand_data;
    else{
        $newbrand=array('name'=>$request->input('brands'));
        $brand_data=Productbrand::create($newbrand);
        $input['brands']=$brand_data->id;
    }
}  
else
     $input['brands']= "";
    
    $input['available_countries'] = $available_countries;
    $input['category_id']=$category_id;
    $input['variants']=$variants;

    if($request->hasFile("product_image")){ 
        $file=$request->file("product_image");
        $fileName=time().'_'.$file->getClientOriginalName();
        $destinationPath = public_path().'/uploads/productImages' ;
        $file->move($destinationPath,$fileName);
        $img['image_path'] = $fileName;
        $img['thumbnail'] = "yes";
        $img['product_id'] = $productId ;
        DB::table('seller_product_images')->where([
            ['product_id', '=', $productId],
            ['thumbnail', '=', 'yes'],
        ])->delete();
        SellerProductImage::create($img);

    }

        if($request->hasFile("product_gallery")){
            $files=$request->file("product_gallery");
            foreach($files as $file){
                $imageName=time().'_'.$file->getClientOriginalName();
                $img['product_id']=$productId;
                $img['thumbnail'] = "no";
                $img['image_path']=$imageName;
                $destinationPath = public_path().'/uploads/productImages' ;
                $file->move($destinationPath,$imageName);
                SellerProductImage::create($img);

            }
        }
   
    $product->update($input);
    return redirect()->route('seller.products')->with('message','Product Updated');
}

public function deleteSProduct($productId)
    {
        $product=  SellerProduct::find($productId);
        $productImages =  SellerProductImage::where('product_id','=',$productId)->get();
        
        if(empty($product)){ 
            return redirect()->route('seller.products')->with('message', 'Product not Exists');
        }
        
        if(!empty($productImages)){
            foreach($productImages as $productImage)
            {
                $path = public_path()."/uploads/productImages/".$productImage->image_path;
                if (file_exists($path)){
                    unlink($path );
                $productImage->delete();
                }
                
            }
        
        }
        
        $product->delete();
        return redirect()->route('seller.products')->with('message', 'Product Deleted!');
    }

    public function AddToWishlist(Request $request)
    {  
         
           $productId =  $input['product_id'] = $request->id;
           $user_id =  $input['user_id'] = Auth::guard('user')->user()->id;
            $input['wishlist'] = 'Yes';
            $id_exists = Wishlist::where('product_id','=',$productId)->where('user_id','=',$user_id)->pluck('id')->first();
            if($id_exists>0)
            Wishlist::where('product_id','=',$productId)->where('user_id','=',$user_id)
       ->update([
           'wishlist' => "Yes"
        ]);
            else
             Wishlist::create($input); 
        $returnArray['result'] = true;
        $returnArray['message'] = 'Added to wishlist.';
        
        return response()->json($returnArray);
    
     }

     public function RemoveWishlist(Request $request)
    {  
         
            $productId =  $input['product_id'] = $request->id;
            $user_id = Auth::guard('user')->user()->id;
            $input['wishlist'] = 'No';
       Wishlist::where('product_id','=',$request->id)->where('user_id','=',$user_id)
       ->update([
           'wishlist' => "No"
        ]);
           
        $returnArray['result'] = true;
        $returnArray['message'] = 'Added to wishlist.';
        
        return response()->json($returnArray);
    
   }






public function List_co_sellers(){ 

    if(Auth::guard('user')->check())
      {


        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }
        if(!$this->PublicMiddlewareController->checkUserValidity() || Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              
                               return redirect(route('home')); 
              
      } 


    $user_id = Auth::guard('user')->user()->id;
    $usertype = Auth::guard('user')->user()->usertype;
    if(Auth::guard('user')->user()->seller_type=='Co-Seller')
           return redirect()->route('home');
    $user = User::where('parent_id',$user_id)->get(); 

    return view('frontEnd.seller.co-sellers',compact('user')); 
  
}

public function addNewSeller(Request $request){ 


  $package_data = DB::table('subscriptions')
                      ->leftJoin('order_details', 'subscriptions.order_id', '=', 'order_details.id')
                      ->leftJoin('packages', 'packages.id', '=', 'order_details.package_id')
                      ->leftJoin('package_accounts', 'package_accounts.id', '=', 'order_details.accounts_id')
                      ->where('subscriptions.user_id', '=',Auth::guard('user')->user()->id)
                      ->where('subscriptions.status','active')
                      ->orderBy('subscriptions.id','DESC')
                      ->first();


 $user = User::where('parent_id',Auth::guard('user')->user()->id)->get();  
 
  if(count($user)>=$package_data->no_of_accounts ||  $package_data->expairy_date<date('Y-m-d') || $package_data->subscription_type!='Extended')
        return redirect()->route('user.listcosellers')->with('message','Co-Seller Adding count Exceeded!'); 


$request->validate([
    'name'      => 'required',
    'email'      =>['required','email', Rule::unique('users')], 
    'phone'      => ['required','regex:/^(^([+]+)(\d+)?$)$/', Rule::unique('users')],
    'username'      => 'required',
    'password' => ['required',  'min:8', 'confirmed'],
   ]);

 $input = $request->all();
 $input['parent_id']=Auth::guard('user')->user()->id;
 $input['seller_type']='Co-Seller';
 $input['usertype']='seller';
 $input['password'] =Hash::make($request->get('password'));

  if(request()->hasFile('imgupload')) {
        $extension = request('imgupload')->extension();
        $fileName = "user_pic".time().'.'.$extension;
        $destinationPath = public_path().'/uploads/userImages' ;
        request('imgupload')->move($destinationPath,$fileName);
        $input['profile_pic'] = $fileName;
    } 
   
 $user=User::create($input);
 Mail::send('admin/seller/email-template', ['name' => $input['name'], 'email' => 
            $input['email'], 'password' => $input['password']] ,function ($message) use ($input) {
                 $message->from("example@gmail.com",'Fmcg');
                 $message->to($input['email'],$input['name'])
                 ->subject('Fmcg Login Credential');
             });
    
 return redirect()->route('user.listcosellers')->with('message','Co-Seller Added successfully!');    
   
}






   
public function usersellersstatusupdates(Request $request)
{
    $status=$request->get('status');
    $id=$request->get('id');

    $User=  User::find($id);
    $User->status =$status;
    $update=$User->save();
    if($update)
        echo json_encode('User '.$status);   
    else
        echo json_encode("Status Not Changed");
}    


 public function deleteUser($userId)
{
    
    $user =  User::find($userId);
    if(empty($user)){ 
        return redirect()->route('user.listcosellers')->with('message', 'User not Exists');
    }
    $user->delete();
    return redirect()->route('user.listcosellers')->with('message', 'User Deleted!');
}




public function WishlistItems(){

     if(Auth::guard('user')->check())
      {




        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }
        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
      } 

    $user_id = Auth::guard('user')->user()->id;
    $user = User::find($user_id);
    //$products = SellerProduct::where('user_id',$user_id)->get();
    $wishlists = Wishlist::where('user_id',$user_id)->where('wishlist','Yes')->pluck('product_id')->all();
    $products = SellerProduct::where('status','active')->whereIn('id',$wishlists)->with('SellerProductImage')->latest()->paginate(20);
    $countries = Country::all();
    $categories = Category::where('parent_id', null)->get();
    if(Auth::guard('user')->check()) 
    return view('frontEnd.seller.WishlistItems',compact('user','products','categories','countries'));
    else
    return redirect()->route('home');
}



public function WishlistItemsFilter( Request $request){
	
	$filter= $request->wish_filter;

     if(Auth::guard('user')->check())
      {




        if(!$this->PublicMiddlewareController->checkUserlogin()) 
        {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home'))->with('message','Access Denied'); ; 
        }
        if(!$this->PublicMiddlewareController->checkUserValidity() && Auth::guard('user')->user()->seller_type=='Co-Seller' ) 
              {
                               Auth::guard('user')->logout(); 
                               return redirect(route('home')); 
              }
      } 

    $user_id = Auth::guard('user')->user()->id;
    $user = User::find($user_id);
    //$products = SellerProduct::where('user_id',$user_id)->get();
    $wishlists = Wishlist::where('user_id',$user_id)->where('wishlist','Yes')->pluck('product_id')->all();
	

	
	$products = SellerProduct::select('*')->where('status','active')->whereIn('id',$wishlists)
      ->when($filter=="Active", function ($q)  {
        return $q ->where(function ($query) {
              $query ->where('product_expiry', '>', Carbon::now())
                     ->orWhereNull('product_expiry');
           });})
      ->when($filter=="Expired", function ($q)  {
          return $q->where('product_expiry', '<', Carbon::now())
          ;})
      ->with('SellerProductImage')->latest()->paginate(20); 
	
	
    $countries = Country::all();
    $categories = Category::where('parent_id', null)->get();
    if(Auth::guard('user')->check()) 
    return view('frontEnd.seller.WishlistItems',compact('user','products','categories','countries'));
    else
    return redirect()->route('home');
}





public function loadreview(Request $request)
{ 
  

    $start_from=$request->input('start_from');
    $per_page=$request->input('per_page');   
    $productId=$request->input('product_id');   
    $productReviews = ProductReview::where('product_id','=',$productId);
    $count = $productReviews->count();
    $productReviews= $productReviews->skip($start_from)->take($per_page)->get();

   $data_return=[];
   foreach($productReviews as $data){
    $created_at = date('M d , Y', strtotime($data->created_at));
    $data_return[]= array('name'=>$data->name,'email'=>$data->email,'review_title'=>$data->review_title,'review'=>$data->review,'star_rating'=>$data->star_rating,'created_at'=>$created_at );
  }
  $return_array=['count'=>$count,'productReviews'=>$data_return];
  return json_encode($return_array);
 
}




}
